This directory exists to support subpath imports for TypeScript projects using --moduleResolution node.
