import type { Component } from 'vue';
import type { MessagePartStatus } from './AssistantTypes';

export interface TextMessagePartProps {
  type: 'text';
  text: string;
  status: MessagePartStatus;
}

export interface ImageMessagePartProps {
  type: 'image';
  image: string;
  status: MessagePartStatus;
}

export interface FileMessagePartProps {
  type: 'file';
  file: any;
  status: MessagePartStatus;
}

export interface AudioMessagePartProps {
  type: 'audio';
  audio: any;
  status: MessagePartStatus;
}

export interface ReasoningMessagePartProps {
  type: 'reasoning';
  reasoning: string;
  status: MessagePartStatus;
}

export interface SourceMessagePartProps {
  type: 'source';
  source: any;
  status: MessagePartStatus;
}

export interface EmptyMessagePartProps {
  status: MessagePartStatus;
}

export interface ToolCallMessagePartProps {
  type: 'tool-call';
  toolCallId: string;
  toolName: string;
  args: any;
  result?: any;
  addResult: (result: any) => void;
}

export type TextMessagePartComponent = Component<TextMessagePartProps>;
export type ImageMessagePartComponent = Component<ImageMessagePartProps>;
export type FileMessagePartComponent = Component<FileMessagePartProps>;
export type AudioMessagePartComponent = Component<AudioMessagePartProps>;
export type ReasoningMessagePartComponent = Component<ReasoningMessagePartProps>;
export type SourceMessagePartComponent = Component<SourceMessagePartProps>;
export type EmptyMessagePartComponent = Component<EmptyMessagePartProps>;
export type ToolCallMessagePartComponent = Component<ToolCallMessagePartProps>;

export interface MessagePartComponentTypes {
  Empty?: EmptyMessagePartComponent;
  Text?: TextMessagePartComponent;
  Reasoning?: ReasoningMessagePartComponent;
  Source?: SourceMessagePartComponent;
  Image?: ImageMessagePartComponent;
  File?: FileMessagePartComponent;
  Unstable_Audio?: AudioMessagePartComponent;
  tools?: {
    by_name?: Record<string, ToolCallMessagePartComponent | undefined>;
    Fallback?: ToolCallMessagePartComponent;
  } | {
    Override: ToolCallMessagePartComponent;
  };
  ToolGroup?: Component<{ startIndex: number; endIndex: number }>;
}