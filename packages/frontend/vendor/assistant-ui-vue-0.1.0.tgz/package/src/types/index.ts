export type {
  Attachment,
  PendingAttachment,
  CompleteAttachment,
  AttachmentStatus,
} from "./AttachmentTypes";

export type {
  AppendMessage,
  TextMessagePart,
  ReasoningMessagePart,
  SourceMessagePart,
  ImageMessagePart,
  FileMessagePart,
  Unstable_AudioMessagePart,
  ToolCallMessagePart,
  MessageStatus,
  MessagePartStatus,
  ToolCallMessagePartStatus,

  // thread message types
  ThreadUserMessagePart,
  ThreadAssistantMessagePart,
  ThreadSystemMessage,
  ThreadAssistantMessage,
  ThreadUserMessage,
  ThreadMessage,
} from "./AssistantTypes";

// Aliases for backward compatibility
export type {
  MessagePartStatus as ContentPartStatus,
  ToolCallMessagePartStatus as ToolCallContentPartStatus,
} from "./AssistantTypes";

export type { Unsubscribe } from "./Unsubscribe";

// Export API types
export type { MessageState } from "../api/MessageRuntime";
export type { ThreadState } from "../api/ThreadRuntime";

export * from "./MessagePartComponentTypes";
export * from "./ThreadMessageComponentTypes";