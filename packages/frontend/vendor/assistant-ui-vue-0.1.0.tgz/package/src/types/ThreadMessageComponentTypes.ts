import type { Component } from 'vue';

export type ThreadMessageRole = 'user' | 'assistant' | 'system';

export type ThreadMessageComponentTypes =
  | {
      /** Component used to render all message types */
      Message: Component;
      /** Component used when editing any message type */
      EditComposer?: Component;
      /** Component used when editing user messages specifically */
      UserEditComposer?: Component;
      /** Component used when editing assistant messages specifically */
      AssistantEditComposer?: Component;
      /** Component used when editing system messages specifically */
      SystemEditComposer?: Component;
      /** Component used to render user messages specifically */
      UserMessage?: Component;
      /** Component used to render assistant messages specifically */
      AssistantMessage?: Component;
      /** Component used to render system messages specifically */
      SystemMessage?: Component;
    }
  | {
      /** Component used to render all message types (fallback) */
      Message?: Component;
      /** Component used when editing any message type */
      EditComposer?: Component;
      /** Component used when editing user messages specifically */
      UserEditComposer?: Component;
      /** Component used when editing assistant messages specifically */
      AssistantEditComposer?: Component;
      /** Component used when editing system messages specifically */
      SystemEditComposer?: Component;
      /** Component used to render user messages */
      UserMessage: Component;
      /** Component used to render assistant messages */
      AssistantMessage: Component;
      /** Component used to render system messages */
      SystemMessage?: Component;
    };