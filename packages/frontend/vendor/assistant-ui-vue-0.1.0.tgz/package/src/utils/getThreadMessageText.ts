import type { ThreadMessage } from "../types";

export function getThreadMessageText(message: ThreadMessage): string {
  const textParts: string[] = [];
  
  for (const part of message.content) {
    if (part.type === 'text') {
      textParts.push(part.text);
    } else if (part.type === 'tool-call' && 'result' in part) {
      // Handle tool call results if they contain text
      if (typeof part.result === 'string') {
        textParts.push(part.result);
      }
    }
  }
  
  return textParts.join('\n');
}