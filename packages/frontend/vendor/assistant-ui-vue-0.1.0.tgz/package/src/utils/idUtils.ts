let counter = 0;

export function generateId(prefix: string = 'id'): string {
  return `${prefix}-${Date.now()}-${counter++}`;
}

export function generateOptimisticId(): string {
  return generateId('optimistic');
}