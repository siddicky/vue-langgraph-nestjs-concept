import { Ref, watch, onUnmounted } from 'vue';

export const useOnResizeContent = (elementRef: Ref<HTMLElement | undefined>, callback: () => void) => {
  let resizeObserver: ResizeObserver | null = null;
  let mutationObserver: MutationObserver | null = null;
  
  const cleanup = () => {
    if (resizeObserver) {
      resizeObserver.disconnect();
      resizeObserver = null;
    }
    if (mutationObserver) {
      mutationObserver.disconnect();
      mutationObserver = null;
    }
  };
  
  watch(elementRef, (element) => {
    cleanup();
    
    if (element) {
      resizeObserver = new ResizeObserver(() => {
        callback();
      });
      
      mutationObserver = new MutationObserver(() => {
        callback();
      });
      
      resizeObserver.observe(element);
      mutationObserver.observe(element, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
      });
    }
  });
  
  onUnmounted(() => {
    cleanup();
  });
};