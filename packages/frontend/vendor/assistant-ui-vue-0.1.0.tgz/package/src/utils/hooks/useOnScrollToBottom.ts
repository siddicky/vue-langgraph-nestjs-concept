import { onMounted, onUnmounted } from 'vue';
import { useThreadViewportStore } from '../../composables/thread/useThreadViewportContext';

export const useOnScrollToBottom = (callback: () => void) => {
  const threadViewportStore = useThreadViewportStore();
  let unsubscribe: (() => void) | undefined;
  
  onMounted(() => {
    if (threadViewportStore && threadViewportStore.value) {
      const viewport = threadViewportStore.value;
      if (viewport.onScrollToBottom) {
        unsubscribe = viewport.onScrollToBottom(callback);
      }
    }
  });
  
  onUnmounted(() => {
    if (unsubscribe) {
      unsubscribe();
    }
  });
};