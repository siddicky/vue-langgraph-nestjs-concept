import { ref as vueRef, type Ref } from "vue";

export const useManagedRef = <TNode>(
  callback: (node: TNode) => (() => void) | void,
): ((el: TNode | null) => void) => {
  const cleanupRef: Ref<(() => void) | void> = vueRef<(() => void) | void>(undefined);

  const ref = (el: TNode | null) => {
    // Call the previous cleanup function
    if (cleanupRef.value) {
      cleanupRef.value();
    }

    // Call the new callback and store its cleanup function
    if (el) {
      cleanupRef.value = callback(el);
    }
  };

  return ref;
};
