<template>
  <button
    type="button"
    :disabled="!callback"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts" generic="TProps = Record<string, any>">
import { computed } from 'vue';

/**
 * Generic action button component that provides standardized behavior
 * for buttons with callback actions.
 * 
 * This is a utility component used to create other action buttons.
 */

interface Props {
  callback?: (() => void) | null;
}

const props = defineProps<Props>();
const emit = defineEmits<{
  click: [event: MouseEvent];
}>();

const handleClick = (event: MouseEvent) => {
  emit('click', event);
  if (props.callback) {
    props.callback();
  }
};
</script>