import { type ComputedRef } from 'vue';
import {
  type CombinedSelector,
  createCombinedStore,
  StoreOrRuntime,
} from './createCombinedStore';

export const useCombinedStore = <T extends Array<unknown>, R>(
  stores: { [K in keyof T]: StoreOrRuntime<T[K]> },
  selector: CombinedSelector<T, R>,
): ComputedRef<R> => {
  const useCombined = createCombinedStore<T, R>(stores);
  return useCombined(selector);
};