import { computed, type ComputedRef, type Ref } from 'vue';
import type { Unsubscribe } from '../../types/Unsubscribe';

export type StoreOrRuntime<T> = {
  getState: () => T;
  subscribe: (callback: () => void) => Unsubscribe;
};

export type CombinedSelector<T extends Array<unknown>, R> = (...args: T) => R;

export const createCombinedStore = <T extends Array<unknown>, R>(
  stores: {
    [K in keyof T]: StoreOrRuntime<T[K]> | Ref<T[K]> | ComputedRef<T[K]>;
  }
) => {
  return (selector: CombinedSelector<T, R>): ComputedRef<R> => {
    return computed(() => {
      const values = stores.map((store) => {
        if ('getState' in store) {
          return store.getState();
        }
        return store.value;
      }) as T;
      
      return selector(...values);
    });
  };
};