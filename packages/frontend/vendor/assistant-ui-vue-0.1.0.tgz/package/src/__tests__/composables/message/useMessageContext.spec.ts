import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useMessageContext } from '../../../composables/message/useMessageContext';
import { inject } from 'vue';

vi.mock('vue', async () => {
  const actual = await vi.importActual('vue');
  return {
    ...actual,
    inject: vi.fn(),
    computed: vi.fn((fn) => ({ value: fn() }))
  };
});

describe('useMessageContext', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns message context when available', () => {
    const mockMessageRuntime = {
      getState: vi.fn().mockReturnValue({
        id: 'msg-1',
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }],
        createdAt: new Date()
      }),
      subscribe: vi.fn(),
      edit: vi.fn(),
      reload: vi.fn(),
      deleteMessage: vi.fn()
    };

    const mockUtils = {
      isCopied: false,
      isHovering: false,
      isSpeaking: false,
      canSpeak: true
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockMessageRuntime },
      utils: mockUtils
    });

    const result = useMessageContext();
    
    expect(result).toBeDefined();
    expect(result!.message).toBeDefined();
    expect(result!.messageRuntime).toBe(mockMessageRuntime);
    expect(result!.messageUtils).toBeDefined();
  });

  it('returns null when optional and no context available', () => {
    (inject as any).mockReturnValue(null);

    const result = useMessageContext({ optional: true });
    expect(result).toBeNull();
  });

  it('throws error when required and no context available', () => {
    (inject as any).mockReturnValue(null);

    expect(() => useMessageContext()).toThrow(
      'useMessageContext must be used within a MessageProvider'
    );
  });

  it('returns computed message state', () => {
    const messageState = {
      id: 'msg-2',
      role: 'assistant',
      content: [{ type: 'text', text: 'Hi there!' }],
      createdAt: new Date(),
      parentId: 'msg-1',
      branchNumber: 1,
      branchCount: 1
    };

    const mockMessageRuntime = {
      getState: vi.fn().mockReturnValue(messageState),
      subscribe: vi.fn()
    };

    const mockUtils = {
      isCopied: false,
      isHovering: true,
      isSpeaking: false,
      canSpeak: false
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockMessageRuntime },
      utils: mockUtils
    });

    const context = useMessageContext();
    
    expect(context!.message.value).toEqual(messageState);
    expect(context!.message.value.role).toBe('assistant');
    expect(context!.message.value.id).toBe('msg-2');
  });

  it('returns message utils state', () => {
    const mockMessageRuntime = {
      getState: vi.fn().mockReturnValue({
        id: 'msg-3',
        role: 'user',
        content: []
      }),
      subscribe: vi.fn()
    };

    const mockUtils = {
      isCopied: true,
      isHovering: false,
      isSpeaking: true,
      canSpeak: true
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockMessageRuntime },
      utils: mockUtils
    });

    const context = useMessageContext();
    
    expect(context!.messageUtils.value).toEqual(mockUtils);
    expect(context!.messageUtils.value.isCopied).toBe(true);
    expect(context!.messageUtils.value.isSpeaking).toBe(true);
  });

  it('handles message runtime with capabilities', () => {
    const mockMessageRuntime = {
      getState: vi.fn().mockReturnValue({
        id: 'msg-4',
        role: 'assistant',
        content: [{ type: 'text', text: 'Response' }],
        createdAt: new Date(),
        status: { type: 'complete' }
      }),
      subscribe: vi.fn(),
      edit: vi.fn(),
      reload: vi.fn(),
      speak: vi.fn(),
      stopSpeak: vi.fn(),
      submitFeedback: vi.fn()
    };

    const mockUtils = {
      isCopied: false,
      isHovering: false,
      isSpeaking: false,
      canSpeak: true
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockMessageRuntime },
      utils: mockUtils
    });

    const context = useMessageContext();
    
    expect(context!.messageRuntime).toBe(mockMessageRuntime);
    expect(context!.messageRuntime.speak).toBeDefined();
    expect(context!.messageRuntime.submitFeedback).toBeDefined();
  });

  it('handles message with attachments', () => {
    const messageWithAttachments = {
      id: 'msg-5',
      role: 'user',
      content: [
        { type: 'text', text: 'Check this file' }
      ],
      attachments: [
        { 
          id: 'att-1',
          type: 'file',
          name: 'document.pdf',
          status: { type: 'complete' }
        }
      ],
      createdAt: new Date()
    };

    const mockMessageRuntime = {
      getState: vi.fn().mockReturnValue(messageWithAttachments),
      subscribe: vi.fn()
    };

    const mockUtils = {
      isCopied: false,
      isHovering: false,
      isSpeaking: false,
      canSpeak: false
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockMessageRuntime },
      utils: mockUtils
    });

    const context = useMessageContext();
    
    expect(context!.message.value).toEqual(messageWithAttachments);
    expect(context!.message.value.attachments).toHaveLength(1);
    expect(context!.message.value.attachments![0].name).toBe('document.pdf');
  });
});