import { describe, it, expect, vi, beforeEach } from 'vitest';
import { ref } from 'vue';
import { useThreadViewportAutoScroll } from '../../../composables/thread/useThreadViewportAutoScroll';

// Mock dependencies
vi.mock('../../../composables/thread/useThreadRuntime', () => ({
  useThreadRuntime: () => ref({
    unstable_on: vi.fn(() => {
      return () => {}; // Return unsubscribe function
    })
  })
}));

vi.mock('../../../composables/thread/useThreadViewportContext', () => ({
  useThreadViewportStore: () => ref({
    isAtBottom: true,
    scrollToBottom: vi.fn(),
    onScrollToBottom: vi.fn(() => () => {})
  })
}));

vi.mock('../../../utils/hooks/useOnResizeContent', () => ({
  useOnResizeContent: vi.fn()
}));

vi.mock('../../../utils/hooks/useOnScrollToBottom', () => ({
  useOnScrollToBottom: vi.fn()
}));

describe('useThreadViewportAutoScroll', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should return a ref for the element', () => {
    const elementRef = useThreadViewportAutoScroll();
    expect(elementRef).toBeDefined();
    expect(elementRef.value).toBeUndefined();
  });

  it('should accept autoScroll option', () => {
    const elementRef = useThreadViewportAutoScroll({ autoScroll: false });
    expect(elementRef).toBeDefined();
  });

  it('should handle element assignment', () => {
    const elementRef = useThreadViewportAutoScroll();
    const mockElement = document.createElement('div');
    elementRef.value = mockElement as any;
    expect(elementRef.value).toBe(mockElement);
  });

  it('should scroll to bottom when autoScroll is enabled', () => {
    const elementRef = useThreadViewportAutoScroll({ autoScroll: true });
    const mockElement = document.createElement('div');
    
    // Mock scrollTo method
    mockElement.scrollTo = vi.fn();
    Object.defineProperty(mockElement, 'scrollHeight', {
      value: 1000,
      writable: true
    });
    
    elementRef.value = mockElement as any;
    
    // Trigger scroll to bottom via element's scrollTo
    expect(mockElement.scrollTo).toBeDefined();
  });

  it('should not scroll when autoScroll is disabled', () => {
    const elementRef = useThreadViewportAutoScroll({ autoScroll: false });
    const mockElement = document.createElement('div');
    
    mockElement.scrollTo = vi.fn();
    elementRef.value = mockElement as any;
    
    // scrollTo should not be called when autoScroll is false
    expect(mockElement.scrollTo).not.toHaveBeenCalled();
  });

  it('should handle scroll events', () => {
    const elementRef = useThreadViewportAutoScroll();
    const mockElement = document.createElement('div');
    
    const addEventListenerSpy = vi.spyOn(mockElement, 'addEventListener');
    elementRef.value = mockElement as any;
    
    // Should add scroll event listener
    expect(addEventListenerSpy).toHaveBeenCalledWith('scroll', expect.any(Function));
  });

  it('should clean up event listeners on unmount', () => {
    const elementRef = useThreadViewportAutoScroll();
    const mockElement = document.createElement('div');
    
    const removeEventListenerSpy = vi.spyOn(mockElement, 'removeEventListener');
    elementRef.value = mockElement as any;
    
    // Change element to trigger cleanup
    elementRef.value = undefined;
    
    // Should remove scroll event listener
    expect(removeEventListenerSpy).toHaveBeenCalledWith('scroll', expect.any(Function));
  });
});