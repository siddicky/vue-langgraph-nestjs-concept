import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useAssistantRuntime } from '../../composables/useAssistantRuntime';
import { inject } from 'vue';

vi.mock('vue', async () => {
  const actual = await vi.importActual('vue');
  return {
    ...actual,
    inject: vi.fn()
  };
});

describe('useAssistantRuntime', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns assistant runtime when available', () => {
    const mockRuntime = {
      thread: {
        getState: vi.fn(),
        subscribe: vi.fn()
      },
      switchToNewThread: vi.fn(),
      registerModelConfigProvider: vi.fn(),
      switchToThread: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockRuntime }
    });

    const result = useAssistantRuntime();
    expect(result.value).toBe(mockRuntime);
  });

  it('throws error when no runtime available', () => {
    (inject as any).mockReturnValue(null);

    expect(() => useAssistantRuntime()).toThrow(
      'AssistantRuntime not provided. Make sure to use AssistantRuntimeProvider in a parent component.'
    );
  });



  it('returns runtime from context value', () => {
    const mockRuntime = {
      thread: {
        getState: vi.fn().mockReturnValue({
          threadId: 'test-thread',
          messages: []
        }),
        subscribe: vi.fn()
      },
      threads: {
        getState: vi.fn(),
        subscribe: vi.fn()
      },
      switchToNewThread: vi.fn(),
      registerModelConfigProvider: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockRuntime }
    });

    const runtime = useAssistantRuntime();
    
    expect(runtime.value).toBe(mockRuntime);
    expect(runtime.value.thread.getState).toBeDefined();
    expect(runtime.value.switchToNewThread).toBeDefined();
  });

  it('handles different runtime configurations', () => {
    const minimalRuntime = {
      thread: {
        getState: vi.fn(),
        subscribe: vi.fn()
      }
    };

    (inject as any).mockReturnValue({
      runtime: { value: minimalRuntime }
    });

    const runtime = useAssistantRuntime();
    expect(runtime.value).toBe(minimalRuntime);
    expect(runtime.value.thread).toBeDefined();
  });
});