import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import { defineComponent, nextTick, computed } from 'vue';
import { useThread } from '../../composables/thread/useThreadContext';
import { THREAD_RUNTIME_KEY } from '../../context/keys';
import type { ThreadRuntime } from '../../api';

describe('useThread', () => {
  const createMockThreadRuntime = (state: any = {}) => {
    const subscribers: Function[] = [];
    
    return {
      getState: vi.fn(() => ({
        isRunning: false,
        isDisabled: false,
        messages: [],
        ...state,
      })),
      subscribe: vi.fn((callback: Function) => {
        subscribers.push(callback);
        return () => {
          const index = subscribers.indexOf(callback);
          if (index > -1) subscribers.splice(index, 1);
        };
      }),
      _notifySubscribers: () => {
        subscribers.forEach(cb => cb());
      },
    } as unknown as ThreadRuntime;
  };

  it('returns thread state from context', () => {
    const mockRuntime = createMockThreadRuntime({
      isRunning: true,
      messages: [
        { id: '1', role: 'user', content: [{ type: 'text', text: 'Hello' }] }
      ]
    });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        return { thread };
      },
      template: '<div>{{ thread.isRunning }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('true');
  });

  it('updates when thread state changes', async () => {
    const mockRuntime = createMockThreadRuntime({ isRunning: false });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        return { thread };
      },
      template: '<div>{{ thread.isRunning }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('false');

    // Update state
    mockRuntime.getState = vi.fn(() => ({ 
      threadId: 'test-thread',
      metadata: { 
        id: 'test-thread', 
        title: 'Test Thread',
        isMain: false,
        remoteId: undefined,
        externalId: undefined,
        threadId: 'test-thread',
        status: 'regular' as const
      },
      isRunning: true, 
      messages: [],
      isDisabled: false,
      isLoading: false,
      capabilities: {
        edit: true,
        reload: true,
        speak: false,
        unstable_copy: true,
        cancel: true,
        feedback: false,
        switchToBranch: false,
        speech: false,
        attachments: false
      },
      state: {},
      suggestions: [],
      extras: undefined,
      speech: undefined
    }));
    (mockRuntime as any)._notifySubscribers();
    
    await nextTick();
    expect(wrapper.text()).toBe('true');
  });

  it('applies selector function when provided', () => {
    const mockRuntime = createMockThreadRuntime({
      messages: [
        { id: '1', role: 'user', content: [{ type: 'text', text: 'Hello' }] },
        { id: '2', role: 'assistant', content: [{ type: 'text', text: 'Hi there' }] }
      ]
    });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        const messageCount = computed(() => thread.value?.messages?.length ?? 0);
        return { messageCount };
      },
      template: '<div>{{ messageCount }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('2');
  });

  it('returns undefined when optional and no context', () => {
    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        return { thread };
      },
      template: '<div>{{ thread === undefined ? "undefined" : "defined" }}</div>'
    });

    const wrapper = mount(TestComponent);
    expect(wrapper.text()).toBe('undefined');
  });

  it('handles empty message list correctly', () => {
    const mockRuntime = createMockThreadRuntime({
      messages: []
    });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        const hasMessages = computed(() => (thread.value?.messages?.length ?? 0) > 0);
        return { hasMessages };
      },
      template: '<div>{{ hasMessages }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('false');
  });

  it('tracks loading state changes', async () => {
    const mockRuntime = createMockThreadRuntime({ isLoading: true });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        return { thread };
      },
      template: '<div>{{ thread.isLoading }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('true');

    // Update loading state
    mockRuntime.getState = vi.fn(() => ({
      threadId: 'test-thread',
      metadata: {
        id: 'test-thread',
        title: 'Test Thread',
        isMain: false,
        remoteId: undefined,
        externalId: undefined,
        threadId: 'test-thread',
        status: 'regular' as const
      },
      isLoading: false,
      isRunning: false,
      isDisabled: false,
      messages: [],
      capabilities: {
        switchToBranch: false,
        edit: false,
        reload: false,
        cancel: false,
        unstable_copy: false,
        speech: false,
        attachments: false,
        feedback: false
      },
      state: {},
      suggestions: [],
      extras: undefined,
      speech: undefined
    }));
    (mockRuntime as any)._notifySubscribers();
    
    await nextTick();
    expect(wrapper.text()).toBe('false');
  });

  it('handles thread capabilities correctly', () => {
    const mockRuntime = createMockThreadRuntime({
      capabilities: {
        edit: true,
        reload: false,
        cancel: true,
        attachments: true
      }
    });

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        const canEdit = computed(() => thread.value?.capabilities?.edit);
        const canReload = computed(() => thread.value?.capabilities?.reload);
        return { canEdit, canReload };
      },
      template: '<div>edit:{{ canEdit }} reload:{{ canReload }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(wrapper.text()).toBe('edit:true reload:false');
  });

  it('unsubscribes on component unmount', () => {
    const mockRuntime = createMockThreadRuntime();
    const unsubscribeSpy = vi.fn();
    mockRuntime.subscribe = vi.fn(() => unsubscribeSpy);

    const TestComponent = defineComponent({
      setup() {
        const thread = useThread();
        return { thread };
      },
      template: '<div>test</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockRuntime }
        }
      }
    });

    expect(mockRuntime.subscribe).toHaveBeenCalledTimes(1);
    
    wrapper.unmount();
    expect(unsubscribeSpy).toHaveBeenCalledTimes(1);
  });
});