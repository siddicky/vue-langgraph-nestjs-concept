import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';
import { inject } from 'vue';

vi.mock('vue', async () => {
  const actual = await vi.importActual('vue');
  return {
    ...actual,
    inject: vi.fn()
  };
});

describe('useThreadRuntime', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns thread runtime when available in thread context', () => {
    const mockThreadRuntime = {
      getState: vi.fn().mockReturnValue({
        threadId: 'test-thread',
        messages: [],
        isRunning: false
      }),
      subscribe: vi.fn(),
      append: vi.fn(),
      startRun: vi.fn(),
      cancelRun: vi.fn()
    };

    // First call for THREAD_CONTEXT_KEY
    (inject as any).mockReturnValueOnce({
      runtime: { value: mockThreadRuntime }
    });

    const result = useThreadRuntime();
    expect(result).toBe(mockThreadRuntime);
  });

  it('returns thread runtime from assistant context when thread context not available', () => {
    const mockThreadRuntime = {
      getState: vi.fn().mockReturnValue({
        threadId: 'assistant-thread',
        messages: []
      }),
      subscribe: vi.fn(),
      append: vi.fn()
    };

    const mockAssistantRuntime = {
      thread: mockThreadRuntime
    };

    // First call returns null (no thread context)
    (inject as any).mockReturnValueOnce(null);
    // Second call returns assistant context
    (inject as any).mockReturnValueOnce({
      runtime: { value: mockAssistantRuntime }
    });

    const result = useThreadRuntime();
    expect(result).toBe(mockThreadRuntime);
  });

  it('returns null when optional and no runtime available', () => {
    (inject as any).mockReturnValue(null);

    const result = useThreadRuntime({ optional: true });
    expect(result).toBeNull();
  });

  it('throws error when required and no runtime available', () => {
    (inject as any).mockReturnValue(null);

    expect(() => useThreadRuntime()).toThrow(
      'useThreadRuntime: thread runtime not available'
    );
  });

  it('throws error when assistant runtime has no thread', () => {
    const mockAssistantRuntime = {
      // No thread property
      switchToNewThread: vi.fn()
    };

    // First call returns null (no thread context)
    (inject as any).mockReturnValueOnce(null);
    // Second call returns assistant context without thread
    (inject as any).mockReturnValueOnce({
      runtime: { value: mockAssistantRuntime }
    });

    expect(() => useThreadRuntime()).toThrow(
      'useThreadRuntime: thread runtime not available'
    );
  });

  it('handles thread runtime with all capabilities', () => {
    const fullThreadRuntime = {
      getState: vi.fn().mockReturnValue({
        threadId: 'full-thread',
        messages: [],
        isRunning: false,
        capabilities: {
          edit: true,
          reload: true,
          cancel: true,
          speak: true
        }
      }),
      subscribe: vi.fn(),
      append: vi.fn(),
      startRun: vi.fn(),
      cancelRun: vi.fn(),
      composer: {
        getState: vi.fn(),
        subscribe: vi.fn()
      }
    };

    (inject as any).mockReturnValueOnce({
      runtime: { value: fullThreadRuntime }
    });

    const runtime = useThreadRuntime();
    
    expect(runtime.value).toBe(fullThreadRuntime);
    expect(runtime.value.composer).toBeDefined();
    expect(runtime.value.append).toBeDefined();
    expect(runtime.value.startRun).toBeDefined();
  });

  it('prefers thread context over assistant context', () => {
    const threadContextRuntime = {
      getState: vi.fn().mockReturnValue({ threadId: 'thread-context' }),
      subscribe: vi.fn()
    };

    const assistantContextRuntime = {
      thread: {
        getState: vi.fn().mockReturnValue({ threadId: 'assistant-context' }),
        subscribe: vi.fn()
      }
    };

    // Thread context is available
    (inject as any).mockReturnValueOnce({
      runtime: { value: threadContextRuntime }
    });
    // Assistant context also available but should not be used
    (inject as any).mockReturnValueOnce({
      runtime: { value: assistantContextRuntime }
    });

    const result = useThreadRuntime();
    expect(result.value).toBe(threadContextRuntime);
    expect(result.value.getState().threadId).toBe('thread-context');
  });
});