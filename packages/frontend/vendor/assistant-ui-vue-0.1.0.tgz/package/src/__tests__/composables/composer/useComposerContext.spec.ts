import { describe, it, expect, vi, beforeEach } from 'vitest';
import { useComposerContext, useComposer } from '../../../composables/composer/useComposerContext';
import { inject } from 'vue';

vi.mock('vue', async () => {
  const actual = await vi.importActual('vue');
  return {
    ...actual,
    inject: vi.fn(),
    computed: vi.fn((fn) => ({ value: fn() }))
  };
});

describe('useComposerContext', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns composer context when available', () => {
    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue({
        type: 'thread',
        text: 'Hello world',
        attachments: [],
        canSend: true,
        canCancel: false,
        isEditing: false,
        isEmpty: false,
        role: 'user',
        runConfig: {}
      }),
      subscribe: vi.fn(),
      setText: vi.fn(),
      send: vi.fn(),
      cancel: vi.fn(),
      addAttachment: vi.fn(),
      removeAttachment: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const result = useComposerContext();
    
    expect(result).toBeDefined();
    expect(result?.composerRuntime).toBe(mockComposerRuntime);
    expect(result?.composer).toBeDefined();
  });

  it('returns null when optional and no context available', () => {
    (inject as any).mockReturnValue(null);

    const result = useComposerContext({ optional: true });
    expect(result).toBeNull();
  });

  it('throws error when required and no context available', () => {
    (inject as any).mockReturnValue(null);

    expect(() => useComposerContext()).toThrow(
      'useComposerContext must be used within a ComposerProvider'
    );
  });

  it('returns computed composer state', () => {
    const composerState = {
      type: 'thread',
      text: 'Test message',
      attachments: [
        { id: 'att-1', type: 'file', name: 'test.pdf', status: { type: 'pending' } }
      ],
      canSend: false,
      canCancel: true,
      isEditing: false,
      isEmpty: false,
      role: 'user',
      runConfig: { temperature: 0.7 }
    };

    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue(composerState),
      subscribe: vi.fn(),
      setText: vi.fn(),
      send: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const context = useComposerContext();
    
    expect(context?.composer.value).toEqual(composerState);
    expect(context?.composer.value?.text).toBe('Test message');
    expect(context?.composer.value?.attachments).toHaveLength(1);
    expect(context?.composer.value?.canCancel).toBe(true);
  });

  it('handles edit composer state', () => {
    const editComposerState = {
      type: 'edit',
      text: 'Edited message',
      attachments: [],
      canSend: true,
      canCancel: true,
      isEditing: true,
      isEmpty: false,
      role: 'user',
      runConfig: {}
    };

    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue(editComposerState),
      subscribe: vi.fn(),
      setText: vi.fn(),
      send: vi.fn(),
      cancel: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const context = useComposerContext();
    
    expect(context?.composer.value?.type).toBe('edit');
    expect(context?.composer.value?.isEditing).toBe(true);
  });
});

describe('useComposer', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns composer state with selector', () => {
    const composerState = {
      type: 'thread',
      text: 'Message text',
      attachments: [],
      canSend: true,
      canCancel: false,
      isEditing: false,
      isEmpty: false,
      role: 'user',
      runConfig: {}
    };

    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue(composerState),
      subscribe: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const selector = (state: any) => state.text;
    const result = useComposer(selector);
    
    expect(result.value).toBe('Message text');
  });

  it('returns full composer state without selector', () => {
    const composerState = {
      type: 'thread',
      text: 'Full state',
      attachments: [],
      canSend: true,
      canCancel: false,
      isEditing: false,
      isEmpty: false,
      role: 'user',
      runConfig: {}
    };

    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue(composerState),
      subscribe: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const result = useComposer();
    
    expect(result.value).toEqual(composerState);
  });

  it('returns undefined when optional and no context', () => {
    (inject as any).mockReturnValue(null);

    const result = useComposer(undefined);
    expect(result.value).toBeUndefined();
  });

  it('throws error when required and no context', () => {
    (inject as any).mockReturnValue(null);

    expect(() => useComposer()).toThrow(
      'useComposerContext must be used within a ComposerProvider'
    );
  });

  it('applies selector correctly', () => {
    const composerState = {
      type: 'thread',
      text: 'Test',
      attachments: [
        { id: '1', type: 'file', name: 'doc1.pdf' },
        { id: '2', type: 'file', name: 'doc2.pdf' }
      ],
      canSend: true,
      canCancel: false,
      isEditing: false,
      isEmpty: false,
      role: 'user',
      runConfig: {}
    };

    const mockComposerRuntime = {
      getState: vi.fn().mockReturnValue(composerState),
      subscribe: vi.fn()
    };

    (inject as any).mockReturnValue({
      runtime: { value: mockComposerRuntime }
    });

    const selector = (state: any) => state.attachments.length;
    const result = useComposer(selector);
    
    expect(result.value).toBe(2);
  });
});