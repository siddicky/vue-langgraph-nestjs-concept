import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import { defineComponent, nextTick } from 'vue';
import { useComposer } from '../../composables/composer/useComposerContext';
import { MESSAGE_RUNTIME_KEY, THREAD_RUNTIME_KEY } from '../../context/keys';
import type { MessageRuntime, ThreadRuntime, ComposerRuntime } from '../../api';

describe('useComposer', () => {
  const createMockComposerRuntime = (state: any = {}) => {
    const subscribers: Function[] = [];
    
    return {
      getState: vi.fn(() => ({
        text: '',
        attachments: [],
        canSend: false,
        isEditing: false,
        isEmpty: true,
        ...state,
      })),
      subscribe: vi.fn((callback: Function) => {
        subscribers.push(callback);
        return () => {
          const index = subscribers.indexOf(callback);
          if (index > -1) subscribers.splice(index, 1);
        };
      }),
      setText: vi.fn(),
      send: vi.fn(),
      cancel: vi.fn(),
      addAttachment: vi.fn(),
      removeAttachment: vi.fn(),
      _notifySubscribers: () => {
        subscribers.forEach(cb => cb());
      },
    } as unknown as ComposerRuntime;
  };

  const createMockThreadRuntime = (composer: any) => ({
    composer,
    getState: vi.fn(() => ({ isRunning: false, messages: [] })),
    subscribe: vi.fn(() => () => {}),
  } as unknown as ThreadRuntime);

  it('returns composer state from thread context', () => {
    const mockComposer = createMockComposerRuntime({
      text: 'Hello world',
      canSend: true,
      isEmpty: false,
    });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.text }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('Hello world');
  });

  it('updates when composer state changes', async () => {
    const mockComposer = createMockComposerRuntime({ text: 'Initial' });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.text }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('Initial');

    // Update state
    mockComposer.getState = vi.fn(() => ({ 
      text: 'Updated',
      attachments: [],
      canSend: true,
      isEmpty: false,
      canCancel: false,
      isEditing: true,
      type: 'thread' as const,
      role: 'user' as const,
      runConfig: {}
    }));
    (mockComposer as any)._notifySubscribers();
    
    await nextTick();
    expect(wrapper.text()).toBe('Updated');
  });

  it('handles attachment operations', async () => {
    const mockComposer = createMockComposerRuntime({
      attachments: [{ id: '1', type: 'image', name: 'test.jpg' }]
    });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.attachments?.length }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('1');

    // Add attachment
    mockComposer.getState = vi.fn(() => ({
      type: 'thread' as const,
      text: '',
      attachments: [
        { id: '1', type: 'image' as const, name: 'test.jpg', contentType: 'image/jpeg' },
        { id: '2', type: 'file' as const, name: 'doc.pdf', contentType: 'application/pdf' }
      ],
      canSend: true,
      isEmpty: false,
      canCancel: false,
      isEditing: false,
      role: 'user' as const,
      runConfig: {}
    }));
    (mockComposer as any)._notifySubscribers();
    
    await nextTick();
    expect(wrapper.text()).toBe('2');
  });

  it('tracks canSend state correctly', () => {
    const mockComposer = createMockComposerRuntime({
      text: 'Message',
      canSend: true,
      isEmpty: false
    });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.canSend }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('true');
    expect(mockComposer.send).toBeDefined();
  });

  it('handles editing state correctly', async () => {
    const mockComposer = createMockComposerRuntime({
      isEditing: false
    });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.isEditing }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('false');

    // Start editing
    mockComposer.getState = vi.fn(() => ({
      type: 'edit' as const,
      text: 'Editing message',
      isEditing: true,
      canCancel: true,
      attachments: [],
      canSend: false,
      isEmpty: false,
      role: 'user' as const,
      runConfig: {}
    }));
    (mockComposer as any)._notifySubscribers();
    
    await nextTick();
    expect(wrapper.text()).toBe('true');
  });

  it('applies selector function when provided', () => {
    const mockComposer = createMockComposerRuntime({
      text: 'Test message',
      attachments: [{ id: '1', type: 'image' }, { id: '2', type: 'file' }],
    });
    const mockThread = createMockThreadRuntime(mockComposer);

    const TestComponent = defineComponent({
      setup() {
        const attachmentCount = useComposer((state) => state?.attachments?.length ?? 0);
        return { attachmentCount };
      },
      template: '<div>{{ attachmentCount }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread }
        }
      }
    });

    expect(wrapper.text()).toBe('2');
  });

  it('prioritizes message composer over thread composer', () => {
    const mockThreadComposer = createMockComposerRuntime({ text: 'Thread composer' });
    const mockEditComposer = createMockComposerRuntime({ text: 'Edit composer' });
    const mockThread = createMockThreadRuntime(mockThreadComposer);
    
    const mockMessage = {
      composer: mockEditComposer,
      getState: vi.fn(() => ({ role: 'user' })),
      subscribe: vi.fn(() => () => {}),
    } as unknown as MessageRuntime;

    const TestComponent = defineComponent({
      setup() {
        const composer = useComposer();
        return { composer };
      },
      template: '<div>{{ composer?.text }}</div>'
    });

    const wrapper = mount(TestComponent, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY]: { value: mockThread },
          [MESSAGE_RUNTIME_KEY]: { value: mockMessage }
        }
      }
    });

    expect(wrapper.text()).toBe('Edit composer');
  });
});