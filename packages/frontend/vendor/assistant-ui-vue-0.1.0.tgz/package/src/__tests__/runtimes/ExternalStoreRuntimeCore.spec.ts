import { describe, it, expect, vi, beforeEach } from 'vitest';
import { ExternalStoreRuntimeCore } from '../../runtimes/external-store/ExternalStoreRuntimeCore';
import type { ExternalStoreAdapter } from '../../runtimes/external-store/ExternalStoreAdapter';
import type { ThreadMessageLike } from '../../runtimes/external-store/ThreadMessageLike';

describe('ExternalStoreRuntimeCore', () => {
  let mockAdapter: ExternalStoreAdapter<ThreadMessageLike>;
  let runtime: ExternalStoreRuntimeCore;
  let mockMessages: ThreadMessageLike[];

  beforeEach(() => {
    // Setup mock messages
    mockMessages = [
      {
        id: '1',
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }],
        createdAt: new Date('2024-01-01T10:00:00Z')
      },
      {
        id: '2',
        role: 'assistant',
        content: [{ type: 'text', text: 'Hi there!' }],
        createdAt: new Date('2024-01-01T10:01:00Z')
      }
    ];

    // Create mock adapter
    mockAdapter = {
      messages: mockMessages,
      isDisabled: false,
      isRunning: false,
      convertMessage: vi.fn((msg: ThreadMessageLike) => ({
        ...msg,
        attachments: msg.attachments || [],
        metadata: msg.metadata || {}
      })),
      onNew: vi.fn(),
      onEdit: vi.fn(),
      onReload: vi.fn(),
      onCancel: vi.fn(),
      onAddToolResult: vi.fn(),
      subscribe: vi.fn(() => () => {})
    } as any;

    runtime = new ExternalStoreRuntimeCore(mockAdapter);
  });

  it('initializes with correct structure', () => {
    expect(runtime.threads).toBeDefined();
    expect(runtime).toBeInstanceOf(ExternalStoreRuntimeCore);
  });

  it('can get main thread runtime core', () => {
    const threadRuntimeCore = runtime.threads.getMainThreadRuntimeCore();
    expect(threadRuntimeCore).toBeDefined();
  });

  it('handles adapter updates', () => {
    const newAdapter = {
      messages: [],
      isDisabled: true,
      isRunning: false,
      convertMessage: vi.fn((msg: ThreadMessageLike) => ({
        ...msg,
        attachments: msg.attachments || [],
        metadata: msg.metadata || {}
      })),
      onNew: vi.fn(),
      onEdit: vi.fn(),
      onReload: vi.fn(),
      onCancel: vi.fn(),
      onAddToolResult: vi.fn(),
      subscribe: vi.fn(() => () => {})
    } as any;

    runtime.setAdapter(newAdapter);
    expect(runtime.threads).toBeDefined();
  });

  it('handles empty message state', () => {
    const emptyAdapter = {
      ...mockAdapter,
      messages: []
    } as any;
    
    const emptyRuntime = new ExternalStoreRuntimeCore(emptyAdapter);
    expect(emptyRuntime.threads).toBeDefined();
  });

  it('handles disabled state', () => {
    const disabledAdapter = {
      ...mockAdapter,
      isDisabled: true
    } as any;
    
    const disabledRuntime = new ExternalStoreRuntimeCore(disabledAdapter);
    expect(disabledRuntime.threads).toBeDefined();
  });

  it('handles running state', () => {
    const runningAdapter = {
      ...mockAdapter,
      isRunning: true
    } as any;
    
    const runningRuntime = new ExternalStoreRuntimeCore(runningAdapter);
    expect(runningRuntime.threads).toBeDefined();
  });

  it('handles messages with attachments', () => {
    const messagesWithAttachments = [
      {
        id: '1',
        role: 'user' as const,
        content: [{ type: 'text' as const, text: 'Check this file' }],
        attachments: [
          {
            id: 'att-1',
            type: 'file' as const,
            name: 'document.pdf',
            contentType: 'application/pdf',
            size: 1024
          }
        ],
        createdAt: new Date('2024-01-01T10:00:00Z')
      }
    ];
    
    const adapterWithAttachments = {
      ...mockAdapter,
      messages: messagesWithAttachments
    } as any;
    
    const runtimeWithAttachments = new ExternalStoreRuntimeCore(adapterWithAttachments);
    expect(runtimeWithAttachments.threads).toBeDefined();
  });

  it('provides thread runtime functionality', () => {
    // Thread runtime has the actual functionality
    const threadCore = runtime.threads.getMainThreadRuntimeCore();
    expect(threadCore).toBeDefined();
  });

  it('handles adapter with thread list', () => {
    const adapterWithThreadList = {
      ...mockAdapter,
      adapters: {
        threadList: {
          threads: [],
          subscribe: vi.fn(() => () => {})
        }
      }
    } as any;
    
    const runtimeWithThreadList = new ExternalStoreRuntimeCore(adapterWithThreadList);
    expect(runtimeWithThreadList.threads).toBeDefined();
  });
});