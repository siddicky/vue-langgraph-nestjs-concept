import { describe, it, expect, vi, beforeEach } from 'vitest';
import { LocalRuntimeCore } from '../../runtimes/local/LocalRuntimeCore';
import type { ChatModelAdapter } from '../../runtimes/local/ChatModelAdapter';
import type { LocalRuntimeOptionsBase } from '../../runtimes/local/LocalRuntimeOptions';

describe('LocalRuntimeCore', () => {
  let mockAdapter: ChatModelAdapter;
  let runtime: LocalRuntimeCore;
  let options: LocalRuntimeOptionsBase;

  beforeEach(() => {
    // Create mock adapter
    mockAdapter = {
      run: vi.fn(() => {
        return (async function* () {
          yield {
            content: [{ type: 'text' as const, text: 'Test response' }],
            status: { type: 'running' as const }
          };
          yield {
            content: [{ type: 'text' as const, text: 'Test response complete' }],
            status: { type: 'complete' as const, reason: 'stop' as const }
          };
        })();
      })
    } as ChatModelAdapter;

    options = {
      adapters: {
        chatModel: mockAdapter
      }
    };

    runtime = new LocalRuntimeCore(options, undefined);
  });

  it('initializes with correct structure', () => {
    expect(runtime.threads).toBeDefined();
    expect(runtime).toBeInstanceOf(LocalRuntimeCore);
  });

  it('can get main thread runtime core', () => {
    const threadRuntimeCore = runtime.threads.getMainThreadRuntimeCore();
    expect(threadRuntimeCore).toBeDefined();
  });

  it('handles initial messages correctly', () => {
    const initialMessages = [
      {
        id: '1',
        role: 'user' as const,
        content: [{ type: 'text' as const, text: 'Hello' }],
        createdAt: new Date()
      },
      {
        id: '2',
        role: 'assistant' as const,
        content: [{ type: 'text' as const, text: 'Hi there!' }],
        createdAt: new Date()
      }
    ];

    const runtimeWithMessages = new LocalRuntimeCore(options, initialMessages);

    const threadCore = runtimeWithMessages.threads.getMainThreadRuntimeCore();
    expect(threadCore).toBeDefined();
  });

  it('provides thread runtime functionality', () => {
    // Thread runtime has the actual functionality
    const threadCore = runtime.threads.getMainThreadRuntimeCore();
    expect(threadCore).toBeDefined();
  });

  it('initializes with undefined Provider', () => {
    expect(runtime.Provider).toBeUndefined();
  });

  it('handles empty initial messages', () => {
    const runtimeNoMessages = new LocalRuntimeCore(options, []);
    expect(runtimeNoMessages.threads).toBeDefined();
  });

  it('handles undefined initial messages', () => {
    const runtimeUndefinedMessages = new LocalRuntimeCore(options, undefined);
    expect(runtimeUndefinedMessages.threads).toBeDefined();
  });

  it('can create multiple thread instances', () => {
    const thread1 = runtime.threads.getMainThreadRuntimeCore();
    const thread2 = runtime.threads.getMainThreadRuntimeCore();
    
    // Should return the same main thread
    expect(thread1).toBe(thread2);
  });

  it('provides access to thread list runtime', () => {
    expect(runtime.threads).toBeDefined();
    expect(runtime.threads.getMainThreadRuntimeCore).toBeDefined();
    expect(runtime.threads.getMainThreadRuntimeCore).toBeDefined();
  });

  it('handles error states properly', async () => {
    const errorAdapter: ChatModelAdapter = {
      run: vi.fn(() => {
        return (async function* () {
          throw new Error('Test error');
        })();
      })
    } as ChatModelAdapter;

    const errorRuntime = new LocalRuntimeCore({ adapters: { chatModel: errorAdapter } }, undefined);
    
    // Runtime should still initialize correctly even with error-prone adapter
    expect(errorRuntime.threads).toBeDefined();
  });

  it('respects maxSteps option', () => {
    const limitedOptions: LocalRuntimeOptionsBase = {
      adapters: {
        chatModel: mockAdapter
      },
      maxSteps: 3
    };

    const limitedRuntime = new LocalRuntimeCore(limitedOptions, undefined);

    // This would test that the runtime initializes correctly with options
    expect(limitedRuntime.threads).toBeDefined();
  });

  it('handles initial messages with attachments', () => {
    const messagesWithAttachments = [
      {
        id: '1',
        role: 'user' as const,
        content: [{ type: 'text' as const, text: 'Check this file' }],
        attachments: [] as any,
        createdAt: new Date()
      }
    ];

    const runtimeWithAttachments = new LocalRuntimeCore(options, messagesWithAttachments);
    expect(runtimeWithAttachments.threads).toBeDefined();
  });
});