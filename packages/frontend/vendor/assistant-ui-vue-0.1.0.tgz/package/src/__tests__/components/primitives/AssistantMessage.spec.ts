import { mount } from '@vue/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import AssistantMessage from '../../../components/primitives/message/AssistantMessage.vue';
import { useMessageContext } from '../../../composables/message/useMessageContext';
import { useMessagePartContext } from '../../../composables/messagePart/useMessagePartContext';
import { MessagePartStatus } from '../../../types';

vi.mock('../../../composables/message/useMessageContext');
vi.mock('../../../composables/messagePart/useMessagePartContext');
vi.mock('../../../components/ui/MarkdownText.vue', () => ({
  default: {
    name: 'MarkdownText',
    props: ['text'],
    template: '<div class="markdown-text">{{ text }}</div>'
  }
}));

describe('AssistantMessage', () => {
  const mockMessageContext = {
    message: {
      id: 'msg-1',
      role: 'assistant',
      content: []
    },
    isLast: false
  };

  const mockMessagePartContext = {
    part: {
      type: 'text',
      text: 'Hello! How can I help you today?'
    },
    status: { type: 'complete' } as MessagePartStatus,
    isLoading: false
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useMessageContext as any).mockReturnValue(mockMessageContext);
    (useMessagePartContext as any).mockReturnValue(mockMessagePartContext);
  });

  it('renders assistant message text content', () => {
    const wrapper = mount(AssistantMessage);
    expect(wrapper.text()).toContain('Hello! How can I help you today?');
  });

  it('renders markdown content through MarkdownText component', () => {
    const wrapper = mount(AssistantMessage);
    expect(wrapper.find('.markdown-text').exists()).toBe(true);
  });

  it('applies correct CSS class', () => {
    const wrapper = mount(AssistantMessage);
    expect(wrapper.classes()).toContain('aui-assistant-message-text');
  });

  it('renders with custom class', () => {
    const wrapper = mount(AssistantMessage, {
      attrs: {
        class: 'custom-assistant-class'
      }
    });
    expect(wrapper.classes()).toContain('custom-assistant-class');
    expect(wrapper.classes()).toContain('aui-assistant-message-text');
  });

  it('renders loading state', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      isLoading: true,
      part: {
        type: 'text',
        text: 'Typing...'
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.text()).toContain('Typing...');
  });

  it('renders error state', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      status: { type: 'error', error: 'Generation failed' }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders markdown formatting', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: '**Bold text** and *italic text* with `code`'
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.find('.markdown-text').text()).toContain('**Bold text** and *italic text* with `code`');
  });

  it('renders code blocks', () => {
    const codeContent = '```javascript\nconst hello = "world";\nconsole.log(hello);\n```';
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: codeContent
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.find('.markdown-text').text()).toContain(codeContent);
  });

  it('renders lists', () => {
    const listContent = '- Item 1\n- Item 2\n- Item 3';
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: listContent
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.find('.markdown-text').text()).toContain(listContent);
  });

  it('renders with slot content', () => {
    const wrapper = mount(AssistantMessage, {
      slots: {
        default: '<div class="custom-assistant">Custom assistant content</div>'
      }
    });
    
    expect(wrapper.find('.custom-assistant').exists()).toBe(true);
    expect(wrapper.text()).toContain('Custom assistant content');
  });

  it('passes through additional props', () => {
    const wrapper = mount(AssistantMessage, {
      props: {
        'data-testid': 'assistant-message'
      }
    });
    
    expect(wrapper.attributes('data-testid')).toBe('assistant-message');
  });

  it('renders empty text gracefully', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: ''
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.find('.markdown-text').text()).toBe('');
  });

  it('renders streaming text', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      status: { type: 'in_progress' },
      part: {
        type: 'text',
        text: 'This is being streamed...'
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.text()).toContain('This is being streamed...');
  });

  it('handles long messages', () => {
    const longText = 'This is a very long assistant response. '.repeat(100);
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: longText
      }
    });
    
    const wrapper = mount(AssistantMessage);
    expect(wrapper.find('.markdown-text').text()).toContain(longText);
  });
});