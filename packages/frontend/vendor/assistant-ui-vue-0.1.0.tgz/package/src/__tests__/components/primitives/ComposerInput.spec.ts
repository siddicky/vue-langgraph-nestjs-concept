import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import ComposerInput from '../../../components/primitives/composer/ComposerInput.vue';
import { THREAD_RUNTIME_KEY } from '../../../context/keys';
import type { ComposerRuntime, ThreadRuntime } from '../../../api';

describe('ComposerInput', () => {
  const mockComposerRuntime = {
    getState: vi.fn(() => ({
      text: 'Initial text',
      attachments: [],
      canSend: true
    })),
    subscribe: vi.fn(() => () => {}),
    setText: vi.fn(),
    send: vi.fn(),
    cancel: vi.fn(),
    addAttachment: vi.fn(),
    removeAttachment: vi.fn()
  } as unknown as ComposerRuntime;

  const mockThreadRuntime = {
    composer: mockComposerRuntime,
    getState: vi.fn(() => ({
      isRunning: false,
      isDisabled: false,
      messages: [],
      capabilities: {
        edit: true,
        reload: true,
        speak: false,
        unstable_copy: true,
        cancel: true,
        feedback: false
      }
    })),
    subscribe: vi.fn(() => () => {})
  } as unknown as ThreadRuntime;

  it('renders a textarea element', () => {
    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    expect(wrapper.find('textarea').exists()).toBe(true);
  });

  it('displays initial text from composer state', () => {
    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    expect(textarea.element.value).toBe('Initial text');
  });

  it('updates composer text on input', async () => {
    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    await textarea.setValue('New text');

    expect(mockComposerRuntime.setText).toHaveBeenCalledWith('New text');
  });

  it('sends message on Enter key', async () => {
    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    await textarea.trigger('keydown', { key: 'Enter' });

    expect(mockComposerRuntime.send).toHaveBeenCalled();
  });

  it('does not send on Enter with Shift key', async () => {
    (mockComposerRuntime.send as any).mockClear();
    
    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    await textarea.trigger('keydown', { key: 'Enter', shiftKey: true });

    expect(mockComposerRuntime.send).not.toHaveBeenCalled();
  });

  it('applies placeholder prop', () => {
    const wrapper = mount(ComposerInput, {
      props: {
        placeholder: 'Type your message...'
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    expect(textarea.attributes('placeholder')).toBe('Type your message...');
  });

  it('applies autoFocus prop', () => {
    const wrapper = mount(ComposerInput, {
      props: {
        autoFocus: true
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    expect(textarea.attributes('autofocus')).toBeDefined();
  });

  it('is disabled when thread is disabled', () => {
    const disabledThreadRuntime = {
      ...mockThreadRuntime,
      getState: vi.fn(() => ({
        isRunning: false,
        isDisabled: true,
        messages: [],
        capabilities: mockThreadRuntime.getState().capabilities
      }))
    } as unknown as ThreadRuntime;

    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: disabledThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    expect(textarea.attributes('disabled')).toBeDefined();
  });

  it('updates when composer state changes', async () => {
    const subscribers: Array<() => void> = [];
    const mockSubscribe = vi.fn((callback: () => void) => {
      subscribers.push(callback);
      return () => {
        const index = subscribers.indexOf(callback);
        if (index > -1) subscribers.splice(index, 1);
      };
    });

    const dynamicMockComposerRuntime = {
      ...mockComposerRuntime,
      subscribe: mockSubscribe,
      getState: vi.fn(() => ({
        text: 'Initial text',
        attachments: [],
        canSend: true
      }))
    } as unknown as ComposerRuntime;

    const dynamicMockThreadRuntime = {
      ...mockThreadRuntime,
      composer: dynamicMockComposerRuntime
    } as unknown as ThreadRuntime;

    const wrapper = mount(ComposerInput, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: dynamicMockThreadRuntime
        }
      }
    });

    const textarea = wrapper.find('textarea');
    expect(textarea.element.value).toBe('Initial text');

    // Update the state
    dynamicMockComposerRuntime.getState = vi.fn(() => ({
      type: 'thread' as const,
      text: 'Updated text',
      attachments: [],
      canSend: true,
      canCancel: false,
      isEditing: false,
      isEmpty: false,
      role: 'user' as const,
      runConfig: {}
    }));

    // Trigger subscribers
    subscribers.forEach(cb => cb());
    await wrapper.vm.$nextTick();

    expect(textarea.element.value).toBe('Updated text');
  });
});