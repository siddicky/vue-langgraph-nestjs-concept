import { mount } from '@vue/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import UserMessage from '../../../components/primitives/message/UserMessage.vue';
import { useMessageContext } from '../../../composables/message/useMessageContext';
import { useMessagePartContext } from '../../../composables/messagePart/useMessagePartContext';
import { MessagePartStatus } from '../../../types';

vi.mock('../../../composables/message/useMessageContext');
vi.mock('../../../composables/messagePart/useMessagePartContext');

describe('UserMessage', () => {
  const mockMessageContext = {
    message: {
      id: 'msg-1',
      content: []
    },
    isLast: false
  };

  const mockMessagePartContext = {
    part: {
      type: 'text',
      text: 'Hello, assistant!'
    },
    status: { type: 'complete' } as MessagePartStatus,
    isLoading: false
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useMessageContext as any).mockReturnValue(mockMessageContext);
    (useMessagePartContext as any).mockReturnValue(mockMessagePartContext);
  });

  it('renders user message text content', () => {
    const wrapper = mount(UserMessage);
    expect(wrapper.text()).toContain('Hello, assistant!');
  });

  it('applies correct CSS class', () => {
    const wrapper = mount(UserMessage);
    expect(wrapper.classes()).toContain('aui-user-message-text');
  });

  it('renders with custom class', () => {
    const wrapper = mount(UserMessage, {
      attrs: {
        class: 'custom-class'
      }
    });
    expect(wrapper.classes()).toContain('custom-class');
    expect(wrapper.classes()).toContain('aui-user-message-text');
  });

  it('renders loading state', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      isLoading: true
    });
    
    const wrapper = mount(UserMessage);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders error state', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      status: { type: 'error', error: 'Network error' }
    });
    
    const wrapper = mount(UserMessage);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders long text content', () => {
    const longText = 'This is a very long message '.repeat(100);
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: longText
      }
    });
    
    const wrapper = mount(UserMessage);
    expect(wrapper.text()).toContain(longText);
  });

  it('renders empty text gracefully', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: ''
      }
    });
    
    const wrapper = mount(UserMessage);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.text()).toBe('');
  });

  it('renders with slot content', () => {
    const wrapper = mount(UserMessage, {
      slots: {
        default: '<div class="custom-content">Custom user message</div>'
      }
    });
    
    expect(wrapper.find('.custom-content').exists()).toBe(true);
    expect(wrapper.text()).toContain('Custom user message');
  });

  it('passes through additional props', () => {
    const wrapper = mount(UserMessage, {
      props: {
        'data-testid': 'user-message'
      }
    });
    
    expect(wrapper.attributes('data-testid')).toBe('user-message');
  });

  it('renders special characters correctly', () => {
    (useMessagePartContext as any).mockReturnValue({
      ...mockMessagePartContext,
      part: {
        type: 'text',
        text: 'Code: <script>alert("XSS")</script> & HTML entities'
      }
    });
    
    const wrapper = mount(UserMessage);
    expect(wrapper.text()).toContain('<script>alert("XSS")</script>');
    expect(wrapper.text()).toContain('& HTML entities');
  });
});