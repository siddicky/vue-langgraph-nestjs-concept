import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import { defineComponent } from 'vue';
import MessageParts from '../../../components/primitives/message/MessageParts.vue';
import { MESSAGE_RUNTIME_KEY } from '../../../context/keys';
import type { MessageRuntime, MessagePartRuntime } from '../../../api';

describe('MessageParts', () => {
  const createMockMessagePart = (type: string, text?: string): MessagePartRuntime => ({
    getState: vi.fn(() => ({
      type,
      part: { type, text },
      status: { type: 'complete' as const },
      tools: null
    })),
    subscribe: vi.fn(() => () => {})
  } as unknown as MessagePartRuntime);

  const mockMessageRuntime = {
    getState: vi.fn(() => ({
      message: {
        id: 'msg-1',
        role: 'assistant',
        content: [
          { type: 'text', text: 'Part 1' },
          { type: 'text', text: 'Part 2' },
          { type: 'text', text: 'Part 3' }
        ],
        createdAt: new Date()
      },
      parentId: null,
      isLast: true,
      branchNumber: 1,
      branchCount: 1
    })),
    composer: {
      getState: vi.fn(() => ({
        canAddAttachment: false,
        isEditing: false,
        isEmpty: true,
        text: '',
        attachments: []
      })),
      subscribe: vi.fn(() => () => {})
    },
    subscribe: vi.fn(() => () => {}),
    getContentPartByIndex: vi.fn((index: number) => {
      const parts = [
        createMockMessagePart('text', 'Part 1'),
        createMockMessagePart('text', 'Part 2'),
        createMockMessagePart('text', 'Part 3')
      ];
      return parts[index];
    })
  } as unknown as MessageRuntime;

  it('renders MessagePartByIndex for each content part', () => {
    const wrapper = mount(MessageParts, {
      global: {
        provide: {
          [MESSAGE_RUNTIME_KEY as symbol]: mockMessageRuntime
        },
        stubs: {
          MessagePartByIndex: true
        }
      }
    });

    const partComponents = wrapper.findAllComponents({ name: 'MessagePartByIndex' });
    expect(partComponents).toHaveLength(3);
    
    // Check that each component receives the correct index
    partComponents.forEach((component, index) => {
      expect(component.props('index')).toBe(index);
    });
  });

  it('passes components prop to MessagePartByIndex', () => {
    const TextComponent = defineComponent({
      template: '<div class="text-component">{{ text }}</div>',
      props: {
        type: { type: String, required: true },
        text: { type: String, required: true },
        status: { type: Object, required: true }
      }
    });

    const components = {
      Text: TextComponent as any
    };

    const wrapper = mount(MessageParts, {
      props: {
        components
      },
      global: {
        provide: {
          [MESSAGE_RUNTIME_KEY as symbol]: mockMessageRuntime
        },
        stubs: {
          MessagePartByIndex: true
        }
      }
    });

    const partComponents = wrapper.findAllComponents({ name: 'MessagePartByIndex' });
    partComponents.forEach((component) => {
      expect(component.props('components')).toBe(components);
    });
  });

  it('renders empty state when no content parts', () => {
    const emptyMessageRuntime = {
      ...mockMessageRuntime,
      getState: vi.fn(() => ({
        message: {
          id: 'msg-1',
          role: 'assistant',
          content: [],
          createdAt: new Date()
        },
        parentId: null,
        isLast: true,
        branchNumber: 1,
        branchCount: 1
      }))
    } as unknown as MessageRuntime;

    const wrapper = mount(MessageParts, {
      global: {
        provide: {
          [MESSAGE_RUNTIME_KEY as symbol]: emptyMessageRuntime
        }
      }
    });

    expect(wrapper.findAllComponents({ name: 'MessagePartByIndex' })).toHaveLength(0);
  });

  it('updates when message content changes', async () => {
    const subscribers: Array<() => void> = [];
    const mockSubscribe = vi.fn((callback: () => void) => {
      subscribers.push(callback);
      return () => {
        const index = subscribers.indexOf(callback);
        if (index > -1) subscribers.splice(index, 1);
      };
    });

    let contentParts = [
      { type: 'text', text: 'Part 1' },
      { type: 'text', text: 'Part 2' }
    ];

    const dynamicMockMessageRuntime = {
      ...mockMessageRuntime,
      subscribe: mockSubscribe,
      getState: vi.fn(() => ({
        message: {
          id: 'msg-1',
          role: 'assistant',
          content: contentParts,
          createdAt: new Date()
        },
        parentId: null,
        isLast: true,
        branchNumber: 1,
        branchCount: 1
      })),
      getContentPartByIndex: vi.fn((index: number) => {
        return createMockMessagePart('text', `Part ${index + 1}`);
      })
    } as unknown as MessageRuntime;

    const wrapper = mount(MessageParts, {
      global: {
        provide: {
          [MESSAGE_RUNTIME_KEY as symbol]: dynamicMockMessageRuntime
        },
        stubs: {
          MessagePartByIndex: true
        }
      }
    });

    let partComponents = wrapper.findAllComponents({ name: 'MessagePartByIndex' });
    expect(partComponents).toHaveLength(2);

    // Update content
    contentParts = [
      { type: 'text', text: 'Part 1' },
      { type: 'text', text: 'Part 2' },
      { type: 'text', text: 'Part 3' },
      { type: 'text', text: 'Part 4' }
    ];

    // Trigger subscribers
    subscribers.forEach(cb => cb());
    await wrapper.vm.$nextTick();

    partComponents = wrapper.findAllComponents({ name: 'MessagePartByIndex' });
    expect(partComponents).toHaveLength(4);
  });

  it('filters content parts when using components', () => {
    const ImageComponent = defineComponent({
      template: '<img class="image-component" />',
      props: {
        type: { type: String, required: true },
        image: { type: String, required: true },
        status: { type: Object, required: true }
      }
    });

    const components = {
      Image: ImageComponent as any
      // Note: Text component is not provided
    };

    const mixedMessageRuntime = {
      ...mockMessageRuntime,
      getState: vi.fn(() => ({
        message: {
          id: 'msg-1',
          role: 'assistant',
          content: [
            { type: 'text', text: 'Text part' },
            { type: 'image', image: 'url' },
            { type: 'text', text: 'Another text' },
            { type: 'tool-call', toolCallId: 'tool-1', toolName: 'test', args: {} }
          ],
          createdAt: new Date()
        },
        parentId: null,
        isLast: true,
        branchNumber: 1,
        branchCount: 1
      })),
      getContentPartByIndex: vi.fn((index: number) => {
        const types = ['text', 'image', 'text', 'tool-call'];
        return createMockMessagePart(types[index]);
      })
    } as unknown as MessageRuntime;

    const wrapper = mount(MessageParts, {
      props: {
        components
      },
      global: {
        provide: {
          [MESSAGE_RUNTIME_KEY as symbol]: mixedMessageRuntime
        },
        stubs: {
          MessagePartByIndex: true
        }
      }
    });

    // Should render all parts since filtering happens in MessagePartByIndex
    const partComponents = wrapper.findAllComponents({ name: 'MessagePartByIndex' });
    expect(partComponents).toHaveLength(4);
  });
});