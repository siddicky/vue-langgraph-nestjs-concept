import { mount } from '@vue/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import ThreadRoot from '../../../components/primitives/thread/ThreadRoot.vue';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';

vi.mock('../../../composables/thread/useThreadRuntime');

describe('ThreadRoot', () => {
  const mockThreadRuntime = {
    getState: vi.fn(),
    subscribe: vi.fn(),
    append: vi.fn(),
    startRun: vi.fn(),
    cancelRun: vi.fn(),
    composer: {
      getState: vi.fn(),
      subscribe: vi.fn()
    }
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useThreadRuntime as any).mockReturnValue(mockThreadRuntime);
    
    mockThreadRuntime.getState.mockReturnValue({
      threadId: 'test-thread',
      messages: [],
      isRunning: false,
      isDisabled: false,
      capabilities: {
        edit: true,
        reload: true,
        cancel: true
      },
      speech: undefined
    });

    mockThreadRuntime.subscribe.mockReturnValue(() => {});
  });

  it('renders thread root element', () => {
    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.classes()).toContain('aui-thread');
  });

  it('provides thread context to children', () => {
    const wrapper = mount(ThreadRoot, {
      slots: {
        default: `
          <div class="test-child">Child content</div>
        `
      }
    });

    expect(wrapper.find('.test-child').exists()).toBe(true);
    expect(wrapper.find('.test-child').text()).toBe('Child content');
  });

  it('subscribes to thread runtime on mount', () => {
    mount(ThreadRoot);
    
    expect(mockThreadRuntime.subscribe).toHaveBeenCalled();
  });

  it('unsubscribes from thread runtime on unmount', () => {
    const unsubscribe = vi.fn();
    mockThreadRuntime.subscribe.mockReturnValue(unsubscribe);
    
    const wrapper = mount(ThreadRoot);
    wrapper.unmount();
    
    expect(unsubscribe).toHaveBeenCalled();
  });

  it('updates when thread state changes', async () => {
    let subscriber: (() => void) | undefined;
    mockThreadRuntime.subscribe.mockImplementation((cb) => {
      subscriber = cb;
      return () => {};
    });

    const wrapper = mount(ThreadRoot);

    // Update thread state
    mockThreadRuntime.getState.mockReturnValue({
      threadId: 'updated-thread',
      messages: [
        {
          id: 'msg-1',
          role: 'user',
          content: [{ type: 'text', text: 'Hello' }]
        }
      ],
      isRunning: true,
      isDisabled: false,
      capabilities: {
        edit: false,
        reload: true,
        cancel: true
      },
      speech: undefined
    });

    // Trigger the subscriber
    if (subscriber) {
      subscriber();
    }

    await wrapper.vm.$nextTick();
    
    expect(wrapper.exists()).toBe(true);
  });

  it('handles thread with messages', () => {
    mockThreadRuntime.getState.mockReturnValue({
      threadId: 'thread-with-messages',
      messages: [
        {
          id: 'msg-1',
          role: 'user',
          content: [{ type: 'text', text: 'User message' }],
          createdAt: new Date()
        },
        {
          id: 'msg-2',
          role: 'assistant',
          content: [{ type: 'text', text: 'Assistant response' }],
          createdAt: new Date()
        }
      ],
      isRunning: false,
      isDisabled: false,
      capabilities: {
        edit: true,
        reload: true,
        cancel: false
      },
      speech: undefined
    });

    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
  });

  it('handles thread in running state', () => {
    mockThreadRuntime.getState.mockReturnValue({
      threadId: 'running-thread',
      messages: [],
      isRunning: true,
      isDisabled: false,
      capabilities: {
        edit: false,
        reload: false,
        cancel: true
      },
      speech: undefined
    });

    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
  });

  it('handles thread in disabled state', () => {
    mockThreadRuntime.getState.mockReturnValue({
      threadId: 'disabled-thread',
      messages: [],
      isRunning: false,
      isDisabled: true,
      capabilities: {
        edit: false,
        reload: false,
        cancel: false
      },
      speech: undefined
    });

    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
  });

  it('applies custom class names', () => {
    const wrapper = mount(ThreadRoot, {
      attrs: {
        class: 'custom-thread-class'
      }
    });

    expect(wrapper.classes()).toContain('aui-thread');
    expect(wrapper.classes()).toContain('custom-thread-class');
  });

  it('passes through additional attributes', () => {
    const wrapper = mount(ThreadRoot, {
      attrs: {
        'data-testid': 'thread-root',
        'aria-label': 'Chat thread'
      }
    });

    expect(wrapper.attributes('data-testid')).toBe('thread-root');
    expect(wrapper.attributes('aria-label')).toBe('Chat thread');
  });

  it('handles empty slot gracefully', () => {
    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.html()).toContain('aui-thread');
  });

  it('renders multiple children in slot', () => {
    const wrapper = mount(ThreadRoot, {
      slots: {
        default: `
          <div class="child-1">First child</div>
          <div class="child-2">Second child</div>
          <div class="child-3">Third child</div>
        `
      }
    });

    expect(wrapper.find('.child-1').exists()).toBe(true);
    expect(wrapper.find('.child-2').exists()).toBe(true);
    expect(wrapper.find('.child-3').exists()).toBe(true);
  });
});