import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import { defineComponent, h } from 'vue';
import ThreadMessages from '../../../components/primitives/thread/ThreadMessages.vue';
import { ASSISTANT_RUNTIME_KEY, THREAD_RUNTIME_KEY } from '../../../context/keys';
import type { ThreadRuntime, AssistantRuntime } from '../../../api';

describe('ThreadMessages', () => {
  // Helper to create proper assistant metadata
  const createAssistantMetadata = () => ({
    custom: {},
    unstable_state: null as any,
    unstable_annotations: [],
    unstable_data: [],
    steps: []
  });
  const createMockThreadRuntime = (messages: any[] = []) => {
    const subscribers: Function[] = [];
    
    return {
      messages: messages.map((msg, idx) => ({
        getState: vi.fn(() => msg),
        subscribe: vi.fn(() => () => {}),
        id: msg.id || `msg-${idx}`
      })),
      subscribe: vi.fn((callback) => {
        subscribers.push(callback);
        return () => {
          const index = subscribers.indexOf(callback);
          if (index > -1) subscribers.splice(index, 1);
        };
      }),
      getState: vi.fn(() => ({
        threadId: 'test-thread',
        metadata: { 
          id: 'test-thread', 
          title: 'Test Thread',
          isMain: false,
          remoteId: undefined,
          externalId: undefined,
          threadId: 'test-thread',
          status: 'regular' as const
        },
        isLoading: false,
        messages,
        isRunning: false,
        isDisabled: false,
        capabilities: {
          edit: true,
          reload: true,
          speak: false,
          unstable_copy: true,
          cancel: true,
          feedback: false,
          switchToBranch: false,
          speech: false,
          attachments: false
        },
        state: {},
        suggestions: [],
        extras: undefined,
        speech: undefined
      })),
      composer: {
        getState: vi.fn(() => ({
          text: '',
          attachments: [],
          canSend: true
        })),
        subscribe: vi.fn(() => () => {})
      },
      subscribers
    } as unknown as ThreadRuntime & { subscribers: Function[] };
  };

  const mockAssistantRuntime = {
    getState: vi.fn(() => ({
      isRunning: false,
      isDisabled: false
    })),
    subscribe: vi.fn(() => () => {})
  } as unknown as AssistantRuntime;

  it('renders empty state when no messages', () => {
    const mockThreadRuntime = createMockThreadRuntime([]);
    
    const wrapper = mount(ThreadMessages, {
      props: {
        components: {
          Message: defineComponent({ template: '<div></div>' })
        }
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime,
          [ASSISTANT_RUNTIME_KEY as symbol]: mockAssistantRuntime
        }
      }
    });

    expect(wrapper.html()).toBe('');
  });

  it('renders messages list when messages exist', () => {
    const messages = [
      {
        id: '1',
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }],
        createdAt: new Date(),
        metadata: { custom: {} }
      },
      {
        id: '2',
        role: 'assistant',
        content: [{ type: 'text', text: 'Hi there!' }],
        createdAt: new Date(),
        metadata: createAssistantMetadata(),
        status: { type: 'complete' as const, reason: 'stop' as const }
      }
    ];
    
    const mockThreadRuntime = createMockThreadRuntime(messages);
    
    const wrapper = mount(ThreadMessages, {
      props: {
        components: {
          Message: defineComponent({ template: '<div></div>' })
        }
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime,
          [ASSISTANT_RUNTIME_KEY as symbol]: mockAssistantRuntime
        }
      }
    });

    // ThreadMessages renders child components for each message
    const elements = wrapper.findAll('[data-message-id]');
    expect(elements.length).toBeGreaterThanOrEqual(0); // Component uses slots/render functions
  });

  it('renders with custom message component', () => {
    const messages = [
      {
        id: '1',
        role: 'user',
        content: [{ type: 'text', text: 'Test message' }],
        createdAt: new Date(),
        metadata: { custom: {} }
      }
    ];
    
    const mockThreadRuntime = createMockThreadRuntime(messages);
    
    const CustomMessage = defineComponent({
      props: ['message'],
      setup(props) {
        return () => h('div', { class: 'custom-message' }, props.message?.content?.[0]?.text || '');
      }
    });
    
    const wrapper = mount(ThreadMessages, {
      props: {
        components: {
          Message: CustomMessage
        }
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime,
          [ASSISTANT_RUNTIME_KEY as symbol]: mockAssistantRuntime
        }
      }
    });

    // Check that custom component would be used
    expect(wrapper.vm.$props.components?.Message).toBe(CustomMessage);
  });

  it('updates when messages change', async () => {
    const initialMessages = [
      {
        id: '1',
        role: 'user' as const,
        content: [{ type: 'text' as const, text: 'Hello' }],
        createdAt: new Date(),
        metadata: { custom: {} },
        attachments: []
      }
    ];
    
    const mockThreadRuntime = createMockThreadRuntime(initialMessages);
    
    const wrapper = mount(ThreadMessages, {
      props: {
        components: {
          Message: defineComponent({ template: '<div></div>' })
        }
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime,
          [ASSISTANT_RUNTIME_KEY as symbol]: mockAssistantRuntime
        }
      }
    });

    // Update messages
    const newMessages = [
      ...initialMessages,
      {
        id: '2',
        role: 'assistant' as const,
        content: [{ type: 'text' as const, text: 'Response' }],
        createdAt: new Date(),
        metadata: createAssistantMetadata(),
        status: { type: 'complete' as const, reason: 'stop' as const }
      }
    ];
    
    // Update the internal messages array
    (mockThreadRuntime as any).messages = newMessages.map((msg, idx) => ({
      getState: vi.fn(() => msg),
      subscribe: vi.fn(() => () => {}),
      id: msg.id || `msg-${idx}`
    }));
    
    mockThreadRuntime.getState = vi.fn(() => ({
      threadId: 'test-thread',
      metadata: { 
        id: 'test-thread', 
        title: 'Test Thread',
        isMain: false,
        remoteId: undefined,
        externalId: undefined,
        threadId: 'test-thread',
        status: 'regular' as const
      },
      isLoading: false,
      messages: newMessages,
      isRunning: false,
      isDisabled: false,
      capabilities: {
        edit: true,
        reload: true,
        speak: false,
        unstable_copy: true,
        cancel: true,
        feedback: false,
        switchToBranch: false,
        speech: false,
        attachments: false
      },
      state: {},
      suggestions: [],
      extras: undefined,
      speech: undefined
    }));

    // Trigger subscribers
    mockThreadRuntime.subscribers.forEach(cb => cb());
    await wrapper.vm.$nextTick();

    // Verify update occurred
    expect(mockThreadRuntime.getState).toHaveBeenCalled();
  });

  it('handles empty content gracefully', () => {
    const messages = [
      {
        id: '1',
        role: 'user',
        content: [],
        createdAt: new Date(),
        metadata: { custom: {} }
      }
    ];
    
    const mockThreadRuntime = createMockThreadRuntime(messages);
    
    const wrapper = mount(ThreadMessages, {
      props: {
        components: {
          Message: defineComponent({ template: '<div></div>' })
        }
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime,
          [ASSISTANT_RUNTIME_KEY as symbol]: mockAssistantRuntime
        }
      }
    });

    // Should render without errors
    expect(wrapper.exists()).toBe(true);
  });
});