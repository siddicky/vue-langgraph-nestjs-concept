import { describe, it, expect, vi, beforeEach } from 'vitest';
import { mount } from '@vue/test-utils';
import ComposerSend from '../../../components/primitives/composer/ComposerSend.vue';
import { THREAD_RUNTIME_KEY } from '../../../context/keys';
import type { ComposerRuntime, ThreadRuntime } from '../../../api';

describe('ComposerSend', () => {
  let mockComposerRuntime: ComposerRuntime;
  let mockThreadRuntime: ThreadRuntime;
  let subscribers: Function[];

  beforeEach(() => {
    subscribers = [];
    
    mockComposerRuntime = {
      getState: vi.fn(() => ({
        text: 'Test message',
        attachments: [],
        canSend: true,
        canCancel: false,
        isEditing: false,
        isEmpty: false,
        role: 'user' as const,
        runConfig: {}
      })),
      subscribe: vi.fn((callback) => {
        subscribers.push(callback);
        return () => {
          const index = subscribers.indexOf(callback);
          if (index > -1) subscribers.splice(index, 1);
        };
      }),
      setText: vi.fn(),
      send: vi.fn(),
      cancel: vi.fn(),
      addAttachment: vi.fn(),
      removeAttachment: vi.fn()
    } as unknown as ComposerRuntime;

    mockThreadRuntime = {
      composer: mockComposerRuntime,
      getState: vi.fn(() => ({
        isRunning: false,
        isDisabled: false,
        messages: [],
        capabilities: {
          edit: true,
          reload: true,
          speak: false,
          unstable_copy: true,
          cancel: true,
          feedback: false
        }
      })),
      subscribe: vi.fn(() => () => {})
    } as unknown as ThreadRuntime;
  });

  it('renders a button element', () => {
    const wrapper = mount(ComposerSend, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    expect(wrapper.find('button').exists()).toBe(true);
  });

  it('calls send when clicked and canSend is true', async () => {
    const wrapper = mount(ComposerSend, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const button = wrapper.find('button');
    await button.trigger('click');

    expect(mockComposerRuntime.send).toHaveBeenCalled();
  });

  it('does not call send when canSend is false', async () => {
    mockComposerRuntime.getState = vi.fn(() => ({
      type: 'thread' as const,
      text: '',
      attachments: [],
      canSend: false,
      canCancel: false,
      isEditing: false,
      isEmpty: true,
      role: 'user' as const,
      runConfig: {}
    }));

    const wrapper = mount(ComposerSend, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const button = wrapper.find('button');
    await button.trigger('click');

    expect(mockComposerRuntime.send).not.toHaveBeenCalled();
  });

  it('disables button when canSend is false', () => {
    mockComposerRuntime.getState = vi.fn(() => ({
      type: 'thread' as const,
      text: '',
      attachments: [],
      canSend: false,
      canCancel: false,
      isEditing: false,
      isEmpty: true,
      role: 'user' as const,
      runConfig: {}
    }));

    const wrapper = mount(ComposerSend, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const button = wrapper.find('button');
    expect(button.attributes('disabled')).toBeDefined();
  });

  it('renders with slot content', () => {
    const wrapper = mount(ComposerSend, {
      slots: {
        default: 'Send Message'
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    expect(wrapper.text()).toContain('Send Message');
  });

  it('applies custom attributes', () => {
    const wrapper = mount(ComposerSend, {
      attrs: {
        class: 'custom-class',
        'data-testid': 'send-button'
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const button = wrapper.find('button');
    expect(button.classes()).toContain('custom-class');
    expect(button.attributes('data-testid')).toBe('send-button');
  });

  it('updates disabled state when canSend changes', async () => {
    const wrapper = mount(ComposerSend, {
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    const button = wrapper.find('button');
    expect(button.attributes('disabled')).toBeUndefined();

    // Update state to disable sending
    mockComposerRuntime.getState = vi.fn(() => ({
      type: 'thread' as const,
      text: '',
      attachments: [],
      canSend: false,
      canCancel: false,
      isEditing: false,
      isEmpty: true,
      role: 'user' as const,
      runConfig: {}
    }));

    // Trigger subscribers
    subscribers.forEach(cb => cb());
    await wrapper.vm.$nextTick();

    expect(button.attributes('disabled')).toBeDefined();
  });

  it('handles asChild prop correctly', () => {
    const wrapper = mount(ComposerSend, {
      props: {
        asChild: true
      },
      slots: {
        default: '<div>Custom Send Element</div>'
      },
      global: {
        provide: {
          [THREAD_RUNTIME_KEY as symbol]: mockThreadRuntime
        }
      }
    });

    // When asChild is true, it should render the slot content directly
    expect(wrapper.html()).toContain('Custom Send Element');
  });
});