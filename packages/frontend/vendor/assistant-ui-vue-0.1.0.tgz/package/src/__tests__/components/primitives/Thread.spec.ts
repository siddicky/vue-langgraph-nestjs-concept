import { mount } from '@vue/test-utils';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Thread from '../../../components/primitives/thread/ThreadRoot.vue';
import { useThreadContext } from '../../../composables/thread/useThreadContext';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';

vi.mock('../../../composables/thread/useThreadContext');
vi.mock('../../../composables/thread/useThreadRuntime');
vi.mock('../../../components/primitives/thread/ThreadRoot.vue', () => ({
  default: {
    name: 'ThreadRoot',
    template: '<div class="thread-root"><slot /></div>'
  }
}));
vi.mock('../../../components/primitives/thread/ThreadViewport.vue', () => ({
  default: {
    name: 'ThreadViewport',
    template: '<div class="thread-viewport"><slot /></div>'
  }
}));
vi.mock('../../../components/primitives/thread/ThreadMessages.vue', () => ({
  default: {
    name: 'ThreadMessages',
    template: '<div class="thread-messages">Messages</div>'
  }
}));
vi.mock('../../../components/primitives/thread/ThreadScrollToBottom.vue', () => ({
  default: {
    name: 'ThreadScrollToBottom',
    template: '<button class="scroll-to-bottom">Scroll</button>'
  }
}));
vi.mock('../../../components/primitives/thread/ThreadViewportFooter.vue', () => ({
  default: {
    name: 'ThreadViewportFooter',
    template: '<div class="viewport-footer"><slot /></div>'
  }
}));
vi.mock('../../../components/primitives/composer/Composer.vue', () => ({
  default: {
    name: 'Composer',
    template: '<div class="composer"><slot /></div>'
  }
}));
vi.mock('../../../components/primitives/composer/ComposerInput.vue', () => ({
  default: {
    name: 'ComposerInput',
    template: '<input class="composer-input" />'
  }
}));

describe('Thread', () => {
  const mockThreadContext = {
    thread: {
      id: 'thread-1',
      messages: []
    },
    isRunning: false
  };

  const mockThreadRuntime = {
    messages: [],
    isRunning: false,
    append: vi.fn(),
    cancel: vi.fn(),
    reload: vi.fn()
  };

  beforeEach(() => {
    vi.clearAllMocks();
    (useThreadContext as any).mockReturnValue(mockThreadContext);
    (useThreadRuntime as any).mockReturnValue(mockThreadRuntime);
  });

  it('renders thread structure', () => {
    const wrapper = mount(Thread);
    
    expect(wrapper.find('.thread-root').exists()).toBe(true);
    expect(wrapper.find('.thread-viewport').exists()).toBe(true);
    expect(wrapper.find('.thread-messages').exists()).toBe(true);
    expect(wrapper.find('.composer').exists()).toBe(true);
  });

  it('renders composer input', () => {
    const wrapper = mount(Thread);
    expect(wrapper.find('.composer-input').exists()).toBe(true);
  });

  it('renders scroll to bottom button', () => {
    const wrapper = mount(Thread);
    expect(wrapper.find('.scroll-to-bottom').exists()).toBe(true);
  });

  it('applies custom class', () => {
    const wrapper = mount(Thread, {
      attrs: {
        class: 'custom-thread'
      }
    });
    
    expect(wrapper.classes()).toContain('aui-thread');
    expect(wrapper.classes()).toContain('custom-thread');
  });

  it('passes through additional props', () => {
    const wrapper = mount(Thread, {
      props: {
        'data-testid': 'main-thread'
      }
    });
    
    expect(wrapper.attributes('data-testid')).toBe('main-thread');
  });

  it('renders with empty thread', () => {
    (useThreadRuntime as any).mockReturnValue({
      ...mockThreadRuntime,
      messages: []
    });
    
    const wrapper = mount(Thread);
    expect(wrapper.find('.thread-messages').exists()).toBe(true);
  });

  it('renders with messages', () => {
    (useThreadRuntime as any).mockReturnValue({
      ...mockThreadRuntime,
      messages: [
        { id: 'msg-1', role: 'user', content: [{ type: 'text', text: 'Hello' }] },
        { id: 'msg-2', role: 'assistant', content: [{ type: 'text', text: 'Hi there!' }] }
      ]
    });
    
    const wrapper = mount(Thread);
    expect(wrapper.find('.thread-messages').exists()).toBe(true);
  });

  it('renders during running state', () => {
    (useThreadContext as any).mockReturnValue({
      ...mockThreadContext,
      isRunning: true
    });
    (useThreadRuntime as any).mockReturnValue({
      ...mockThreadRuntime,
      isRunning: true
    });
    
    const wrapper = mount(Thread);
    expect(wrapper.find('.thread-messages').exists()).toBe(true);
    expect(wrapper.find('.composer').exists()).toBe(true);
  });

  it('renders viewport footer', () => {
    const wrapper = mount(Thread);
    expect(wrapper.find('.viewport-footer').exists()).toBe(true);
  });

  it('renders with custom slot content', () => {
    const wrapper = mount(Thread, {
      slots: {
        default: '<div class="custom-thread-content">Custom content</div>'
      }
    });
    
    expect(wrapper.find('.custom-thread-content').exists()).toBe(true);
    expect(wrapper.text()).toContain('Custom content');
  });

  it('maintains structure hierarchy', () => {
    const wrapper = mount(Thread);
    
    const threadRoot = wrapper.find('.thread-root');
    const viewport = threadRoot.find('.thread-viewport');
    const messages = viewport.find('.thread-messages');
    
    expect(threadRoot.exists()).toBe(true);
    expect(viewport.exists()).toBe(true);
    expect(messages.exists()).toBe(true);
  });

  it('includes composer in footer', () => {
    const wrapper = mount(Thread);
    
    const footer = wrapper.find('.viewport-footer');
    const composer = footer.find('.composer');
    
    expect(footer.exists()).toBe(true);
    expect(composer.exists()).toBe(true);
  });

  it('renders with minimal setup', () => {
    (useThreadContext as any).mockReturnValue(null);
    (useThreadRuntime as any).mockReturnValue(null);
    
    const wrapper = mount(Thread);
    expect(wrapper.exists()).toBe(true);
  });
});