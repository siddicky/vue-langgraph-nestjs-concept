import { ref } from 'vue';
import type { ThreadRuntime } from '../api/ThreadRuntime';
import type { Unsubscribe } from '../types/Unsubscribe';

export interface ThreadViewportState {
  readonly isAtBottom: boolean;
  readonly scrollToBottom: () => void;
  readonly onScrollToBottom: (callback: () => void) => Unsubscribe;
}

export class ThreadViewport implements ThreadViewportState {
  private scrollToBottomListeners = new Set<() => void>();
  private _isAtBottom = ref(true);
  
  public unsubscribe?: () => void;

  constructor(_runtime: ThreadRuntime) {
    // Initialize with runtime if needed
  }

  get isAtBottom(): boolean {
    return this._isAtBottom.value;
  }

  set isAtBottom(value: boolean) {
    this._isAtBottom.value = value;
  }

  scrollToBottom = (): void => {
    for (const listener of this.scrollToBottomListeners) {
      listener();
    }
  };

  onScrollToBottom = (callback: () => void): Unsubscribe => {
    this.scrollToBottomListeners.add(callback);
    return () => {
      this.scrollToBottomListeners.delete(callback);
    };
  };
}

export const makeThreadViewportStore = () => {
  const scrollToBottomListeners = new Set<() => void>();
  const isAtBottom = ref(true);

  return {
    isAtBottom,
    scrollToBottom: () => {
      for (const listener of scrollToBottomListeners) {
        listener();
      }
    },
    onScrollToBottom: (callback: () => void) => {
      scrollToBottomListeners.add(callback);
      return () => {
        scrollToBottomListeners.delete(callback);
      };
    },
  };
};