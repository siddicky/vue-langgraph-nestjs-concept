import { reactive } from 'vue';
import type { Component } from 'vue';
import type { Unsubscribe } from '../types/Unsubscribe';

export interface ToolCallMessagePartComponent {
  component: Component;
  // Add other properties as needed
}

export interface AssistantToolUIsState {
  /**
   * Get the tool UI configured for a given tool name.
   */
  getToolUI: (toolName: string) => ToolCallMessagePartComponent | null;

  /**
   * Registers a tool UI for a given tool name. Returns an unsubscribe function to remove the tool UI.
   */
  setToolUI: (
    toolName: string,
    render: ToolCallMessagePartComponent,
  ) => Unsubscribe;
}

export class AssistantToolUIsProvider implements AssistantToolUIsState {
  private renderers = new Map<string, ToolCallMessagePartComponent[]>();
  private state = reactive({});

  getToolUI = (name: string): ToolCallMessagePartComponent | null => {
    const arr = this.renderers.get(name);
    const last = arr?.at(-1);
    if (last) return last;
    return null;
  };

  setToolUI = (
    name: string,
    render: ToolCallMessagePartComponent
  ): Unsubscribe => {
    let arr = this.renderers.get(name);
    if (!arr) {
      arr = [];
      this.renderers.set(name, arr);
    }
    arr.push(render);
    // Trigger reactivity
    this.state;

    return () => {
      const index = arr!.indexOf(render);
      if (index !== -1) {
        arr!.splice(index, 1);
      }
      if (index === arr!.length) {
        // Trigger reactivity
        this.state;
      }
    };
  };
}

export const makeAssistantToolUIsStore = () => {
  return new AssistantToolUIsProvider();
};