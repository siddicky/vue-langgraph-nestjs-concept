export interface MessageUtilsState {
  isHovering: boolean;
  isCopied: boolean;
  isSpeaking: boolean;
  
  setIsHovering: (value: boolean) => void;
  setIsCopied: (value: boolean) => void;
  setIsSpeaking: (value: boolean) => void;
}

export class MessageUtils implements MessageUtilsState {
  isHovering = false;
  isCopied = false;
  isSpeaking = false;
  
  setIsHovering(value: boolean) {
    this.isHovering = value;
  }
  
  setIsCopied(value: boolean) {
    this.isCopied = value;
  }
  
  setIsSpeaking(value: boolean) {
    this.isSpeaking = value;
  }
}