
import { ref, onUnmounted, computed, watchEffect } from "vue";
import type { ChatModelAdapter } from "./ChatModelAdapter";
import { LocalRuntimeCore } from "./LocalRuntimeCore";
import type { LocalRuntimeOptions } from "./LocalRuntimeOptions";
import { useRuntimeAdapters } from "../adapters/useRuntimeAdapters";
import { useRemoteThreadListRuntime } from "../remote-thread-list/useRemoteThreadListRuntime";
import { useCloudThreadListAdapter } from "../remote-thread-list/adapter/cloud";
import { AssistantRuntimeImpl } from "../../internal";

export const useLocalThreadRuntime = (
  adapter: ChatModelAdapter,
  { initialMessages, ...options }: LocalRuntimeOptions,
) => {
  const runtimeAdaptersResult = useRuntimeAdapters();
  const { modelContext, ...threadListAdapters } = runtimeAdaptersResult ?? {};
  
  const opt = computed(() => ({
    ...options,
    adapters: {
      ...(threadListAdapters?.history ? { history: threadListAdapters.history.value } : {}),
      ...options.adapters,
      chatModel: adapter,
    },
  }));

  const runtime = ref(new LocalRuntimeCore(opt.value, initialMessages));

  onUnmounted(() => {
    runtime.value.threads.getMainThreadRuntimeCore().detach();
  });

  watchEffect(() => {
    runtime.value.threads.getMainThreadRuntimeCore().__internal_setOptions(opt.value);
    runtime.value.threads.getMainThreadRuntimeCore().__internal_load();
  });

  watchEffect((onCleanup) => {
    if (!modelContext?.value) return;
    const unsubscribe = runtime.value.registerModelContextProvider(modelContext.value);
    onCleanup(() => unsubscribe());
  });

  return computed(() => new AssistantRuntimeImpl(runtime.value));
};

export const useLocalRuntime = (
  adapter: ChatModelAdapter,
  { cloud, ...options }: LocalRuntimeOptions = {},
) => {
  const cloudAdapter = useCloudThreadListAdapter({ cloud });
  return useRemoteThreadListRuntime({
    runtimeHook: function RuntimeHook() {
      return useLocalThreadRuntime(adapter, options).value;
    },
    adapter: cloudAdapter,
  });
};