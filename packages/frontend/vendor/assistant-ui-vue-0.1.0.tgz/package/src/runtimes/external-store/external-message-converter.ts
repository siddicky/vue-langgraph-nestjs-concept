
import { computed, ComputedRef, Ref } from "vue";
import {
  symbolInnerMessage,
} from "./getExternalStoreMessage";
import { fromThreadMessageLike, ThreadMessageLike } from "./ThreadMessageLike";
import { getAutoStatus, isAutoStatus } from "./auto-status";
import { ToolCallMessagePart } from "../../types";
import { generateId } from "../../internal";

export namespace useExternalMessageConverter {
  export type Message =
    | (ThreadMessageLike & {
        readonly convertConfig?: {
          readonly joinStrategy?: "concat-content" | "none";
        };
      })
    | {
        role: "tool";
        toolCallId: string;
        toolName?: string | undefined;
        args?: any;
        argsText?: string;
        result: any;
        artifact?: any;
        isError?: boolean;
        readonly convertConfig?: {
          readonly joinStrategy?: "concat-content" | "none";
        };
      };

  export type Callback<T> = (message: T) => Message | Message[];
}

type CallbackResult<T> = {
  input: T;
  outputs: useExternalMessageConverter.Message[];
};

type ChunkResult<T> = {
  inputs: T[];
  outputs: useExternalMessageConverter.Message[];
};

type Mutable<T> = {
  -readonly [P in keyof T]: T[P];
};

const joinExternalMessages = (
  messages: readonly useExternalMessageConverter.Message[],
): ThreadMessageLike => {
  const assistantMessage: Mutable<Omit<ThreadMessageLike, "metadata">> & {
    content: Exclude<ThreadMessageLike["content"][0], string>[];
    metadata?: Mutable<ThreadMessageLike["metadata"]>;
  } = {
    role: "assistant",
    content: [],
  };
  for (const output of messages) {
    if (output.role === "tool") {
      const toolCallIdx = assistantMessage.content.findIndex(
        (c) => c.type === "tool-call" && c.toolCallId === output.toolCallId,
      );
      if (toolCallIdx !== -1) {
        const toolCall = assistantMessage.content[
          toolCallIdx
        ]! as ToolCallMessagePart;
        if (output.toolName) {
          if (toolCall.toolName !== output.toolName)
            throw new Error(
              `Tool call name ${output.toolCallId} ${output.toolName} does not match existing tool call ${toolCall.toolName}`,
            );
        }
        assistantMessage.content[toolCallIdx] = {
          ...toolCall,
          ...{
            [symbolInnerMessage]: [
              ...((toolCall as any)[symbolInnerMessage] ?? []),
              output,
            ],
          },
          result: output.result,
          artifact: output.artifact,
          isError: output.isError,
        };
      } else {
        assistantMessage.content.push({
          type: "tool-call",
          toolCallId: output.toolCallId,
          toolName: output.toolName ?? "unknown",
          args: output.args ?? {},
          argsText: output.argsText ?? "",
          ...{
            [symbolInnerMessage]: [output],
          },
          result: output.result,
          artifact: output.artifact,
          isError: output.isError,
        } as ToolCallMessagePart);
      }
    } else {
      const outputLike = fromThreadMessageLike(
        output,
        generateId(),
        { type: "complete", reason: "unknown" }
      );
      if (output.role !== outputLike.role) {
        throw new Error(
          `Cannot join external messages with different roles: ${assistantMessage.role} and ${outputLike.role}`,
        );
      }
      const content = outputLike.content;
      if (
        typeof content === "string" &&
        assistantMessage.content.length > 0 &&
        assistantMessage.content[assistantMessage.content.length - 1]?.type ===
          "text"
      ) {
        (assistantMessage.content[assistantMessage.content.length - 1] as any).text +=
          content;
      } else {
        if (typeof content === "string") {
          assistantMessage.content.push({ type: "text", text: content });
        } else {
          assistantMessage.content.push(...content);
        }
      }

      // Merge id from the last message
      assistantMessage.id = outputLike.id;

      // Merge metadata
      const outputMetadata = outputLike.metadata;
      if (outputMetadata) {
        assistantMessage.metadata = assistantMessage.metadata ?? {};
        for (const [key, value] of Object.entries(outputMetadata)) {
          const prev = assistantMessage.metadata[key as keyof typeof outputMetadata];
          if (prev && Array.isArray(prev) && Array.isArray(value)) {
            assistantMessage.metadata[key as keyof typeof outputMetadata] = [...prev, ...value] as any;
          } else {
            assistantMessage.metadata[key as keyof typeof outputMetadata] = value as any;
          }
        }
      }

      // Set status of the last message
      assistantMessage.status = outputLike.status;
      assistantMessage.attachments = outputLike.attachments;
    }
  }
  return assistantMessage as ThreadMessageLike;
};

export const chunkExternalMessages = <T>(
  callbackResults: CallbackResult<T>[],
): ChunkResult<T>[] => {
  const chunks: ChunkResult<T>[] = [];
  let currentChunk: ChunkResult<T> | undefined = undefined;
  let currentJoinStrategy: "concat-content" | "none" | undefined = undefined;

  for (const result of callbackResults) {
    const joinStrategy = result.outputs[0]?.convertConfig?.joinStrategy;
    if (joinStrategy !== currentJoinStrategy) {
      if (currentChunk) chunks.push(currentChunk);
      currentChunk = undefined;
      currentJoinStrategy = joinStrategy;
    }

    if (!currentChunk) {
      currentChunk = { inputs: [], outputs: [] };
    }

    currentChunk.inputs.push(result.input);
    currentChunk.outputs.push(...result.outputs);
  }

  if (currentChunk) chunks.push(currentChunk);

  return chunks;
};

export const convertExternalMessages = <T>(
  messages: T[],
  callback: useExternalMessageConverter.Callback<T>,
  isRunning: boolean,
): ThreadMessageLike[] => {
  const callbackResults: CallbackResult<T>[] = [];
  for (const input of messages) {
    const rawOutputs = callback(input);
    const outputs = Array.isArray(rawOutputs)
      ? rawOutputs
      : [rawOutputs];
    callbackResults.push({ input, outputs });
  }

  const chunks = chunkExternalMessages(callbackResults);

  const newMessages: ThreadMessageLike[] = [];
  for (const chunk of chunks) {
    const joinStrategy = chunk.outputs[0]?.convertConfig?.joinStrategy;
    if (joinStrategy === "concat-content") {
      newMessages.push({
        ...joinExternalMessages(chunk.outputs),
        ...{
          [symbolInnerMessage]: chunk.inputs,
        },
      } as ThreadMessageLike);
    } else {
      for (let i = 0; i < chunk.outputs.length; i++) {
        const output = chunk.outputs[i]!;
        const isLast = i === chunk.outputs.length - 1;
        const autoStatus = isLast ? getAutoStatus(true, isRunning, false) : undefined;
        if (output.role === "tool") {
          // skip
          continue;
        }
        newMessages.push({
          ...fromThreadMessageLike(
            output,
            generateId(),
            autoStatus ?? { type: "complete", reason: "unknown" }
          ),
          ...(autoStatus ? { status: autoStatus } : undefined),
          ...{
            [symbolInnerMessage]: [chunk.inputs[i]!],
          },
        } as ThreadMessageLike);
      }
    }
  }

  // Add auto-status to the last message if needed
  const lastMessage = newMessages.at(-1);
  if (lastMessage && lastMessage.status && !isAutoStatus(lastMessage.status)) {
    const autoStatus = getAutoStatus(true, isRunning, false);
    if (autoStatus) {
      newMessages[newMessages.length - 1] = {
        ...(newMessages.at(-1) as ThreadMessageLike),
        status: autoStatus,
      };
    }
  }

  return newMessages;
};

export const useExternalMessageConverter = <T>({
  callback,
  messages,
  isRunning: _isRunning,
  joinStrategy,
}: {
  callback: useExternalMessageConverter.Callback<T>;
  messages: Ref<T[]> | T[];
  isRunning: Ref<boolean> | boolean;
  joinStrategy?: "concat-content" | "none" | undefined;
}): ComputedRef<ThreadMessageLike[]> => {
  const messagesRef = Array.isArray(messages) ? computed(() => messages) : computed(() => messages.value);

  return computed(() => {
    const callbackWithJoinStrategy: useExternalMessageConverter.Callback<T> = (
      message,
    ) => {
      const rawResult = callback(message);
      const result = Array.isArray(rawResult) ? rawResult : [rawResult];
      return result.map((r) => ({
        ...r,
        convertConfig: { ...r.convertConfig, joinStrategy },
      }));
    };

    // TODO: Refactor to match React's implementation with proper caching
    // For now, convert messages directly without the converter
    const convertedMessages: ThreadMessageLike[] = [];
    for (const message of messagesRef.value) {
      const result = callbackWithJoinStrategy(message);
      const results = Array.isArray(result) ? result : [result];
      for (const msg of results) {
        convertedMessages.push(msg as unknown as ThreadMessageLike);
      }
    }
    return convertedMessages;
  });
};