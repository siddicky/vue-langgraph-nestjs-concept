import { ref, watchEffect, computed } from "vue";
import { ExternalStoreRuntimeCore } from "./ExternalStoreRuntimeCore";
import { ExternalStoreAdapter } from "./ExternalStoreAdapter";
import {
  AssistantRuntime,
  AssistantRuntimeImpl,
} from "../../api/AssistantRuntime";
import { useRuntimeAdapters } from "../adapters/useRuntimeAdapters";

export const useExternalStoreRuntime = <T,>(
  store: ExternalStoreAdapter<T>,
): AssistantRuntime => {
  const runtime = ref(new ExternalStoreRuntimeCore(store));

  watchEffect(() => {
    runtime.value.setAdapter(store);
  });

  const { modelContext } = useRuntimeAdapters() ?? {};

  watchEffect((onInvalidate) => {
    if (!modelContext?.value) return;
    const unsubscribe = runtime.value.registerModelContextProvider(modelContext.value);
    onInvalidate(() => unsubscribe?.());
  });

  return computed(() => new AssistantRuntimeImpl(runtime.value)).value;
};