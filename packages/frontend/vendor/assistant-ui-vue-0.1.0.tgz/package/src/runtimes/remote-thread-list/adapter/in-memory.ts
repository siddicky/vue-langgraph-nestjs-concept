import { RemoteThreadListAdapter } from "../types";

export class InMemoryThreadListAdapter implements RemoteThreadListAdapter {
  private threads: Map<string, any> = new Map();

  async list() {
    return {
      threads: Array.from(this.threads.values()),
    };
  }

  async initialize() {
    const remoteId = `thread-${Date.now()}`;
    const thread = {
      status: "regular" as const,
      remoteId,
      externalId: undefined,
      title: "New Thread",
    };
    this.threads.set(remoteId, thread);
    return { remoteId, externalId: undefined };
  }

  async rename(remoteId: string, newTitle: string) {
    const thread = this.threads.get(remoteId);
    if (thread) {
      thread.title = newTitle;
    }
  }

  async archive(remoteId: string) {
    const thread = this.threads.get(remoteId);
    if (thread) {
      thread.status = "archived";
    }
  }

  async unarchive(remoteId: string) {
    const thread = this.threads.get(remoteId);
    if (thread) {
      thread.status = "regular";
    }
  }

  async delete(remoteId: string) {
    this.threads.delete(remoteId);
  }

  async generateTitle() {
    // TODO: Implement title generation
    return {} as any;
  }
}