
import { computed, defineComponent, ref, watchEffect, Ref } from "vue";
import { AssistantCloud } from "@assistant-ui/cloud";
import { RemoteThreadListAdapter } from "../types";
import { InMemoryThreadListAdapter } from "./in-memory";
import { useAssistantCloudThreadHistoryAdapter } from "../../../cloud/AssistantCloudThreadHistoryAdapter";
import { provideRuntimeAdapters } from "../../adapters";

type ThreadData = {
  externalId: string;
};

type CloudThreadListAdapterOptions = {
  cloud?: AssistantCloud | undefined;

  create?(): Promise<ThreadData>;
  delete?(threadId: string): Promise<void>;
};

const baseUrl =
  typeof process !== "undefined" &&
  process?.env?.["NEXT_PUBLIC_ASSISTANT_BASE_URL"];
const autoCloud = baseUrl
  ? new AssistantCloud({ baseUrl, anonymous: true })
  : undefined;

export const useCloudThreadListAdapter = (
  adapter: CloudThreadListAdapterOptions,
): RemoteThreadListAdapter => {
  const adapterRef = ref(adapter);
  watchEffect(() => {
    adapterRef.value = adapter;
  });

  const cloud = adapter.cloud ?? autoCloud;
  if (!cloud) return new InMemoryThreadListAdapter();

  return {
    list: async () => {
      const { threads } = await cloud.threads.list();
      return {
        threads: threads.map((t) => ({
          status: t.is_archived ? "archived" : "regular",
          remoteId: t.id,
          title: t.title,
          externalId: t.external_id ?? undefined,
        })),
      };
    },

    initialize: async () => {
      const createTask = adapter.create?.() ?? Promise.resolve();
      const t = await createTask;
      const external_id = t ? t.externalId : undefined;
      const { thread_id: remoteId } = await cloud.threads.create({
        last_message_at: new Date(),
        external_id,
      });

      return { externalId: external_id, remoteId: remoteId };
    },

    rename: async (threadId, newTitle) => {
      return cloud.threads.update(threadId, { title: newTitle });
    },
    archive: async (threadId) => {
      return cloud.threads.update(threadId, { is_archived: true });
    },
    unarchive: async (threadId) => {
      return cloud.threads.update(threadId, { is_archived: false });
    },
    delete: async (threadId) => {
      await adapter.delete?.(threadId);
      return cloud.threads.delete(threadId);
    },

    generateTitle: async (threadId, messages) => {
      return cloud.runs.stream({
        thread_id: threadId,
        assistant_id: "system/thread_title",
        messages: messages, // TODO serialize these to a more efficient format
      });
    },

    unstable_Provider: defineComponent({
      name: "CloudThreadListAdapterProvider",
      setup(_, { slots }) {
        const cloudRef = computed(() => adapterRef.value.cloud ?? autoCloud!);
        const history = useAssistantCloudThreadHistoryAdapter(cloudRef as Ref<AssistantCloud>);
        
        // Provide runtime adapters
        provideRuntimeAdapters({ history: ref(history) });

        return () => slots.default?.();
      },
    }),
  };
};