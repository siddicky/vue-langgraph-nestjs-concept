import { provide, inject, Ref, InjectionKey } from "vue";
import { ThreadHistoryAdapter } from "./thread-history/ThreadHistoryAdapter";
import { ModelContextProvider } from "../../model-context";

export type RuntimeAdapters = {
  modelContext?: Ref<ModelContextProvider | undefined>;
  history?: Ref<ThreadHistoryAdapter | undefined>;
};

const RuntimeAdaptersKey: InjectionKey<RuntimeAdapters> = Symbol("RuntimeAdapters");

export function provideRuntimeAdapters(adapters: RuntimeAdapters) {
  const existing = inject(RuntimeAdaptersKey, null);
  const merged: RuntimeAdapters = {
    modelContext: adapters.modelContext || existing?.modelContext,
    history: adapters.history || existing?.history,
  };
  provide(RuntimeAdaptersKey, merged);
  return merged;
}

export function useRuntimeAdapters(): RuntimeAdapters | null {
  return inject(RuntimeAdaptersKey, null);
}