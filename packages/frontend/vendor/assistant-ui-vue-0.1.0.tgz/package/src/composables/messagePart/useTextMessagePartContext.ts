import { inject, provide, InjectionKey } from 'vue';

export interface TextMessagePartContextValue {
  text: string;
  isRunning: boolean;
}

export const TEXT_MESSAGE_PART_CONTEXT_KEY: InjectionKey<TextMessagePartContextValue> = Symbol('TextMessagePartContext');

export function provideTextMessagePartContext(value: TextMessagePartContextValue) {
  provide(TEXT_MESSAGE_PART_CONTEXT_KEY, value);
}

export function useTextMessagePartContext(options?: { optional?: boolean }) {
  const context = inject(TEXT_MESSAGE_PART_CONTEXT_KEY, null);
  
  if (!context && !options?.optional) {
    throw new Error(
      'useTextMessagePartContext must be used within a TextMessagePart provider'
    );
  }
  
  return context;
}