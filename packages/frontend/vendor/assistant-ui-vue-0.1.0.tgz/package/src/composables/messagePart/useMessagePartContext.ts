import { inject, provide, InjectionKey, Ref, computed } from 'vue';
import type { MessagePartRuntime } from '../../api/MessagePartRuntime';

export interface MessagePartContextValue {
  runtime: Ref<MessagePartRuntime | null>;
}

export const MESSAGE_PART_CONTEXT_KEY: InjectionKey<MessagePartContextValue> = Symbol('MessagePartContext');

export function provideMessagePartContext(value: MessagePartContextValue) {
  provide(MESSAGE_PART_CONTEXT_KEY, value);
}

export function useMessagePartContext(options?: { optional?: boolean }) {
  const context = inject(MESSAGE_PART_CONTEXT_KEY, null);
  
  if (!context && !options?.optional) {
    throw new Error(
      'useMessagePartContext must be used within a MessagePart component'
    );
  }
  
  if (!context) return null;
  
  // Return an object with the expected properties
  return {
    messagePart: computed(() => context.runtime.value?.getState()),
    messagePartRuntime: context.runtime.value
  };
}

export function useMessagePartRuntime(options?: { optional?: boolean }) {
  const context = useMessagePartContext(options);
  return computed(() => context?.messagePartRuntime ?? null);
}

export function useMessagePart() {
  const runtime = useMessagePartRuntime();
  
  return computed(() => {
    if (!runtime.value) return null;
    return runtime.value.getState();
  });
}