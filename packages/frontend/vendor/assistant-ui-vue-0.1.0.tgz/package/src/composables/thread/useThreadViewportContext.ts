import { inject, computed, type ComputedRef } from 'vue';
import type { ThreadViewport } from '../../stores/ThreadViewport';
import { THREAD_VIEWPORT_KEY } from '../../context/keys';

/**
 * Hook to access the thread viewport context.
 * Returns an object with threadViewport and threadViewportStore properties.
 */
export function useThreadViewportContext(options?: { optional?: boolean }) {
  const viewport = inject<ComputedRef<ThreadViewport | undefined>>(THREAD_VIEWPORT_KEY, undefined as any);
  
  if (!viewport && !options?.optional) {
    throw new Error('useThreadViewportContext must be used within a ThreadViewportProvider');
  }
  
  if (!viewport) return null;
  
  // Return an object with the expected properties
  return {
    threadViewport: viewport.value,
    threadViewportStore: computed(() => viewport.value)
  };
}

// Export for backward compatibility
export function useThreadViewportStore() {
  const context = useThreadViewportContext();
  return context?.threadViewportStore;
}

// Specific viewport state accessors
export function useThreadViewportState() {
  const context = useThreadViewportContext({ optional: true });
  const viewport = context?.threadViewport;
  return {
    isAtBottom: computed(() => viewport?.isAtBottom ?? false),
    scrollToBottom: () => viewport?.scrollToBottom?.(),
    onScrollToBottom: (callback: () => void) => {
      return viewport?.onScrollToBottom?.(callback);
    }
  };
}