import { describe, it, expect, vi } from 'vitest';
import { mount } from '@vue/test-utils';
import { defineComponent, provide, computed } from 'vue';
import { useThreadRuntime } from './useThreadRuntime';
import { THREAD_RUNTIME_KEY } from '../../context/keys';
import type { ThreadRuntime } from '../../api/ThreadRuntime';

// Mock ThreadRuntime
const createMockThreadRuntime = (): ThreadRuntime => ({
  getState: vi.fn(),
  append: vi.fn(),
  startRun: vi.fn(),
  cancelRun: vi.fn(),
  getModelConfig: vi.fn(),
  composer: {
    getState: vi.fn(),
    setText: vi.fn(),
    addAttachment: vi.fn(),
    removeAttachment: vi.fn(),
    reset: vi.fn(),
    send: vi.fn(),
    cancel: vi.fn(),
    focus: vi.fn(),
    subscribe: vi.fn()
  },
  capabilities: computed(() => ({
    edit: false,
    reload: true,
    cancel: true,
    unstable_copy: true,
    speech: false,
    attachments: false,
    feedback: false
  })),
  messages: [],
  subscribe: vi.fn(),
  isDisabled: false,
  isRunning: false,
  unstable_synchronizer: undefined,
  speech: undefined,
  submitFeedback: vi.fn(),
  getEditComposer: vi.fn(),
  beginEdit: vi.fn()
} as any);

describe('useThreadRuntime', () => {
  it('returns runtime when provided', () => {
    const mockRuntime = createMockThreadRuntime();
    
    const TestComponent = defineComponent({
      setup() {
        const runtime = useThreadRuntime();
        // The runtime is a ComputedRef, access its value
        return { runtimeValue: runtime?.value };
      },
      template: '<div>Test</div>'
    });

    const ProviderComponent = defineComponent({
      setup() {
        provide(THREAD_RUNTIME_KEY, computed(() => mockRuntime));
      },
      components: { TestComponent },
      template: '<TestComponent />'
    });

    const wrapper = mount(ProviderComponent);
    const testComponent = wrapper.findComponent(TestComponent);
    
    expect(testComponent.vm.runtimeValue).toBeDefined();
    expect(testComponent.vm.runtimeValue).toBe(mockRuntime);
  });

  it('throws error when runtime not provided and not optional', () => {
    const TestComponent = defineComponent({
      setup() {
        useThreadRuntime();
        return {};
      },
      template: '<div>Test</div>'
    });

    expect(() => mount(TestComponent)).toThrowError(
      'ThreadRuntime not provided. Make sure to use ThreadRuntimeProvider in a parent component.'
    );
  });

  it('returns null when runtime not provided and optional is true', () => {
    const TestComponent = defineComponent({
      setup() {
        const runtime = useThreadRuntime({ optional: true });
        // The runtime is null when not provided and optional
        return { runtime };
      },
      template: '<div>Test</div>'
    });

    const wrapper = mount(TestComponent);
    expect(wrapper.vm.runtime).toBeNull();
  });

  it('returns runtime when provided and optional is true', () => {
    const mockRuntime = createMockThreadRuntime();
    
    const TestComponent = defineComponent({
      setup() {
        const runtime = useThreadRuntime({ optional: true });
        // The runtime is a ComputedRef or null, access its value if it exists
        return { runtimeValue: runtime?.value };
      },
      template: '<div>Test</div>'
    });

    const ProviderComponent = defineComponent({
      setup() {
        provide(THREAD_RUNTIME_KEY, computed(() => mockRuntime));
      },
      components: { TestComponent },
      template: '<TestComponent />'
    });

    const wrapper = mount(ProviderComponent);
    const testComponent = wrapper.findComponent(TestComponent);
    
    expect(testComponent.vm.runtimeValue).toBeDefined();
    expect(testComponent.vm.runtimeValue).toBe(mockRuntime);
  });

  it('runtime methods can be called', () => {
    const mockRuntime = createMockThreadRuntime();
    
    const TestComponent = defineComponent({
      setup() {
        const runtime = useThreadRuntime();
        
        // Call runtime methods
        runtime.value.append({ role: 'user', content: [{ type: 'text', text: 'Test message' }] });
        runtime.value.cancelRun();
        
        return { runtimeValue: runtime?.value };
      },
      template: '<div>Test</div>'
    });

    const ProviderComponent = defineComponent({
      setup() {
        provide(THREAD_RUNTIME_KEY, computed(() => mockRuntime));
      },
      components: { TestComponent },
      template: '<TestComponent />'
    });

    mount(ProviderComponent);
    
    expect(mockRuntime.append).toHaveBeenCalledWith({
      role: 'user',
      content: [{ type: 'text', text: 'Test message' }]
    });
    expect(mockRuntime.cancelRun).toHaveBeenCalled();
  });
});