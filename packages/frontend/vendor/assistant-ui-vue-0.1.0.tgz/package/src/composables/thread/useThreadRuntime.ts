import { inject, type ComputedRef } from 'vue';
import type { ThreadRuntime } from '../../api/ThreadRuntime';
import { THREAD_RUNTIME_KEY } from '../../context/keys';

/**
 * Hook to access the ThreadRuntime from the current context.
 *
 * The ThreadRuntime provides access to thread-level state and actions,
 * including message management, thread state, and composer functionality.
 *
 * @param options Configuration options
 * @param options.optional Whether the hook should return null if no context is found
 * @returns The ThreadRuntime instance, or null if optional is true and no context exists
 *
 * @example
 * ```vue
 * <script setup>
 * const runtime = useThreadRuntime();
 *
 * const handleSendMessage = (text: string) => {
 *   runtime.value.append({ role: "user", content: [{ type: "text", text }] });
 * };
 * </script>
 * ```
 */
export function useThreadRuntime(options?: {
  optional?: false | undefined;
}): ComputedRef<ThreadRuntime>;
export function useThreadRuntime(options?: {
  optional?: boolean | undefined;
}): ComputedRef<ThreadRuntime> | null;
export function useThreadRuntime(options?: {
  optional?: boolean | undefined;
}): ComputedRef<ThreadRuntime> | null {
  const runtime = inject<ComputedRef<ThreadRuntime> | null>(THREAD_RUNTIME_KEY, null);
  
  if (!runtime && !options?.optional) {
    throw new Error(
      'ThreadRuntime not provided. Make sure to use ThreadRuntimeProvider in a parent component.'
    );
  }
  
  return runtime;
}