import { inject, provide, InjectionKey, Ref, computed } from 'vue';
import type { ThreadRuntime } from '../../api/ThreadRuntime';
import type { ThreadState } from '../../api/ThreadRuntime';

export interface ThreadContextValue {
  runtime: Ref<ThreadRuntime>;
}

export const THREAD_CONTEXT_KEY: InjectionKey<ThreadContextValue> = Symbol('ThreadContext');

export function provideThreadContext(value: ThreadContextValue) {
  provide(THREAD_CONTEXT_KEY, value);
}

export function useThreadContext(options?: { optional?: boolean }) {
  const context = inject(THREAD_CONTEXT_KEY, null);
  
  if (!context && !options?.optional) {
    throw new Error(
      'useThreadContext must be used within a Thread component'
    );
  }
  
  if (!context) return null;
  
  // Return an object with the expected properties
  return {
    thread: computed(() => context.runtime.value?.getState() as ThreadState),
    threadRuntime: context.runtime.value
  };
}

// useThreadRuntime is exported from ./useThreadRuntime.ts to avoid duplicate exports

export function useThread() {
  const context = useThreadContext();
  
  return computed(() => {
    if (!context?.thread.value) return null;
    return context.thread.value;
  });
}