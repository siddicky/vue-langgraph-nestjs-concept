import { ref, Ref, watch, onMounted, onUnmounted } from 'vue';
import { useThreadRuntime } from './useThreadRuntime';
import { useThreadViewportStore } from './useThreadViewportContext';
import { useOnResizeContent } from '../../utils/hooks/useOnResizeContent';
import { useOnScrollToBottom } from '../../utils/hooks/useOnScrollToBottom';

export interface UseThreadViewportAutoScrollOptions {
  autoScroll?: boolean;
}

export function useThreadViewportAutoScroll<TElement extends HTMLElement = HTMLDivElement>(
  options: UseThreadViewportAutoScrollOptions = {}
): Ref<TElement | undefined> {
  const { autoScroll = true } = options;
  
  const elementRef = ref<TElement>();
  const threadViewportStore = useThreadViewportStore();
  const lastScrollTop = ref<number>(0);
  const isScrollingToBottomRef = ref(false);
  
  const scrollToBottom = (behavior: ScrollBehavior = 'auto') => {
    const element = elementRef.value;
    if (!element || !autoScroll) return;
    
    isScrollingToBottomRef.value = true;
    element.scrollTo({ top: element.scrollHeight, behavior });
  };
  
  const handleScroll = () => {
    const element = elementRef.value;
    if (!element) return;
    
    const viewport = threadViewportStore?.value;
    if (!viewport) return;
    
    const isAtBottom = viewport.isAtBottom;
    const newIsAtBottom = 
      element.scrollHeight - element.scrollTop <= element.clientHeight + 1;
    
    if (!newIsAtBottom && lastScrollTop.value < element.scrollTop) {
      // ignore scroll down
    } else {
      if (newIsAtBottom) {
        isScrollingToBottomRef.value = false;
      }
      
      if (newIsAtBottom !== isAtBottom) {
        viewport.isAtBottom = newIsAtBottom;
      }
    }
    
    lastScrollTop.value = element.scrollTop;
  };
  
  // Handle content resize
  useOnResizeContent(elementRef, () => {
    const viewport = threadViewportStore?.value;
    if (
      isScrollingToBottomRef.value ||
      (viewport && viewport.isAtBottom)
    ) {
      scrollToBottom('instant');
    }
    
    handleScroll();
  });
  
  // Handle scroll to bottom requests
  useOnScrollToBottom(() => {
    scrollToBottom('auto');
  });
  
  // Auto-scroll on run start
  const threadRuntime = useThreadRuntime();
  let unsubscribe: (() => void) | undefined;
  
  onMounted(() => {
    const element = elementRef.value;
    if (element) {
      element.addEventListener('scroll', handleScroll);
    }
    
    if (threadRuntime.value) {
      unsubscribe = threadRuntime.value.unstable_on('run-start', () => scrollToBottom('auto'));
    }
  });
  
  onUnmounted(() => {
    const element = elementRef.value;
    if (element) {
      element.removeEventListener('scroll', handleScroll);
    }
    
    if (unsubscribe) {
      unsubscribe();
    }
  });
  
  // Watch for element changes
  watch(elementRef, (newElement, oldElement) => {
    if (oldElement) {
      oldElement.removeEventListener('scroll', handleScroll);
    }
    if (newElement) {
      newElement.addEventListener('scroll', handleScroll);
      handleScroll(); // Initialize state
    }
  });
  
  return elementRef;
}