import { computed, type ComputedRef } from 'vue';
import { useMessageContext } from './useMessageContext';
import type { CompleteAttachment } from '../../types';

/**
 * Hook to access message attachments.
 */
export function useMessageAttachment<T>(
  selector: (attachment: CompleteAttachment | undefined) => T,
  attachmentIndex?: number
): ComputedRef<T> {
  const context = useMessageContext();
  const message = context?.message;
  
  return computed(() => {
    const attachments = message?.value?.attachments;
    const index = attachmentIndex ?? 0;
    const attachment = attachments?.[index];
    return selector(attachment);
  });
}

export function useMessageAttachments(): ComputedRef<readonly CompleteAttachment[]> {
  const context = useMessageContext();
  const message = context?.message;
  return computed(() => message?.value?.attachments ?? []);
}