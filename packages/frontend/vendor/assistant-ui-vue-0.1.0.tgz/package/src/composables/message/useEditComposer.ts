import { computed } from 'vue';
import { useMessageRuntime } from './useMessageContext';

export function useEditComposer() {
  const messageRuntime = useMessageRuntime();
  
  return computed(() => {
    if (!messageRuntime) return null;
    return messageRuntime.composer;
  });
}