import { inject, provide, InjectionKey, Ref, computed } from 'vue';
import type { MessageRuntime } from '../../api/MessageRuntime';
import type { MessageUtilsState } from '../../stores/MessageUtils';
import type { MessageState } from '../../api/MessageRuntime';

export interface MessageContextValue {
  runtime: Ref<MessageRuntime>;
  utils: MessageUtilsState;
}

export const MESSAGE_CONTEXT_KEY: InjectionKey<MessageContextValue> = Symbol('MessageContext');

export function provideMessageContext(value: MessageContextValue) {
  provide(MESSAGE_CONTEXT_KEY, value);
}

export function useMessageContext(options?: { optional?: boolean }) {
  const context = inject(MESSAGE_CONTEXT_KEY, null);
  
  if (!context && !options?.optional) {
    throw new Error(
      'useMessageContext must be used within a component passed to <ThreadMessages components={...} />'
    );
  }
  
  if (!context) return null;
  
  // Return an object with the expected properties
  return {
    message: computed(() => context.runtime.value?.getState() as MessageState),
    messageRuntime: context.runtime.value,
    messageUtils: computed(() => context.utils)
  };
}

export function useMessageRuntime(options?: { optional?: boolean }) {
  const context = useMessageContext(options);
  return context?.messageRuntime ?? null;
}

export function useMessage<T = any>(selector?: (state: any) => T) {
  const runtime = useMessageRuntime();
  if (!runtime) return null;
  
  // This would need proper reactive state management
  // For now, returning the runtime state directly
  const state = runtime.getState();
  return selector ? selector(state) : state;
}