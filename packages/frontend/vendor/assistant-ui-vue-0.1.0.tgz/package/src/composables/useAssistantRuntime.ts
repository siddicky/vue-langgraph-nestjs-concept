import { inject, type ComputedRef } from 'vue';
import type { AssistantRuntime } from '../api/AssistantRuntime';
import { ASSISTANT_RUNTIME_KEY, ASSISTANT_TOOL_UIS_KEY } from '../context/keys';
import type { AssistantToolUIsState } from '../stores/AssistantToolUIs';

export function useAssistantRuntime(): ComputedRef<AssistantRuntime> {
  const runtime = inject<ComputedRef<AssistantRuntime>>(ASSISTANT_RUNTIME_KEY);
  if (!runtime) {
    throw new Error('AssistantRuntime not provided. Make sure to use AssistantRuntimeProvider in a parent component.');
  }
  return runtime;
}

export function useAssistantToolUIs(): AssistantToolUIsState {
  const toolUIs = inject<AssistantToolUIsState>(ASSISTANT_TOOL_UIS_KEY);
  if (!toolUIs) {
    throw new Error('AssistantToolUIs not provided. Make sure to use AssistantRuntimeProvider in a parent component.');
  }
  return toolUIs;
}