import { inject, provide, ComputedRef, computed } from 'vue';
import { ThreadListItemRuntime } from '../../api/ThreadListItemRuntime';

const ThreadListItemContextKey = Symbol('ThreadListItemContext');

export function provideThreadListItemRuntime(runtime: ComputedRef<ThreadListItemRuntime | null>) {
  provide(ThreadListItemContextKey, runtime);
}

export function useThreadListItemRuntime(options?: {
  optional?: boolean;
}): ComputedRef<ThreadListItemRuntime | null> {
  const runtime = inject<ComputedRef<ThreadListItemRuntime | null>>(
    ThreadListItemContextKey,
    () => computed(() => null),
    true
  );

  if (!options?.optional && !runtime?.value) {
    throw new Error("ThreadListItemContext not found");
  }

  return runtime;
}

// Alias for backward compatibility
export const useThreadListItemContext = useThreadListItemRuntime;