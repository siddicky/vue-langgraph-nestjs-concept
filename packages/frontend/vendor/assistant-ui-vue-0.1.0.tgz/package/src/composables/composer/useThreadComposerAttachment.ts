import { computed, type ComputedRef } from 'vue';
import { useComposerRuntime } from './useComposerContext';
import type { Attachment } from '../../types';

/**
 * Hook to access thread composer attachments.
 */
export function useThreadComposerAttachment<T>(
  selector: (attachment: Attachment | undefined) => T,
  attachmentIndex?: number
): ComputedRef<T> {
  const composerRuntime = useComposerRuntime();
  
  return computed(() => {
    if (!composerRuntime.value || composerRuntime.value.type !== 'thread') {
      return selector(undefined);
    }
    const attachments = composerRuntime.value.getState().attachments;
    const index = attachmentIndex ?? 0;
    const attachment = attachments?.[index];
    return selector(attachment);
  });
}

export function useThreadComposerAttachments(): ComputedRef<readonly Attachment[]> {
  const composerRuntime = useComposerRuntime();
  
  return computed(() => {
    if (!composerRuntime.value || composerRuntime.value.type !== 'thread') {
      return [];
    }
    return composerRuntime.value.getState().attachments ?? [];
  });
}