
import { computed, ComputedRef } from 'vue';
import { useMessageContext } from '../message/useMessageContext';
import { useThreadContext } from '../thread/useThreadContext';
import { ComposerRuntime } from '../../api/ComposerRuntime';

/**
 * Hook to access the ComposerRuntime from the current context.
 *
 * The ComposerRuntime provides access to composer state and actions for message
 * composition, including text input, attachments, and sending functionality.
 * This hook automatically resolves to either the message's edit composer or
 * the thread's main composer depending on the context.
 *
 * @param options Configuration options
 * @param options.optional Whether the hook should return null if no context is found
 * @returns The ComposerRuntime instance, or null if optional is true and no context exists
 *
 * @example
 * ```vue
 * <script setup>
 * import { useComposerRuntime } from '@assistant-ui/vue';
 * 
 * const runtime = useComposerRuntime();
 * 
 * const handleSend = () => {
 *   if (runtime.value?.getState().canSend) {
 *     runtime.value?.send();
 *   }
 * };
 * 
 * const handleCancel = () => {
 *   if (runtime.value?.getState().canCancel) {
 *     runtime.value?.cancel();
 *   }
 * };
 * </script>
 * ```
 */
export function useComposerRuntime(options?: {
  optional?: boolean;
}): ComputedRef<ComposerRuntime | null> {
  const messageContext = useMessageContext({ optional: true });
  const threadContext = useThreadContext(options);
  
  return computed(() => {
    const messageRuntime = messageContext?.messageRuntime;
    const threadRuntime = threadContext?.threadRuntime;
    
    if (messageRuntime) {
      return messageRuntime.composer;
    }
    
    return threadRuntime?.composer ?? null;
  });
}

/**
 * Hook to access the current composer state.
 *
 * This hook provides reactive access to the composer's state, including text content,
 * attachments, editing status, and send/cancel capabilities.
 *
 * @param selector Optional selector function to pick specific state properties
 * @returns The selected composer state or the entire composer state if no selector provided
 *
 * @example
 * ```vue
 * <script setup>
 * import { useComposer } from '@assistant-ui/vue';
 * 
 * const text = useComposer((state) => state.text);
 * const canSend = useComposer((state) => state.canSend);
 * const attachmentCount = useComposer((state) => state.attachments.length);
 * </script>
 * ```
 */
export function useComposer<TSelected = any>(
  selector?: (state: any) => TSelected
): ComputedRef<TSelected | undefined> {
  const runtime = useComposerRuntime();
  
  return computed(() => {
    if (!runtime.value) return undefined;
    const state = runtime.value.getState();
    return selector ? selector(state) : state;
  }) as ComputedRef<TSelected | undefined>;
}

// Hook for components expecting useComposerContext with proper structure
export function useComposerContext(options?: { optional?: boolean }) {
  const messageContext = useMessageContext({ optional: true });
  const threadContext = useThreadContext(options);
  
  const composerRuntime = computed(() => {
    const messageRuntime = messageContext?.messageRuntime;
    const threadRuntime = threadContext?.threadRuntime;
    
    if (messageRuntime?.composer) {
      return messageRuntime.composer;
    }
    
    return threadRuntime?.composer ?? null;
  });
  
  if (!composerRuntime.value && !options?.optional) {
    return null;
  }
  
  return {
    composer: computed(() => composerRuntime.value?.getState()),
    composerRuntime: composerRuntime.value
  };
}