import { inject, computed, type ComputedRef } from 'vue'
import type { AttachmentRuntime } from '../../api'

export interface AttachmentContext {
  attachment: ComputedRef<any>
  remove: () => void
  runtime: AttachmentRuntime | null
}

export function useAttachmentContext(): AttachmentContext | undefined {
  const runtime = inject<AttachmentRuntime | null>('attachmentRuntime', null)
  
  if (!runtime) {
    return undefined
  }
  
  const attachment = computed(() => runtime.getState())
  
  return {
    attachment,
    remove: () => runtime.remove(),
    runtime
  }
}

export function useAttachmentRuntime(): AttachmentRuntime | null {
  return inject<AttachmentRuntime | null>('attachmentRuntime', null)
}