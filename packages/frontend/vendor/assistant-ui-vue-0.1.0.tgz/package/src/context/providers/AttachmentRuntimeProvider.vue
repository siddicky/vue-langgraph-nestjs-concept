<template>
  <slot />
</template>

<script setup lang="ts">
import { computed, provide, watch } from 'vue';
import type { AttachmentRuntime } from '../../api/AttachmentRuntime';
import { ATTACHMENT_RUNTIME_KEY } from '../keys';

interface Props {
  runtime: AttachmentRuntime;
}

const props = defineProps<Props>();

// Create a computed ref for the runtime
const runtimeRef = computed(() => props.runtime);

// Provide the runtime
provide(ATTACHMENT_RUNTIME_KEY, runtimeRef);

// Watch for runtime changes and ensure bindings
watch(
  () => props.runtime,
  (runtime) => {
    if (runtime && typeof runtime.subscribe === 'function') {
      // Runtime is already bound
    }
  },
  { immediate: true }
);
</script>