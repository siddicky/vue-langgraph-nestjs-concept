<template>
  <slot />
</template>

<script setup lang="ts">
import { computed, provide, watch } from 'vue';
import type { ThreadListItemRuntime } from '../../api/ThreadListItemRuntime';
import { THREAD_LIST_ITEM_RUNTIME_KEY } from '../keys';

interface Props {
  runtime: ThreadListItemRuntime;
}

const props = defineProps<Props>();

// Create a computed ref for the runtime
const runtimeRef = computed(() => props.runtime);

// Provide the runtime
provide(THREAD_LIST_ITEM_RUNTIME_KEY, runtimeRef);

// Watch for runtime changes
watch(
  () => props.runtime,
  (runtime) => {
    if (runtime && typeof runtime.subscribe === 'function') {
      // Runtime is already bound
    }
  },
  { immediate: true }
);
</script>