<template>
  <component v-if="RenderComponent" :is="RenderComponent" />
  <ThreadRuntimeProvider
    :runtime="runtime.thread"
    :list-item-runtime="runtime.threads.mainItem"
  >
    <slot />
  </ThreadRuntimeProvider>
</template>

<script setup lang="ts">
import { computed, provide, watch, onMounted } from 'vue';
import type { AssistantRuntime } from '../../api/AssistantRuntime';
import ThreadRuntimeProvider from './ThreadRuntimeProvider.vue';
import { makeAssistantToolUIsStore } from '../../stores/AssistantToolUIs';
import type { AssistantRuntimeCore } from '../../runtimes/core/AssistantRuntimeCore';
import { ASSISTANT_RUNTIME_KEY, ASSISTANT_TOOL_UIS_KEY } from '../keys';

interface Props {
  runtime: AssistantRuntime;
}

const props = defineProps<Props>();

// Create a computed ref for the runtime
const runtimeRef = computed(() => props.runtime);

// Provide the runtime
provide(ASSISTANT_RUNTIME_KEY, runtimeRef);

// Create and provide tool UIs store
const toolUIsStore = makeAssistantToolUIsStore();
provide(ASSISTANT_TOOL_UIS_KEY, toolUIsStore);

// Helper function to get render component
const getRenderComponent = (runtime: AssistantRuntime) => {
  return (runtime as { _core?: AssistantRuntimeCore })._core?.RenderComponent;
};

// Watch for runtime changes and ensure bindings
watch(
  () => props.runtime,
  (runtime) => {
    if (runtime) {
      // Ensure bindings similar to React version
      if ('subscribe' in runtime && typeof runtime.subscribe === 'function') {
        // Runtime is already bound
      }
      if (runtime.threads && 'subscribe' in runtime.threads && typeof runtime.threads.subscribe === 'function') {
        // Threads are already bound
      }
    }
  },
  { immediate: true }
);

// Handle RenderComponent if it exists
const RenderComponent = computed(() => getRenderComponent(props.runtime));

onMounted(() => {
  // Any initialization logic can go here
});
</script>