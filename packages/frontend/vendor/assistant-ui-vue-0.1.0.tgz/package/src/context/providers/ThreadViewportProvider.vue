<template>
  <slot />
</template>

<script setup lang="ts">
import { ref, provide, onMounted, onUnmounted } from 'vue';
import { ThreadViewport } from '../../stores/ThreadViewport';
import { useThreadRuntime } from '../../composables/thread/useThreadRuntime';
import { THREAD_VIEWPORT_KEY } from '../keys';

// Get thread runtime
const threadRuntime = useThreadRuntime();

// Create viewport store
const viewport = ref<ThreadViewport | null>(null);

// Initialize viewport on mount
onMounted(() => {
  viewport.value = new ThreadViewport(threadRuntime.value);
});

// Clean up on unmount
onUnmounted(() => {
  if (viewport.value) {
    viewport.value.unsubscribe?.();
    viewport.value = null;
  }
});

// Provide the viewport
provide(THREAD_VIEWPORT_KEY, viewport);
</script>