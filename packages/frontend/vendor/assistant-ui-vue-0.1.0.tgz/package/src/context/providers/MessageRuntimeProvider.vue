<template>
  <slot />
</template>

<script setup lang="ts">
import { computed, provide, watch } from 'vue';
import type { MessageRuntime } from '../../api/MessageRuntime';
import { MessageUtils } from '../../stores/MessageUtils';
import { MESSAGE_RUNTIME_KEY, MESSAGE_UTILS_KEY } from '../keys';

interface Props {
  runtime: MessageRuntime;
}

const props = defineProps<Props>();

// Create a computed ref for the runtime
const runtimeRef = computed(() => props.runtime);

// Provide the runtime
provide(MESSAGE_RUNTIME_KEY, runtimeRef);

// Create and provide message utils store
const messageUtils = new MessageUtils();
provide(MESSAGE_UTILS_KEY, messageUtils);

// Watch for runtime changes and ensure bindings
watch(
  () => props.runtime,
  (runtime) => {
    if (runtime && typeof runtime.subscribe === 'function') {
      // Runtime is already bound
    }
  },
  { immediate: true }
);
</script>