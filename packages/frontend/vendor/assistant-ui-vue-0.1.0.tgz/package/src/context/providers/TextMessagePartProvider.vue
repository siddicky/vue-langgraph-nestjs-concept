<template>
  <slot />
</template>

<script setup lang="ts">
import { computed, provide, reactive, watch } from 'vue';
import type { MessagePartStatus } from '../../types/AssistantTypes';
import { MessagePartRuntimeImpl } from '../../api/MessagePartRuntime';
import { TEXT_MESSAGE_PART_KEY, TEXT_MESSAGE_PART_RUNTIME_KEY } from '../keys';

interface Props {
  text: string;
  isRunning?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  isRunning: false
});

const COMPLETE_STATUS: MessagePartStatus = {
  type: 'complete',
};

const RUNNING_STATUS: MessagePartStatus = {
  type: 'running',
};

// Create reactive state for the message part
const messagePartState = reactive({
  status: props.isRunning ? RUNNING_STATUS : COMPLETE_STATUS,
  type: 'text' as const,
  text: props.text,
});

// Create the runtime
const runtime = new MessagePartRuntimeImpl({
  path: {
    ref: 'text',
    threadSelector: { type: 'main' },
    messageSelector: { type: 'messageId', messageId: '' },
    messagePartSelector: { type: 'index', index: 0 },
  },
  getState: () => messagePartState,
  subscribe: (callback: () => void) => {
    // Vue's reactivity will handle this
    watch(() => messagePartState, callback, { deep: true });
    return () => {
      // Cleanup would go here if needed
    };
  },
});

// Provide the runtime
const runtimeRef = computed(() => runtime);
provide(TEXT_MESSAGE_PART_RUNTIME_KEY, runtimeRef);

// Provide the state
provide(TEXT_MESSAGE_PART_KEY, messagePartState);

// Watch for prop changes and update state
watch(
  () => [props.text, props.isRunning] as const,
  ([text, isRunning]) => {
    messagePartState.text = text;
    messagePartState.status = isRunning ? RUNNING_STATUS : COMPLETE_STATUS;
  }
);
</script>