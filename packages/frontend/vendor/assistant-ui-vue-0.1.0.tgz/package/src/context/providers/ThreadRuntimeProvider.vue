<template>
  <ThreadListItemRuntimeProvider :runtime="listItemRuntime">
    <ThreadViewportProvider>
      <slot />
    </ThreadViewportProvider>
  </ThreadListItemRuntimeProvider>
</template>

<script setup lang="ts">
import { computed, provide, watch } from 'vue';
import type { ThreadRuntime } from '../../api/ThreadRuntime';
import type { ThreadListItemRuntime } from '../../api/ThreadListItemRuntime';
import ThreadListItemRuntimeProvider from './ThreadListItemRuntimeProvider.vue';
import ThreadViewportProvider from './ThreadViewportProvider.vue';
import { THREAD_RUNTIME_KEY } from '../keys';

interface Props {
  runtime: ThreadRuntime;
  listItemRuntime: ThreadListItemRuntime;
}

const props = defineProps<Props>();

// Create a computed ref for the runtime
const runtimeRef = computed(() => props.runtime);

// Provide the runtime
provide(THREAD_RUNTIME_KEY, runtimeRef);

// Watch for runtime changes and ensure bindings
watch(
  () => props.runtime,
  (runtime) => {
    if (runtime) {
      // Ensure bindings similar to React version
      if (typeof runtime.subscribe === 'function') {
        // Runtime is already bound
      }
      if (runtime.composer && typeof runtime.composer.subscribe === 'function') {
        // Composer is already bound
      }
    }
  },
  { immediate: true }
);
</script>