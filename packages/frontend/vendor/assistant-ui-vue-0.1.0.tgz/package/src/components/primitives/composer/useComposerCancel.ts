import { computed, ComputedRef } from 'vue';
import { useComposer, useComposerRuntime } from '../../../composables/composer/useComposerContext';

/**
 * Hook that provides a cancel function for the composer.
 * Returns null when canceling is disabled (!composer.canCancel).
 * 
 * @returns A computed ref containing the cancel function or null
 */
export function useComposerCancel(): ComputedRef<(() => void) | null> {
  const composerRuntime = useComposerRuntime();
  
  const disabled = useComposer((c) => !c?.canCancel);

  return computed(() => {
    if (disabled.value || !composerRuntime.value) return null;
    return () => composerRuntime.value!.cancel();
  });
}