<template>
  <div class="attachment-root" v-bind="$attrs">
    <slot />
  </div>
</template>

<script setup lang="ts">
import { provide } from 'vue'
import { useAttachmentContext } from '../../../composables'

// This component provides the attachment context to its children
// The actual attachment data should come from the parent context
const attachmentContext = useAttachmentContext()

// Re-provide the context for child components
if (attachmentContext) {
  provide('attachment', attachmentContext)
}
</script>