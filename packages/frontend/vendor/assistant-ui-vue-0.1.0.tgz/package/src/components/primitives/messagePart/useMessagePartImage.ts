import { computed } from 'vue'
import { useMessagePartContext } from '../../../composables'
import type { MessagePartState } from '../../../api/MessagePartRuntime'
import type { ImageMessagePart } from '../../../types'

export const useMessagePartImage = () => {
  const context = useMessagePartContext()
  
  const image = computed(() => {
    const part = context?.messagePart.value
    if (!part || part.type !== 'image') {
      throw new Error('MessagePartImage can only be used inside image message parts.')
    }
    return part as MessagePartState & ImageMessagePart
  })
  
  return image
}