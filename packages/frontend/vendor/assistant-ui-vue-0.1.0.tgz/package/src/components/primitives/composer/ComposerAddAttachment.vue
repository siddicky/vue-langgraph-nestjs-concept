<template>
  <button
    v-if="!disabled"
    @click="handleAddAttachment"
    :disabled="disabled"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useComposerContext } from '../../../composables'

interface Props {
  multiple?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  multiple: true
})

const context = useComposerContext()
const disabled = computed(() => !context?.composer.value?.isEditing)

const handleAddAttachment = () => {
  if (!context?.composerRuntime) return
  
  const input = document.createElement('input')
  input.type = 'file'
  input.multiple = props.multiple
  input.hidden = true

  const attachmentAccept = context.composerRuntime.getAttachmentAccept()
  if (attachmentAccept !== '*') {
    input.accept = attachmentAccept
  }

  document.body.appendChild(input)

  input.onchange = (e) => {
    const fileList = (e.target as HTMLInputElement).files
    if (!fileList || !context?.composerRuntime) return
    for (const file of fileList) {
      context.composerRuntime.addAttachment(file)
    }
    document.body.removeChild(input)
  }

  input.oncancel = () => {
    if (!input.files || input.files.length === 0) {
      document.body.removeChild(input)
    }
  }

  input.click()
}
</script>