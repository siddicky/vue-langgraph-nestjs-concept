<template>
  <MessagePartRuntimeProvider v-if="runtime" :runtime="runtime">
    <MessagePartComponent :components="components" />
  </MessagePartRuntimeProvider>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useMessageRuntime } from '../../../composables/message/useMessageContext';
import MessagePartRuntimeProvider from '../../../context/providers/MessagePartRuntimeProvider.vue';
import MessagePartComponent from './MessagePartComponent.vue';
import type { MessagePartComponentTypes } from '../../../types/MessagePartComponentTypes';

interface Props {
  index: number;
  components?: MessagePartComponentTypes;
}

const props = defineProps<Props>();

const messageRuntime = useMessageRuntime();

const runtime = computed(() => {
  return messageRuntime?.getMessagePartByIndex(props.index);
});
</script>