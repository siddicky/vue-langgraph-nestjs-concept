<template>
  <button
    :disabled="!callback"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useActionBarReload } from './useActionBarReload';

/**
 * Button component that regenerates/reloads assistant messages.
 * 
 * Only available for assistant messages.
 * Automatically disabled when thread is running or disabled.
 * 
 * @example
 * ```vue
 * <ActionBarReload>Regenerate</ActionBarReload>
 * ```
 */

const callback = useActionBarReload();

const handleClick = () => {
  if (callback.value) {
    callback.value();
  }
};
</script>