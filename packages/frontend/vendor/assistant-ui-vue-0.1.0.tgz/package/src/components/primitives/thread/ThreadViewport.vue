<template>
  <div 
    ref="viewportRef"
    v-bind="$attrs"
    :style="{ overflowY: 'scroll' }"
  >
    <slot />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useThreadViewportAutoScroll } from '../../../composables/thread/useThreadViewportAutoScroll';

/**
 * The scrollable viewport component for thread messages.
 *
 * This component provides the scrollable container for thread messages,
 * handling scroll behavior and viewport-related functionality.
 *
 * @example
 * ```vue
 * <ThreadRoot>
 *   <ThreadViewport>
 *     <ThreadMessages />
 *   </ThreadViewport>
 * </ThreadRoot>
 * ```
 */
defineOptions({
  name: 'ThreadViewport',
  inheritAttrs: true
});

export interface ThreadViewportProps {
  autoScroll?: boolean;
}

const props = withDefaults(defineProps<ThreadViewportProps>(), {
  autoScroll: true
});

const viewportRef = useThreadViewportAutoScroll({
  autoScroll: props.autoScroll
});

const scrollToBottom = (behavior: ScrollBehavior = 'auto') => {
  if (viewportRef.value) {
    viewportRef.value.scrollTo({ 
      top: viewportRef.value.scrollHeight, 
      behavior 
    });
  }
};

defineExpose({
  viewportRef: computed(() => viewportRef.value),
  scrollToBottom
});
</script>