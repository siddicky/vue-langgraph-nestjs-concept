<template>
  <component
    v-if="componentToRender"
    :is="componentToRender"
    v-bind="partProps"
  />
</template>

<script setup lang="ts">
import { computed, defineComponent, h } from 'vue';
import { useMessagePart, useMessagePartRuntime } from '../../../composables/messagePart/useMessagePartContext';
import MessagePartText from '../messagePart/MessagePartText.vue';
import MessagePartImage from '../messagePart/MessagePartImage.vue';
import MessagePartInProgress from '../messagePart/MessagePartInProgress.vue';
import type { MessagePartComponentTypes } from '../../../types/MessagePartComponentTypes';

interface Props {
  components?: MessagePartComponentTypes;
}

const props = withDefaults(defineProps<Props>(), {
  components: () => ({})
});

// Default components
const defaultText = defineComponent({
  name: 'DefaultText',
  setup() {
    return () => h('p', { style: { whiteSpace: 'pre-line' } }, [
      h(MessagePartText),
      h(MessagePartInProgress, () => h('span', { style: { fontFamily: 'revert' } }, ' ●'))
    ]);
  }
});

const defaultReasoning = defineComponent({
  name: 'DefaultReasoning',
  render: () => null
});

const defaultSource = defineComponent({
  name: 'DefaultSource',
  render: () => null
});

const defaultImage = defineComponent({
  name: 'DefaultImage',
  setup() {
    return () => h(MessagePartImage);
  }
});

const defaultFile = defineComponent({
  name: 'DefaultFile',
  render: () => null
});

const defaultAudio = defineComponent({
  name: 'DefaultAudio',
  render: () => null
});

const runtime = useMessagePartRuntime();
const part = useMessagePart();

const componentToRender = computed(() => {
  if (!part.value) return null;
  
  const type = part.value.type;
  
  if (type === 'tool-call') {
    const tools = props.components?.tools;
    if (!tools) return null;
    
    if ('Override' in tools) {
      return tools.Override;
    }
    
    const Tool = tools.by_name?.[part.value.toolName] ?? tools.Fallback;
    return Tool;
  }
  
  switch (type) {
    case 'text':
      return props.components?.Text ?? defaultText;
    case 'reasoning':
      return props.components?.Reasoning ?? defaultReasoning;
    case 'source':
      return props.components?.Source ?? defaultSource;
    case 'image':
      return props.components?.Image ?? defaultImage;
    case 'file':
      return props.components?.File ?? defaultFile;
    case 'audio':
      return props.components?.Unstable_Audio ?? defaultAudio;
    default:
      console.error(`Unknown message part type: ${type}`);
      return null;
  }
});

const partProps = computed(() => {
  if (!part.value) return {};
  
  if (part.value.type === 'tool-call') {
    return {
      ...part.value,
      addResult: (result: any) => runtime.value?.addToolResult(result)
    };
  }
  
  return part.value;
});
</script>