import { computed } from 'vue'
import { useMessagePartContext } from '../../../composables'
import type { MessagePartState } from '../../../api/MessagePartRuntime'
import type { SourceMessagePart } from '../../../types'

export const useMessagePartSource = () => {
  const context = useMessagePartContext()
  
  const source = computed(() => {
    const part = context?.messagePart.value
    if (!part || part.type !== 'source') {
      throw new Error('MessagePartSource can only be used inside source message parts.')
    }
    return part as MessagePartState & SourceMessagePart
  })
  
  return source
}