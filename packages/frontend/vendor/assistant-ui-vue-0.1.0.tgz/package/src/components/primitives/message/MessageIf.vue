<template>
  <template v-if="shouldRender">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessageContext } from '../../../composables'

interface Props {
  user?: boolean
  assistant?: boolean
  system?: boolean
  hasBranches?: boolean
  copied?: boolean
  lastOrHover?: boolean
  last?: boolean
  speaking?: boolean
  hasAttachments?: boolean
  hasContent?: boolean
  submittedFeedback?: 'positive' | 'negative' | null
}

const props = defineProps<Props>()

const context = useMessageContext()

const shouldRender = computed(() => {
  if (!context) return false
  
  const msg = context.message.value
  const runtime = context.messageRuntime.getState()
  const utils = context.messageUtils.value
  
  // Check branch count
  if (props.hasBranches === true && runtime.branchCount < 2) return false
  
  // Check role
  if (props.user && msg.role !== 'user') return false
  if (props.assistant && msg.role !== 'assistant') return false
  if (props.system && msg.role !== 'system') return false
  
  // Check last or hover state
  if (props.lastOrHover === true && !utils.isHovering && !runtime.isLast) return false
  if (props.last !== undefined && props.last !== runtime.isLast) return false
  
  // Check copied state
  if (props.copied === true && !utils.isCopied) return false
  if (props.copied === false && utils.isCopied) return false
  
  // Check speaking state
  if (props.speaking === true && runtime.speech == null) return false
  if (props.speaking === false && runtime.speech != null) return false
  
  // Check attachments
  if (props.hasAttachments === true && 
      (msg.role !== 'user' || !msg.attachments?.length)) return false
  if (props.hasAttachments === false && 
      msg.role === 'user' && !!msg.attachments?.length) return false
  
  // Check content
  if (props.hasContent === true && (!msg.content || msg.content.length === 0)) return false
  if (props.hasContent === false && msg.content && msg.content.length > 0) return false
  
  // Check submitted feedback
  if (props.submittedFeedback !== undefined && 
      (runtime.submittedFeedback?.type ?? null) !== props.submittedFeedback) return false
  
  return true
})
</script>