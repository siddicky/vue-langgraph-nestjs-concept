<template>
  <Transition name="assistant-modal">
    <div
      v-if="isOpen"
      ref="contentRef"
      class="assistant-modal-content"
      :style="floatingStyles"
      v-bind="$attrs"
    >
      <slot />
    </div>
  </Transition>
</template>

<script setup lang="ts">
import { ref, inject, computed, onUnmounted, watch } from 'vue'
import type { Ref } from 'vue'

interface Props {
  side?: 'top' | 'right' | 'bottom' | 'left'
  align?: 'start' | 'center' | 'end'
  sideOffset?: number
  alignOffset?: number
  dismissOnInteractOutside?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  side: 'top',
  align: 'end',
  sideOffset: 0,
  alignOffset: 0,
  dismissOnInteractOutside: false
})

const contentRef = ref<HTMLElement>()
const isOpen = inject<Ref<boolean>>('assistantModalOpen', ref(false))
const setOpen = inject<(value: boolean) => void>('assistantModalSetOpen', () => {})

// Simple positioning styles (can be enhanced with floating-ui later)
const floatingStyles = computed(() => {
  const styles: Record<string, string> = {
    position: 'fixed',
    zIndex: '50'
  }
  
  // Position based on side
  switch (props.side) {
    case 'top':
      styles.bottom = '100%'
      styles.marginBottom = `${props.sideOffset}px`
      break
    case 'bottom':
      styles.top = '100%'
      styles.marginTop = `${props.sideOffset}px`
      break
    case 'left':
      styles.right = '100%'
      styles.marginRight = `${props.sideOffset}px`
      break
    case 'right':
      styles.left = '100%'
      styles.marginLeft = `${props.sideOffset}px`
      break
  }
  
  // Align based on alignment
  if (props.side === 'top' || props.side === 'bottom') {
    switch (props.align) {
      case 'start':
        styles.left = `${props.alignOffset}px`
        break
      case 'center':
        styles.left = '50%'
        styles.transform = 'translateX(-50%)'
        break
      case 'end':
        styles.right = `${props.alignOffset}px`
        break
    }
  } else {
    switch (props.align) {
      case 'start':
        styles.top = `${props.alignOffset}px`
        break
      case 'center':
        styles.top = '50%'
        styles.transform = 'translateY(-50%)'
        break
      case 'end':
        styles.bottom = `${props.alignOffset}px`
        break
    }
  }
  
  return styles
})

// Handle click outside to dismiss
const handleClickOutside = (event: MouseEvent) => {
  if (props.dismissOnInteractOutside && contentRef.value && !contentRef.value.contains(event.target as Node)) {
    setOpen(false)
  }
}

// Handle escape key
const handleEscape = (event: KeyboardEvent) => {
  if (event.key === 'Escape') {
    setOpen(false)
  }
}

watch(isOpen, (newValue) => {
  if (newValue) {
    document.addEventListener('click', handleClickOutside, true)
    document.addEventListener('keydown', handleEscape)
  } else {
    document.removeEventListener('click', handleClickOutside, true)
    document.removeEventListener('keydown', handleEscape)
  }
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside, true)
  document.removeEventListener('keydown', handleEscape)
})
</script>

<style scoped>
.assistant-modal-enter-active,
.assistant-modal-leave-active {
  transition: opacity 0.2s ease;
}

.assistant-modal-enter-from,
.assistant-modal-leave-to {
  opacity: 0;
}
</style>