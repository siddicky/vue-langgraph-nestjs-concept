import { computed, ComputedRef } from 'vue';
import { useMessageContext } from '../../../composables/message/useMessageContext';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';

export enum HideAndFloatStatus {
  Hidden = "hidden",
  Floating = "floating",
  Normal = "normal",
}

interface UseActionBarFloatStatusProps {
  hideWhenRunning?: boolean;
  autohide?: "always" | "not-last" | "never";
  autohideFloat?: "always" | "single-branch" | "never";
}

/**
 * Hook that manages action bar visibility and floating behavior.
 * 
 * Combines thread state, message state, and hover state to determine
 * whether the action bar should be hidden, floating, or normal.
 * 
 * @param props Configuration for hide and float behavior
 * @returns Computed ref with current hide/float status
 */
export function useActionBarFloatStatus(
  props: UseActionBarFloatStatusProps
): ComputedRef<HideAndFloatStatus> {
  const threadRuntimeRef = useThreadRuntime();
  const messageContext = useMessageContext();

  return computed(() => {
    const threadRuntime = threadRuntimeRef?.value;
    if (!threadRuntime || !messageContext) {
      return HideAndFloatStatus.Hidden;
    }

    const thread = threadRuntime.getState();
    const message = messageContext.message.value;
    const messageUtils = messageContext.messageUtils.value;

    const { isRunning } = thread;
    const { isLast, branchCount } = message;
    const { isHovering } = messageUtils;

    // Check if should hide
    if (props.hideWhenRunning && isRunning) {
      return HideAndFloatStatus.Hidden;
    }

    const autohide = props.autohide ?? "never";
    if (autohide === "always") {
      return HideAndFloatStatus.Hidden;
    }
    if (autohide === "not-last" && !isLast) {
      return HideAndFloatStatus.Hidden;
    }

    // Check if should float
    const autohideFloat = props.autohideFloat ?? "never";
    
    if (autohideFloat === "always") {
      return isHovering ? HideAndFloatStatus.Floating : HideAndFloatStatus.Hidden;
    }
    
    if (autohideFloat === "single-branch" && branchCount <= 1) {
      return isHovering ? HideAndFloatStatus.Floating : HideAndFloatStatus.Hidden;
    }

    return HideAndFloatStatus.Normal;
  });
}