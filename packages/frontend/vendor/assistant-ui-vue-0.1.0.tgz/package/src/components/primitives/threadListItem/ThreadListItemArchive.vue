<template>
  <button
    type="button"
    class="thread-list-item-archive"
    @click="handleArchive"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useThreadListItemContext } from '../../../composables'

const threadListItemRuntime = useThreadListItemContext()

const handleArchive = () => {
  if (threadListItemRuntime.value) {
    threadListItemRuntime.value.archive()
  }
}
</script>