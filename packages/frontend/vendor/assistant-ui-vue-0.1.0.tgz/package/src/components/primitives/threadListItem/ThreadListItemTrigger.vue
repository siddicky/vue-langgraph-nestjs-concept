<template>
  <button
    type="button"
    class="thread-list-item-trigger"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useThreadListItemContext } from '../../../composables'

const threadListItemRuntime = useThreadListItemContext()

const handleClick = () => {
  if (threadListItemRuntime.value) {
    threadListItemRuntime.value.switchTo()
  }
}
</script>