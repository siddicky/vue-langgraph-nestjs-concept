<template>
  <button
    v-if="!disabled"
    @click="handleSuggestion"
    :disabled="disabled"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadContext } from '../../../composables'

export interface ThreadSuggestionProps {
  prompt: string
  method?: 'replace'
  autoSend?: boolean
}

const props = withDefaults(defineProps<ThreadSuggestionProps>(), {
  autoSend: false
})

const context = useThreadContext()
const disabled = computed(() => context?.thread.value?.isDisabled ?? false)

const handleSuggestion = () => {
  if (!context?.threadRuntime) return
  if (props.autoSend && !context.threadRuntime.getState().isRunning) {
    context.threadRuntime.append(props.prompt)
  } else {
    context.threadRuntime.composer.setText(props.prompt)
  }
}
</script>