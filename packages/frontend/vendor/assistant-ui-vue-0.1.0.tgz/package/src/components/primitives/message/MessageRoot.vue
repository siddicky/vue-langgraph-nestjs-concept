<template>
  <div ref="rootRef" v-bind="$attrs">
    <slot />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, inject } from 'vue';
import { MESSAGE_CONTEXT_KEY } from '../../../composables/message/useMessageContext';

const messageContext = inject(MESSAGE_CONTEXT_KEY);

const rootRef = ref<HTMLDivElement>();
const isHovering = ref(false);

const handleMouseEnter = () => {
  isHovering.value = true;
  if (messageContext?.utils) {
    messageContext.utils.setIsHovering(true);
  }
};

const handleMouseLeave = () => {
  isHovering.value = false;
  if (messageContext?.utils) {
    messageContext.utils.setIsHovering(false);
  }
};

onMounted(() => {
  if (rootRef.value) {
    rootRef.value.addEventListener('mouseenter', handleMouseEnter);
    rootRef.value.addEventListener('mouseleave', handleMouseLeave);
  }
});

onUnmounted(() => {
  if (rootRef.value) {
    rootRef.value.removeEventListener('mouseenter', handleMouseEnter);
    rootRef.value.removeEventListener('mouseleave', handleMouseLeave);
  }
  if (messageContext?.utils) {
    messageContext.utils.setIsHovering(false);
  }
});
</script>