<template>
  <template v-if="messagesLength > 0">
    <ThreadMessageByIndex
      v-for="index in messagesLength"
      :key="index - 1"
      :index="index - 1"
      :components="components"
    />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useThread } from '../../../composables/thread/useThreadContext';
import ThreadMessageByIndex from './ThreadMessageByIndex.vue';
import type { ThreadMessageComponentTypes } from '../../../types/ThreadMessageComponentTypes';

export interface ThreadMessagesProps {
  components: ThreadMessageComponentTypes;
}

defineProps<ThreadMessagesProps>();

const thread = useThread();

const messagesLength = computed(() => {
  return thread.value?.messages?.length ?? 0;
});
</script>