<template>
  <component :is="Component" />
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useMessage } from '../../../composables/message/useMessageContext';
import { useEditComposer } from '../../../composables/message/useEditComposer';
import type { ThreadMessageComponentTypes } from '../../../types/ThreadMessageComponentTypes';
import type { ThreadMessageRole } from '../../../types/AssistantTypes';

interface Props {
  components: ThreadMessageComponentTypes;
}

const props = defineProps<Props>();

const message = useMessage();
const editComposer = useEditComposer();

const role = computed(() => message?.role as ThreadMessageRole);
const isEditing = computed(() => editComposer?.value?.getState().isEditing ?? false);

const DEFAULT_SYSTEM_MESSAGE = () => null;

const getComponent = (
  components: ThreadMessageComponentTypes,
  role: ThreadMessageRole,
  isEditing: boolean
) => {
  switch (role) {
    case 'user':
      if (isEditing) {
        return (
          components.UserEditComposer ??
          components.EditComposer ??
          components.UserMessage ??
          components.Message
        );
      } else {
        return components.UserMessage ?? components.Message;
      }
    case 'assistant':
      if (isEditing) {
        return (
          components.AssistantEditComposer ??
          components.EditComposer ??
          components.AssistantMessage ??
          components.Message
        );
      } else {
        return components.AssistantMessage ?? components.Message;
      }
    case 'system':
      if (isEditing) {
        return (
          components.SystemEditComposer ??
          components.EditComposer ??
          components.SystemMessage ??
          components.Message
        );
      } else {
        return components.SystemMessage ?? DEFAULT_SYSTEM_MESSAGE;
      }
    default:
      throw new Error(`Unknown message role: ${role}`);
  }
};

const Component = computed(() => {
  if (!role.value) return null;
  return getComponent(props.components, role.value, isEditing.value);
});
</script>