<template>
  <span class="thread-list-item-title">
    <template v-if="title">{{ title }}</template>
    <slot v-else />
  </span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadListItemContext } from '../../../composables'

const threadListItemRuntime = useThreadListItemContext()

const title = computed(() => {
  const state = threadListItemRuntime.value?.getState()
  return state?.title || ''
})
</script>