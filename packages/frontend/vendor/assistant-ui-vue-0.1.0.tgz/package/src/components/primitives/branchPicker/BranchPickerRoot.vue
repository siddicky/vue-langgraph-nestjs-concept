<template>
  <div 
    v-if="shouldRender"
    class="branch-picker-root"
    v-bind="$attrs"
  >
    <slot />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessage } from '../../../composables'

interface Props {
  hideWhenSingleBranch?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  hideWhenSingleBranch: false
})

const message = useMessage()

const shouldRender = computed(() => {
  if (!props.hideWhenSingleBranch) return true
  return message && message.branchCount > 1
})
</script>