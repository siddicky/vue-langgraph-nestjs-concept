<template>
  <ThreadListItemRuntimeProvider v-if="runtime" :runtime="runtime">
    <component :is="components.ThreadListItem" />
  </ThreadListItemRuntimeProvider>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Component } from 'vue'
import { useAssistantRuntime } from '../../../composables'
import ThreadListItemRuntimeProvider from '../../../context/providers/ThreadListItemRuntimeProvider.vue'

interface Props {
  index: number
  archived?: boolean
  components: {
    ThreadListItem: Component
  }
}

const props = withDefaults(defineProps<Props>(), {
  archived: false
})

const assistantRuntime = useAssistantRuntime()

const runtime = computed(() => {
  if (!assistantRuntime.value) return null
  return props.archived
    ? assistantRuntime.value.threads.getArchivedItemByIndex(props.index)
    : assistantRuntime.value.threads.getItemByIndex(props.index)
})
</script>