<template>
  <button
    :disabled="!callback"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useComposerSend } from './useComposerSend';

/**
 * A button component that sends the current message in the composer.
 * 
 * Automatically disabled when:
 * - The thread is running
 * - The composer is not in editing mode  
 * - The composer is empty
 * 
 * @example
 * ```vue
 * <ComposerSend>Send Message</ComposerSend>
 * ```
 */

const callback = useComposerSend();

const handleClick = () => {
  if (callback.value) {
    callback.value();
  }
};
</script>