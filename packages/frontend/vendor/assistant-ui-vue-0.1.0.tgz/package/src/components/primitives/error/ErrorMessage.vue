<template>
  <span v-if="error" class="error-message" v-bind="$attrs">
    <slot>{{ errorMessage }}</slot>
  </span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessageContext } from '../../../composables'

const context = useMessageContext()

const error = computed(() => {
  const messageState = context?.message.value
  if (!messageState) return undefined
  
  if (messageState.status?.type === 'incomplete' && 
      messageState.status.reason === 'error') {
    return messageState.status.error
  }
  
  return undefined
})

const errorMessage = computed(() => {
  if (!error.value) return ''
  return String(error.value)
})
</script>