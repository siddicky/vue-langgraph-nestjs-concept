<template>
  <div
    v-if="!isHidden"
    :data-floating="isFloating"
    v-bind="$attrs"
  >
    <slot />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useActionBarFloatStatus, HideAndFloatStatus } from './useActionBarFloatStatus';

/**
 * Root container for action bar components.
 * 
 * Manages visibility and floating behavior based on message state,
 * thread execution, and user interaction.
 * 
 * @example
 * ```vue
 * <ActionBarRoot :autohide="'not-last'" :autohideFloat="'single-branch'">
 *   <ActionBarCopy />
 *   <ActionBarEdit />
 *   <ActionBarReload />
 * </ActionBarRoot>
 * ```
 */

export interface ActionBarRootProps {
  /**
   * Controls when the action bar is hidden.
   * - "always": Always hide the action bar
   * - "not-last": Hide for all messages except the last one
   * - "never": Never hide the action bar
   * @default "never"
   */
  autohide?: "always" | "not-last" | "never";
  
  /**
   * Controls when the action bar floats (shows on hover).
   * - "always": Always float
   * - "single-branch": Float when there's only one branch
   * - "never": Never float
   * @default "never"
   */
  autohideFloat?: "always" | "single-branch" | "never";
  
  /**
   * Whether to hide the action bar when the thread is running.
   * @default true
   */
  hideWhenRunning?: boolean;
}

const props = withDefaults(defineProps<ActionBarRootProps>(), {
  autohide: "never",
  autohideFloat: "never",
  hideWhenRunning: true
});

const hideAndFloatStatus = useActionBarFloatStatus({
  hideWhenRunning: props.hideWhenRunning,
  autohide: props.autohide,
  autohideFloat: props.autohideFloat
});

const isHidden = computed(() => hideAndFloatStatus.value === HideAndFloatStatus.Hidden);
const isFloating = computed(() => hideAndFloatStatus.value === HideAndFloatStatus.Floating);
</script>