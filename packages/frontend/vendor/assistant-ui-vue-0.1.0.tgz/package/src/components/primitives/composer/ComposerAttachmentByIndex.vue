<template>
  <AttachmentRuntimeProvider v-if="runtime" :runtime="runtime">
    <AttachmentComponent :components="components" />
  </AttachmentRuntimeProvider>
</template>

<script setup lang="ts">
import { computed, h, defineComponent } from 'vue'
import type { Component } from 'vue'
import { useComposerContext, useThreadComposerAttachment } from '../../../composables'
import AttachmentRuntimeProvider from '../../../context/providers/AttachmentRuntimeProvider.vue'
import type { Attachment } from '../../../types'

interface Components {
  Image?: Component
  Document?: Component
  File?: Component
  Attachment?: Component
}

interface Props {
  index: number
  components?: Components
}

const props = defineProps<Props>()

const context = useComposerContext()
const runtime = computed(() => context?.composerRuntime?.getAttachmentByIndex(props.index))

function getComponent(components: Components | undefined, attachment: Attachment) {
  const type = attachment.type
  switch (type) {
    case 'image':
      return components?.Image ?? components?.Attachment
    case 'document':
      return components?.Document ?? components?.Attachment
    case 'file':
      return components?.File ?? components?.Attachment
    default:
      const _exhaustiveCheck: never = type
      throw new Error(`Unknown attachment type: ${_exhaustiveCheck}`)
  }
}

// AttachmentComponent as a child component
const AttachmentComponent = defineComponent({
  props: {
    components: {
      type: Object as () => Components | undefined,
      default: undefined
    }
  },
  setup(props) {
    const Component = useThreadComposerAttachment((a) => a ? getComponent(props.components, a) : undefined)
    
    return () => {
      if (!Component.value) return null
      return h(Component.value)
    }
  }
})
</script>