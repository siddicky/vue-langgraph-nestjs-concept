import { computed } from 'vue'
import { useMessagePartContext } from '../../../composables'
import type { MessagePartState } from '../../../api/MessagePartRuntime'
import type { FileMessagePart } from '../../../types'

export const useMessagePartFile = () => {
  const context = useMessagePartContext()
  
  const file = computed(() => {
    const part = context?.messagePart.value
    if (!part || part.type !== 'file') {
      throw new Error('MessagePartFile can only be used inside file message parts.')
    }
    return part as MessagePartState & FileMessagePart
  })
  
  return file
}