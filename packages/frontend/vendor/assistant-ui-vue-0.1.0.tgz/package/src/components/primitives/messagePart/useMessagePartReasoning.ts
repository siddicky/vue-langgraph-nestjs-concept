import { computed } from 'vue'
import { useMessagePartContext } from '../../../composables'
import type { MessagePartState } from '../../../api/MessagePartRuntime'
import type { ReasoningMessagePart } from '../../../types'

export const useMessagePartReasoning = () => {
  const context = useMessagePartContext()
  
  const text = computed(() => {
    const part = context?.messagePart.value
    if (!part || part.type !== 'reasoning') {
      throw new Error('MessagePartReasoning can only be used inside reasoning message parts.')
    }
    return part as MessagePartState & ReasoningMessagePart
  })
  
  return text
}