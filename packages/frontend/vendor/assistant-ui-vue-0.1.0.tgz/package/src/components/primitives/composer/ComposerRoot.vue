<template>
  <form @submit.prevent="handleSubmit">
    <slot />
  </form>
</template>

<script setup lang="ts">
import { useComposerSend } from './useComposerSend';

/**
 * The root form container for message composition.
 *
 * This component provides a form wrapper that handles message submission when the form
 * is submitted (e.g., via Enter key or submit button). It automatically prevents the
 * default form submission and triggers the composer's send functionality.
 *
 * @example
 * ```vue
 * <ComposerRoot>
 *   <ComposerInput placeholder="Type your message..." />
 *   <ComposerSend>Send</ComposerSend>
 * </ComposerRoot>
 * ```
 */

// Emit for custom submit handling
const emit = defineEmits<{
  submit: [event: Event];
}>();

const send = useComposerSend();

const handleSubmit = (e: Event) => {
  emit('submit', e);
  
  if (!send.value) return;
  send.value();
};
</script>