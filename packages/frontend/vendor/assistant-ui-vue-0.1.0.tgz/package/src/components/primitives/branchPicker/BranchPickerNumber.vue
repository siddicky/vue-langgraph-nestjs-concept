<template>
  <span class="branch-picker-number">{{ branchNumber }}</span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessage } from '../../../composables'

const message = useMessage()

const branchNumber = computed(() => {
  return message?.branchNumber || 0
})
</script>