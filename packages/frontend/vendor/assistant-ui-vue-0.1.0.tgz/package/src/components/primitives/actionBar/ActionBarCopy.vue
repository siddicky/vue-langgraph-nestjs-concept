<template>
  <button
    :disabled="!callback"
    :data-copied="isCopied"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { ref, onUnmounted } from 'vue';
import { useActionBarCopy } from './useActionBarCopy';

/**
 * Button component that copies message content to clipboard.
 * 
 * Shows visual feedback via data-copied attribute after copying.
 * Automatically disabled when no copyable content is available.
 * 
 * @example
 * ```vue
 * <ActionBarCopy :copiedDuration="3000">
 *   Copy Message
 * </ActionBarCopy>
 * ```
 */

export interface ActionBarCopyProps {
  /**
   * Duration in milliseconds to show the "copied" state.
   * @default 3000
   */
  copiedDuration?: number;
}

const props = withDefaults(defineProps<ActionBarCopyProps>(), {
  copiedDuration: 3000
});

const isCopied = ref(false);
let copiedTimeoutId: NodeJS.Timeout | undefined;

const callback = useActionBarCopy();

const handleClick = async () => {
  if (!callback.value) return;
  
  await callback.value();
  
  // Show copied state
  isCopied.value = true;
  
  // Clear any existing timeout
  if (copiedTimeoutId) {
    clearTimeout(copiedTimeoutId);
  }
  
  // Reset copied state after duration
  copiedTimeoutId = setTimeout(() => {
    isCopied.value = false;
  }, props.copiedDuration);
};

// Clean up timeout on unmount
onUnmounted(() => {
  if (copiedTimeoutId) {
    clearTimeout(copiedTimeoutId);
  }
});
</script>