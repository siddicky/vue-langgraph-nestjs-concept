<template>
  <div class="thread-list-root" v-bind="$attrs">
    <slot />
  </div>
</template>

<script setup lang="ts">
// This component serves as the root container for thread list components
</script>