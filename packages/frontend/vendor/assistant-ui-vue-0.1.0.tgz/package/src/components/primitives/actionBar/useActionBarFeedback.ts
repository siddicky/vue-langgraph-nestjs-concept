import { computed, ComputedRef } from 'vue';
import { useMessageRuntime } from '../../../composables/message/useMessageContext';

type FeedbackType = 'positive' | 'negative';

/**
 * Hook that provides feedback submission functionality for messages.
 * 
 * @param type Type of feedback ('positive' or 'negative')
 * @returns Object with callback function and submitted state
 */
export function useActionBarFeedback(type: FeedbackType) {
  const messageRuntime = useMessageRuntime();
  
  const isSubmitted = computed(() => {
    if (!messageRuntime) return false;
    const state = messageRuntime.getState();
    const feedback = state.submittedFeedback;
    return feedback?.type === type;
  });
  
  const callback: ComputedRef<(() => void) | null> = computed(() => {
    if (!messageRuntime) return null;
    
    return () => {
      messageRuntime.submitFeedback({ type });
    };
  });

  return {
    callback,
    isSubmitted
  };
}