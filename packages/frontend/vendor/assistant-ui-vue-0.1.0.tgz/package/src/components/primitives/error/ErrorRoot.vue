<template>
  <div
    role="alert"
    class="error-root"
    v-bind="$attrs"
  >
    <slot />
  </div>
</template>

<script setup lang="ts">
// This component serves as the root container for error-related components
// It sets the appropriate ARIA role for accessibility
</script>