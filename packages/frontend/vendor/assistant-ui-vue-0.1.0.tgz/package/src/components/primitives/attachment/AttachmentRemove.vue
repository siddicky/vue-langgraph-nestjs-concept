<template>
  <button
    type="button"
    class="attachment-remove"
    @click="handleRemove"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useAttachmentContext } from '../../../composables'

const attachment = useAttachmentContext()

const handleRemove = () => {
  if (attachment?.remove) {
    attachment.remove()
  }
}
</script>