<template>
  <component
    :is="asChild ? 'slot' : 'div'"
    :data-dragging="isDragging ? 'true' : undefined"
    @dragenter="handleDrag"
    @dragover="handleDrag"
    @dragleave="handleDrag"
    @drop="handleDrop"
    v-bind="$attrs"
  >
    <slot />
  </component>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useComposerContext } from '../../../composables'

interface Props {
  asChild?: boolean
  disabled?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  asChild: false,
  disabled: false
})

const context = useComposerContext()
const isDragging = ref(false)

const handleDrag = (e: DragEvent) => {
  if (props.disabled) return
  e.preventDefault()
  e.stopPropagation()
  isDragging.value = e.type === 'dragenter' || e.type === 'dragover'
}

const handleDrop = async (e: DragEvent) => {
  if (props.disabled || !context?.composerRuntime) return
  e.preventDefault()
  e.stopPropagation()
  isDragging.value = false
  
  if (!e.dataTransfer?.files) return
  
  for (const file of e.dataTransfer.files) {
    try {
      await context.composerRuntime.addAttachment(file)
    } catch (error) {
      console.error('Failed to add attachment:', error)
    }
  }
}
</script>