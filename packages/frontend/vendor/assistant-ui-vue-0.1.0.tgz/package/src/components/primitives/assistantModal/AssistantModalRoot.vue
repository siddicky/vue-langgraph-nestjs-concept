<template>
  <Teleport to="body" :disabled="!modal">
    <div v-if="isOpen" ref="modalRef" class="assistant-modal-root">
      <slot />
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, provide, computed, onMounted, onUnmounted } from 'vue'
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime'

interface Props {
  open?: boolean
  defaultOpen?: boolean
  modal?: boolean
  unstableOpenOnRunStart?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  defaultOpen: false,
  modal: true,
  unstableOpenOnRunStart: true
})

const emit = defineEmits<{
  'update:open': [value: boolean]
  'openChange': [value: boolean]
}>()

const modalRef = ref<HTMLElement>()
const internalOpen = ref(props.defaultOpen)

const isOpen = computed({
  get: () => props.open !== undefined ? props.open : internalOpen.value,
  set: (value: boolean) => {
    internalOpen.value = value
    emit('update:open', value)
    emit('openChange', value)
  }
})

// Handle open on run start
if (props.unstableOpenOnRunStart) {
  const threadRuntimeRef = useThreadRuntime()
  
  onMounted(() => {
    const threadRuntime = threadRuntimeRef?.value
    if (!props.unstableOpenOnRunStart || !threadRuntime) return
    
    const unsubscribe = threadRuntime.unstable_on('run-start', () => {
      isOpen.value = true
    })
    
    onUnmounted(() => {
      unsubscribe?.()
    })
  })
}

// Provide modal state to children
provide('assistantModalOpen', isOpen)
provide('assistantModalSetOpen', (value: boolean) => {
  isOpen.value = value
})

// Handle click outside
const handleClickOutside = (event: MouseEvent) => {
  if (modalRef.value && !modalRef.value.contains(event.target as Node)) {
    // Can be configured to close or not
  }
}

onMounted(() => {
  if (props.modal) {
    document.addEventListener('click', handleClickOutside)
  }
})

onUnmounted(() => {
  document.removeEventListener('click', handleClickOutside)
})
</script>