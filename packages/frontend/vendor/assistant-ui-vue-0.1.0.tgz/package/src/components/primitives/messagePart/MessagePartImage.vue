<template>
  <img v-if="image" :src="image" v-bind="$attrs" />
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useMessagePart } from '../../../composables/messagePart/useMessagePartContext';

const part = useMessagePart();

const image = computed(() => {
  if (!part.value) return null;
  if (part.value.type !== 'image') return null;
  return part.value.image ?? null;
});
</script>