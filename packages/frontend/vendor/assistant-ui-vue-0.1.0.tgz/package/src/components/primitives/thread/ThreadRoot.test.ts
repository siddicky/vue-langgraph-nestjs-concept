import { describe, it, expect } from 'vitest';
import { mount } from '@vue/test-utils';
import ThreadRoot from './ThreadRoot.vue';

describe('ThreadRoot', () => {
  it('renders correctly', () => {
    const wrapper = mount(ThreadRoot);
    expect(wrapper.exists()).toBe(true);
    expect(wrapper.element.tagName).toBe('DIV');
  });

  it('renders slot content', () => {
    const wrapper = mount(ThreadRoot, {
      slots: {
        default: '<div class="test-content">Test Content</div>'
      }
    });
    expect(wrapper.find('.test-content').exists()).toBe(true);
    expect(wrapper.text()).toContain('Test Content');
  });

  it('exposes rootRef', () => {
    const wrapper = mount(ThreadRoot);
    const { rootRef } = wrapper.vm as any;
    expect(rootRef).toBeDefined();
    expect(rootRef).toBe(wrapper.element);
  });

  it('inherits attributes', () => {
    const wrapper = mount(ThreadRoot, {
      attrs: {
        class: 'custom-class',
        id: 'thread-root-id',
        'data-testid': 'thread-root'
      }
    });
    expect(wrapper.classes()).toContain('custom-class');
    expect(wrapper.attributes('id')).toBe('thread-root-id');
    expect(wrapper.attributes('data-testid')).toBe('thread-root');
  });
});