<template>
  <component
    v-if="EmptyComponent"
    :is="EmptyComponent"
    :status="status"
  />
  <EmptyPartFallback
    v-else
    :status="status"
    :component="TextComponent"
  />
</template>

<script setup lang="ts">
import { computed, defineComponent, h } from 'vue';
import { useMessage } from '../../../composables/message/useMessageContext';
import EmptyPartFallback from './EmptyPartFallback.vue';
import MessagePartText from '../messagePart/MessagePartText.vue';
import MessagePartInProgress from '../messagePart/MessagePartInProgress.vue';
import type { MessagePartComponentTypes } from '../../../types/MessagePartComponentTypes';
import type { MessagePartStatus } from '../../../types/AssistantTypes';

interface Props {
  components?: MessagePartComponentTypes;
}

const props = withDefaults(defineProps<Props>(), {
  components: () => ({})
});

const COMPLETE_STATUS: MessagePartStatus = Object.freeze({
  type: 'complete',
});

const message = useMessage();

const status = computed(() => {
  return (message?.status as MessagePartStatus) ?? COMPLETE_STATUS;
});

const EmptyComponent = computed(() => props.components?.Empty);

const defaultText = defineComponent({
  name: 'DefaultText',
  setup() {
    return () => h('p', { style: { whiteSpace: 'pre-line' } }, [
      h(MessagePartText),
      h(MessagePartInProgress, () => h('span', { style: { fontFamily: 'revert' } }, ' ●'))
    ]);
  }
});

const TextComponent = computed(() => props.components?.Text ?? defaultText);
</script>