export { default as ThreadListItemRoot } from './ThreadListItemRoot.vue'
export { default as ThreadListItemTitle } from './ThreadListItemTitle.vue'
export { default as ThreadListItemTrigger } from './ThreadListItemTrigger.vue'
export { default as ThreadListItemArchive } from './ThreadListItemArchive.vue'
export { default as ThreadListItemUnarchive } from './ThreadListItemUnarchive.vue'
export { default as ThreadListItemDelete } from './ThreadListItemDelete.vue'

// Composable for thread list item functionality
import { computed } from 'vue'
import { useThreadListItemContext } from '../../../composables'

export function useThreadListItem() {
  const threadListItemRuntime = useThreadListItemContext()
  
  const title = computed(() => threadListItemRuntime.value?.getState()?.title || '')
  const isMain = computed(() => threadListItemRuntime.value?.getState()?.isMain || false)
  const isArchived = computed(() => threadListItemRuntime.value?.getState()?.status === 'archived')
  const threadId = computed(() => threadListItemRuntime.value?.getState()?.threadId || null)
  
  const switchTo = () => {
    if (threadListItemRuntime.value) {
      threadListItemRuntime.value.switchTo()
    }
  }
  
  const archive = () => {
    if (threadListItemRuntime.value) {
      threadListItemRuntime.value.archive()
    }
  }
  
  const unarchive = () => {
    if (threadListItemRuntime.value) {
      threadListItemRuntime.value.unarchive()
    }
  }
  
  const deleteThread = () => {
    if (threadListItemRuntime.value) {
      threadListItemRuntime.value.delete()
    }
  }
  
  return {
    title,
    isMain,
    isArchived,
    threadId,
    switchTo,
    archive,
    unarchive,
    deleteThread
  }
}