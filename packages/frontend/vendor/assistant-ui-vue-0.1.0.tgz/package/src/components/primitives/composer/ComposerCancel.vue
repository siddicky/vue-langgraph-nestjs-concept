<template>
  <button
    :disabled="!callback"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useComposerCancel } from './useComposerCancel';

/**
 * A button component that cancels the current message composition.
 * 
 * Automatically disabled when canceling is not available (!composer.canCancel).
 * 
 * @example
 * ```vue
 * <ComposerCancel>Cancel</ComposerCancel>
 * ```
 */

const callback = useComposerCancel();

const handleClick = () => {
  if (callback.value) {
    callback.value();
  }
};
</script>