<template>
  <div class="attachment-thumb" v-bind="$attrs">
    .{{ extension }}
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useAttachmentContext } from '../../../composables'

const attachment = useAttachmentContext()

const extension = computed(() => {
  if (!attachment?.attachment.value?.name) return ''
  const parts = attachment.attachment.value.name.split('.')
  return parts.length > 1 ? parts.pop() : ''
})
</script>