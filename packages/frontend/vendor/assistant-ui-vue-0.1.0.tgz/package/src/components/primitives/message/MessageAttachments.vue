<template>
  <template v-for="index in attachmentsCount" :key="index - 1">
    <MessageAttachmentByIndex
      :index="index - 1"
      :components="components"
    />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Component } from 'vue'
import { useMessageContext } from '../../../composables'
import MessageAttachmentByIndex from './MessageAttachmentByIndex.vue'

interface Components {
  Image?: Component
  Document?: Component
  File?: Component
  Attachment?: Component
}

interface Props {
  components?: Components
}

defineProps<Props>()

const context = useMessageContext()
const attachmentsCount = computed(() => {
  const msg = context?.message.value
  if (!msg || msg.role !== 'user') return 0
  return msg.attachments?.length ?? 0
})
</script>