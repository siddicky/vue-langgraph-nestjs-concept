<template>
  <template v-if="empty">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadContext } from '../../../composables'

const context = useThreadContext()
const empty = computed(() => context?.thread.value.messages.length === 0)
</script>