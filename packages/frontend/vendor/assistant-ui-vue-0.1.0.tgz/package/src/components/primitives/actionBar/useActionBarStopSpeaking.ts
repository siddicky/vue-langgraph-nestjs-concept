import { computed } from 'vue'
import { useMessageRuntime, useMessage } from '../../../composables'

export const useActionBarStopSpeaking = () => {
  const messageRuntime = useMessageRuntime()
  const message = useMessage()
  
  const callback = () => {
    messageRuntime?.stopSpeaking()
  }
  
  const isSpeaking = computed(() => {
    const m = message
    return m && m.speech != null
  })
  
  const disabled = computed(() => !isSpeaking.value)
  
  return {
    callback,
    disabled
  }
}