<template>
  <button
    type="button"
    :disabled="disabled"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useActionBarSpeak } from './useActionBarSpeak'

const { callback, disabled } = useActionBarSpeak()

const handleClick = () => {
  if (!disabled.value) {
    callback()
  }
}
</script>