export interface MessagePartGroup {
  groupKey: string | undefined
  indices: number[]
}

export type GroupingFunction = (parts: readonly any[]) => MessagePartGroup[]

// Default grouping function by parent ID
export const groupMessagePartsByParentId: GroupingFunction = (parts: readonly any[]): MessagePartGroup[] => {
  const groupMap = new Map<string, number[]>()
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i]
    const parentId = part?.parentId as string | undefined
    const groupId = parentId ?? `__ungrouped_${i}`
    
    const indices = groupMap.get(groupId) ?? []
    indices.push(i)
    groupMap.set(groupId, indices)
  }
  
  const groups: MessagePartGroup[] = []
  for (const [groupId, indices] of groupMap) {
    const groupKey = groupId.startsWith('__ungrouped_') ? undefined : groupId
    groups.push({ groupKey, indices })
  }
  
  return groups
}