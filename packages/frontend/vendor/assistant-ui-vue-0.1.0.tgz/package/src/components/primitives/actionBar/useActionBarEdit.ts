import { computed, ComputedRef } from 'vue';
import { useEditComposer } from '../../../composables/message/useEditComposer';
import { useMessageRuntime } from '../../../composables/message/useMessageContext';

/**
 * Hook that provides an edit function for the current message.
 * Returns null when editing is not available or already active.
 * 
 * @returns A computed ref containing the edit function or null
 */
export function useActionBarEdit(): ComputedRef<(() => void) | null> {
  const editComposer = useEditComposer();
  const messageRuntime = useMessageRuntime();
  
  const isEditing = computed(() => editComposer.value?.getState().isEditing ?? false);

  return computed(() => {
    if (isEditing.value || !messageRuntime) return null;
    
    return () => {
      messageRuntime.composer.beginEdit();
    };
  });
}