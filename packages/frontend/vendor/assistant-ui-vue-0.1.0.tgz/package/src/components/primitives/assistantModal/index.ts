export { default as AssistantModalRoot } from './AssistantModalRoot.vue'
export { default as AssistantModalContent } from './AssistantModalContent.vue'
export { default as AssistantModalTrigger } from './AssistantModalTrigger.vue'
export { default as AssistantModalAnchor } from './AssistantModalAnchor.vue'

// Composables for programmatic control
import { ref, inject } from 'vue'
import type { Ref } from 'vue'

export function useAssistantModal() {
  const isOpen = inject<Ref<boolean>>('assistantModalOpen', ref(false))
  const setOpen = inject<(value: boolean) => void>('assistantModalSetOpen', () => {})
  
  return {
    isOpen,
    setOpen,
    open: () => setOpen(true),
    close: () => setOpen(false),
    toggle: () => setOpen(!isOpen.value)
  }
}