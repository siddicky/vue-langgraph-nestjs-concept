export { default as BranchPickerRoot } from './BranchPickerRoot.vue'
export { default as BranchPickerPrevious } from './BranchPickerPrevious.vue'
export { default as BranchPickerNext } from './BranchPickerNext.vue'
export { default as BranchPickerNumber } from './BranchPickerNumber.vue'
export { default as BranchPickerCount } from './BranchPickerCount.vue'

// Composables for programmatic use
import { computed } from 'vue'
import { useMessageContext } from '../../../composables'

export function useBranchPicker() {
  const context = useMessageContext()
  
  const branchNumber = computed(() => context?.message.value?.branchNumber || 0)
  const branchCount = computed(() => context?.message.value?.branchCount || 0)
  
  const canGoPrevious = computed(() => branchNumber.value > 1)
  const canGoNext = computed(() => branchNumber.value < branchCount.value)
  
  const goToPrevious = () => {
    if (canGoPrevious.value && context?.messageRuntime) {
      context.messageRuntime.switchToBranch({ position: 'previous' })
    }
  }
  
  const goToNext = () => {
    if (canGoNext.value && context?.messageRuntime) {
      context.messageRuntime.switchToBranch({ position: 'next' })
    }
  }
  
  const goToBranch = (index: number) => {
    if (context?.messageRuntime && index >= 1 && index <= branchCount.value) {
      context.messageRuntime.switchToBranch({ branchId: `${index - 1}` })
    }
  }
  
  return {
    branchNumber,
    branchCount,
    canGoPrevious,
    canGoNext,
    goToPrevious,
    goToNext,
    goToBranch
  }
}