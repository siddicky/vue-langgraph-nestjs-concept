<template>
  <button
    type="button"
    class="thread-list-item-unarchive"
    @click="handleUnarchive"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useThreadListItemContext } from '../../../composables'

const threadListItemRuntime = useThreadListItemContext()

const handleUnarchive = () => {
  if (threadListItemRuntime.value) {
    threadListItemRuntime.value.unarchive()
  }
}
</script>