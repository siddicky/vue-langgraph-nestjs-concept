<template>
  <button
    :disabled="!callback"
    :data-submitted="isSubmitted"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useActionBarFeedback } from './useActionBarFeedback';

/**
 * Button component for submitting negative feedback on a message.
 * 
 * Shows visual feedback via data-submitted attribute when feedback is submitted.
 * 
 * @example
 * ```vue
 * <ActionBarFeedbackNegative>👎</ActionBarFeedbackNegative>
 * ```
 */

const { callback, isSubmitted } = useActionBarFeedback('negative');

const handleClick = () => {
  if (callback.value) {
    callback.value();
  }
};
</script>