<template>
  <button
    type="button"
    :disabled="disabled"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { onMounted, onUnmounted } from 'vue'
import { useActionBarStopSpeaking } from './useActionBarStopSpeaking'

const { callback, disabled } = useActionBarStopSpeaking()

const handleClick = () => {
  if (!disabled.value) {
    callback()
  }
}

// Handle Escape key to stop speaking
const handleEscape = (e: KeyboardEvent) => {
  if (e.key === 'Escape' && !disabled.value) {
    e.preventDefault()
    callback()
  }
}

onMounted(() => {
  document.addEventListener('keydown', handleEscape)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleEscape)
})
</script>