<template>
  <template v-for="(_, index) in contentLength" :key="index">
    <ThreadListItemByIndex
      :index="index"
      :archived="archived"
      :components="components"
    />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useAssistantRuntime } from '../../../composables'
import ThreadListItemByIndex from './ThreadListItemByIndex.vue'
import type { Component } from 'vue'

interface Props {
  archived?: boolean
  components: {
    ThreadListItem: Component
  }
}

const props = withDefaults(defineProps<Props>(), {
  archived: false
})

const assistantRuntime = useAssistantRuntime()

const contentLength = computed(() => {
  if (!assistantRuntime.value) return 0
  const threadList = assistantRuntime.value.threads.getState()
  return props.archived ? threadList.archivedThreads.length : threadList.threads.length
})
</script>