export { default as ThreadListRoot } from './ThreadListRoot.vue'
export { default as ThreadListItems } from './ThreadListItems.vue'
export { default as ThreadListItemByIndex } from './ThreadListItemByIndex.vue'
export { default as ThreadListNew } from './ThreadListNew.vue'

// Composable for thread list functionality
import { computed } from 'vue'
import { useAssistantRuntime } from '../../../composables'

export function useThreadList() {
  const assistantRuntime = useAssistantRuntime()
  
  const threads = computed(() => {
    if (!assistantRuntime.value) return []
    return assistantRuntime.value.threads.getState().threads
  })
  
  const archivedThreads = computed(() => {
    if (!assistantRuntime.value) return []
    return assistantRuntime.value.threads.getState().archivedThreads
  })
  
  const currentThreadId = computed(() => {
    if (!assistantRuntime.value) return null
    return assistantRuntime.value.threads.getState().mainThreadId
  })
  
  const newThreadId = computed(() => {
    if (!assistantRuntime.value) return null
    return assistantRuntime.value.threads.getState().newThread
  })
  
  const isNewThreadActive = computed(() => {
    return currentThreadId.value === newThreadId.value
  })
  
  const switchToThread = (threadId: string) => {
    if (assistantRuntime.value) {
      assistantRuntime.value.switchToThread(threadId)
    }
  }
  
  const switchToNewThread = () => {
    if (assistantRuntime.value) {
      assistantRuntime.value.switchToNewThread()
    }
  }
  
  return {
    threads,
    archivedThreads,
    currentThreadId,
    newThreadId,
    isNewThreadActive,
    switchToThread,
    switchToNewThread
  }
}