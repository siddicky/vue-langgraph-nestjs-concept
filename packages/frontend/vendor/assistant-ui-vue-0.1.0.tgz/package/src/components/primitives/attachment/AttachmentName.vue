<template>
  <span class="attachment-name">{{ name }}</span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useAttachmentContext } from '../../../composables'

const attachment = useAttachmentContext()

const name = computed(() => {
  if (!attachment?.attachment.value) return ''
  return attachment.attachment.value.name || ''
})
</script>