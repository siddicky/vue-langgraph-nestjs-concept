<template>
  <button
    type="button"
    class="branch-picker-next"
    :disabled="disabled"
    @click="handleNext"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessage, useMessageRuntime } from '../../../composables'

const message = useMessage()
const messageRuntime = useMessageRuntime()

const disabled = computed(() => {
  return !message || message.branchNumber >= message.branchCount
})

const handleNext = () => {
  if (!disabled.value && messageRuntime) {
    messageRuntime.switchToBranch({ position: 'next' })
  }
}
</script>