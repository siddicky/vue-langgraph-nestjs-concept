import { computed } from 'vue'
import { useMessageRuntime, useMessage } from '../../../composables'

export const useActionBarSpeak = () => {
  const messageRuntime = useMessageRuntime()
  const message = useMessage()
  
  const callback = () => {
    messageRuntime?.speak()
  }
  
  const hasSpeakableContent = computed(() => {
    const m = message
    if (!m) return false
    
    return (
      (m.role !== 'assistant' || m.status.type !== 'running') &&
      m.content.some((c: any) => c.type === 'text' && c.text.length > 0)
    )
  })
  
  const disabled = computed(() => !hasSpeakableContent.value)
  
  return {
    callback,
    disabled
  }
}