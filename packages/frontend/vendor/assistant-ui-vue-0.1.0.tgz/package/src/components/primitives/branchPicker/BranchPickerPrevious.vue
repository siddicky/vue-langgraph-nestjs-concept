<template>
  <button
    type="button"
    class="branch-picker-previous"
    :disabled="disabled"
    @click="handlePrevious"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessage, useMessageRuntime } from '../../../composables'

const message = useMessage()
const messageRuntime = useMessageRuntime()

const disabled = computed(() => {
  return !message || message.branchNumber <= 1
})

const handlePrevious = () => {
  if (!disabled.value && messageRuntime) {
    messageRuntime.switchToBranch({ position: 'previous' })
  }
}
</script>