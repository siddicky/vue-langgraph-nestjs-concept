<template>
  <component
    :is="component"
    type="text"
    text=""
    :status="status"
  />
</template>

<script setup lang="ts">
import { provide } from 'vue';
import type { Component } from 'vue';
import type { MessagePartStatus } from '../../../types/AssistantTypes';
import { TEXT_MESSAGE_PART_CONTEXT_KEY } from '../../../composables/messagePart/useTextMessagePartContext';

interface Props {
  status: MessagePartStatus;
  component: Component;
}

const props = defineProps<Props>();

// Provide text message part context
provide(TEXT_MESSAGE_PART_CONTEXT_KEY, {
  text: '',
  isRunning: props.status.type === 'running'
});
</script>