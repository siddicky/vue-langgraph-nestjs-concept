<template>
  <span>{{ text }}</span>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useMessagePart } from '../../../composables/messagePart/useMessagePartContext';

const part = useMessagePart();

const text = computed(() => {
  if (!part.value) return '';
  if (part.value.type !== 'text') return '';
  return part.value.text ?? '';
});
</script>