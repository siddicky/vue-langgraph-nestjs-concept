import { computed } from 'vue'
import { useMessagePartContext } from '../../../composables'
import type { MessagePartState } from '../../../api/MessagePartRuntime'
import type { TextMessagePart, ReasoningMessagePart } from '../../../types'

export const useMessagePartText = () => {
  const context = useMessagePartContext()
  
  const text = computed(() => {
    const part = context?.messagePart.value
    if (!part || (part.type !== 'text' && part.type !== 'reasoning')) {
      throw new Error('MessagePartText can only be used inside text or reasoning message parts.')
    }
    return part as MessagePartState & (TextMessagePart | ReasoningMessagePart)
  })
  
  return text
}