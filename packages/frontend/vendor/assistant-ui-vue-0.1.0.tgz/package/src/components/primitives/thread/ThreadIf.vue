<template>
  <template v-if="shouldRender">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadContext } from '../../../composables'

export interface ThreadIfProps {
  empty?: boolean
  running?: boolean
  disabled?: boolean
}

const props = defineProps<ThreadIfProps>()

const context = useThreadContext()

const shouldRender = computed(() => {
  if (!context) return false
  const t = context.thread.value
  
  if (props.empty === true && t.messages.length !== 0) return false
  if (props.empty === false && t.messages.length === 0) return false
  if (props.running === true && !t.isRunning) return false
  if (props.running === false && t.isRunning) return false
  if (props.disabled === true && !t.isDisabled) return false
  if (props.disabled === false && t.isDisabled) return false
  
  return true
})
</script>