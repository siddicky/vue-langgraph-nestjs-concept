export { default as ErrorRoot } from './ErrorRoot.vue'
export { default as ErrorMessage } from './ErrorMessage.vue'

// Composable for error handling
import { computed } from 'vue'
import { useMessageContext } from '../../../composables'

export function useError() {
  const context = useMessageContext()
  
  const error = computed(() => {
    const messageState = context?.message.value
    if (!messageState) return undefined
    
    if (messageState.status?.type === 'incomplete' && 
        messageState.status.reason === 'error') {
      return messageState.status.error
    }
    
    return undefined
  })
  
  const hasError = computed(() => error.value !== undefined)
  
  const errorMessage = computed(() => {
    if (!error.value) return ''
    return String(error.value)
  })
  
  return {
    error,
    hasError,
    errorMessage
  }
}