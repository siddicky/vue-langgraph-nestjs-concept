import { computed, ComputedRef } from 'vue';
import { useMessageRuntime } from '../../../composables/message/useMessageContext';
import { useEditComposer } from '../../../composables/message/useEditComposer';
import { getThreadMessageText } from '../../../utils/getThreadMessageText';

/**
 * Hook that provides a copy function for message content.
 * Returns null when no copyable content is available.
 * 
 * @returns A computed ref containing the copy function or null
 */
export function useActionBarCopy(): ComputedRef<(() => Promise<void>) | null> {
  const messageRuntime = useMessageRuntime();
  const editComposer = useEditComposer();
  
  const hasCopyableContent = computed(() => {
    if (!messageRuntime) return false;
    
    const composer = editComposer.value;
    if (composer) {
      // If editing, check if there's text in the composer
      const composerState = composer.getState();
      if (composerState.isEditing) {
        return composerState.text.length > 0;
      }
    }
    
    // Otherwise check if message has copyable content
    const message = messageRuntime.getState();
    const content = message.content;
    if (!content || content.length === 0) return false;
    
    const text = getThreadMessageText(message);
    return text.length > 0;
  });

  return computed(() => {
    if (!hasCopyableContent.value || !messageRuntime) return null;
    
    return async () => {
      const composer = editComposer.value;
      const composerState = composer?.getState();
      
      let textToCopy: string;
      if (composerState?.isEditing && composerState.text) {
        textToCopy = composerState.text;
      } else {
        const message = messageRuntime.getState();
        textToCopy = getThreadMessageText(message);
      }
      
      if (textToCopy) {
        await navigator.clipboard.writeText(textToCopy);
      }
    };
  });
}