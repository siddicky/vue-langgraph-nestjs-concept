<template>
  <template v-if="isInProgress">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useMessagePart } from '../../../composables/messagePart/useMessagePartContext';

const part = useMessagePart();

const isInProgress = computed(() => {
  if (!part.value) return false;
  return part.value.status?.type === 'running';
});
</script>