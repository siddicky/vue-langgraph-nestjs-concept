import { computed, ComputedRef } from 'vue';
import { useMessageRuntime } from '../../../composables/message/useMessageContext';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';

/**
 * Hook that provides a reload function for assistant messages.
 * Returns null when reload is not available (not assistant message, thread running, etc).
 * 
 * @returns A computed ref containing the reload function or null
 */
export function useActionBarReload(): ComputedRef<(() => void) | null> {
  const messageRuntime = useMessageRuntime();
  const threadRuntimeRef = useThreadRuntime();
  
  const canReload = computed(() => {
    const threadRuntime = threadRuntimeRef?.value;
    if (!threadRuntime || !messageRuntime) return false;
    
    const thread = threadRuntime.getState();
    const message = messageRuntime.getState();
    
    // Only available for assistant messages
    if (message.role !== "assistant") return false;
    
    // Not available when thread is running or disabled
    if (thread.isRunning || thread.isDisabled) return false;
    
    return true;
  });

  return computed(() => {
    if (!canReload.value || !messageRuntime) return null;
    
    return () => {
      messageRuntime.reload();
    };
  });
}