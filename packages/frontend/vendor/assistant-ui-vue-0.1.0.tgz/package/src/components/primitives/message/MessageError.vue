<template>
  <template v-if="hasError">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessageContext } from '../../../composables'

const context = useMessageContext()
const hasError = computed(() => {
  const msg = context?.message.value
  return msg?.status?.type === 'incomplete' && 
         msg.status.reason === 'error'
})
</script>