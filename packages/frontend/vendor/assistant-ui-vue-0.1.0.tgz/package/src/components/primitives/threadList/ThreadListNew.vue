<template>
  <button
    type="button"
    class="thread-list-new"
    :disabled="disabled"
    :data-active="isMain"
    :aria-current="isMain"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useAssistantRuntime } from '../../../composables'

interface Props {
  disabled?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  disabled: false
})

const assistantRuntime = useAssistantRuntime()

const isMain = computed(() => {
  if (!assistantRuntime.value) return false
  const threadList = assistantRuntime.value.threads.getState()
  return threadList.newThread === threadList.mainThreadId
})

const handleClick = () => {
  if (!props.disabled && assistantRuntime.value) {
    assistantRuntime.value.switchToNewThread()
  }
}
</script>