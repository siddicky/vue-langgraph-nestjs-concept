<template>
  <MessageRoot v-if="message">
    <MessageParts />
  </MessageRoot>
</template>

<script setup lang="ts">
import { useMessageContext } from '../../../composables/message/useMessageContext';
import MessageRoot from './MessageRoot.vue';
import MessageParts from './MessageParts.vue';

const context = useMessageContext();
const message = context?.message;
</script>