<template>
  <button
    type="button"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { inject } from 'vue'
import type { Ref } from 'vue'

const isOpen = inject<Ref<boolean>>('assistantModalOpen')
const setOpen = inject<(value: boolean) => void>('assistantModalSetOpen')

const handleClick = () => {
  if (setOpen && isOpen) {
    setOpen(!isOpen.value)
  }
}
</script>