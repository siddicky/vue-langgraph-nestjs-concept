<template>
  <button
    v-if="!isAtBottom"
    @click="handleScrollToBottom"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadViewportContext } from '../../../composables'

const context = useThreadViewportContext()
const isAtBottom = computed(() => context?.threadViewportStore.value?.isAtBottom ?? true)

const handleScrollToBottom = () => {
  context?.threadViewport?.scrollToBottom()
}
</script>