<template>
  <button
    :disabled="!callback"
    @click="handleClick"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useActionBarEdit } from './useActionBarEdit';

/**
 * Button component that starts editing the current message.
 * 
 * Automatically disabled when already in editing mode.
 * 
 * @example
 * ```vue
 * <ActionBarEdit>Edit Message</ActionBarEdit>
 * ```
 */

const callback = useActionBarEdit();

const handleClick = () => {
  if (callback.value) {
    callback.value();
  }
};
</script>