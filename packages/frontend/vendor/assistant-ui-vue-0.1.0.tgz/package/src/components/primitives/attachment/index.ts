export { default as AttachmentRoot } from './AttachmentRoot.vue'
export { default as AttachmentName } from './AttachmentName.vue'
export { default as AttachmentRemove } from './AttachmentRemove.vue'
export { default as AttachmentThumb } from './AttachmentThumb.vue'