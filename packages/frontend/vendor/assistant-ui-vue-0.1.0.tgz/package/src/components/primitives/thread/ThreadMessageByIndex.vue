<template>
  <MessageRuntimeProvider v-if="runtime" :runtime="runtime">
    <ThreadMessageComponent :components="components" />
  </MessageRuntimeProvider>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';
import MessageRuntimeProvider from '../../../context/providers/MessageRuntimeProvider.vue';
import ThreadMessageComponent from './ThreadMessageComponent.vue';
import type { ThreadMessageComponentTypes } from '../../../types/ThreadMessageComponentTypes';

export interface ThreadMessageByIndexProps {
  index: number;
  components: ThreadMessageComponentTypes;
}

const props = defineProps<ThreadMessageByIndexProps>();

const threadRuntime = useThreadRuntime();

const runtime = computed(() => {
  return threadRuntime?.value?.getMesssageByIndex(props.index);
});
</script>