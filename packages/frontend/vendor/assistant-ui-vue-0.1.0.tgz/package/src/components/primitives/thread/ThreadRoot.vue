<template>
  <div ref="rootRef" v-bind="$attrs">
    <slot />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

/**
 * The root container component for a thread.
 *
 * This component serves as the foundational wrapper for all thread-related components.
 * It provides the basic structure and context needed for thread functionality.
 *
 * @example
 * ```vue
 * <ThreadRoot>
 *   <ThreadViewport>
 *     <ThreadMessages />
 *   </ThreadViewport>
 * </ThreadRoot>
 * ```
 */
defineOptions({
  name: 'ThreadRoot',
  inheritAttrs: true
});

const rootRef = ref<HTMLDivElement>();

defineExpose({
  rootRef
});
</script>