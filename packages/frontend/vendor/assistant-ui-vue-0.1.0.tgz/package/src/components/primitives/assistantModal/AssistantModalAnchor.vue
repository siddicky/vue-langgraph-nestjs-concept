<template>
  <div ref="anchorRef" class="assistant-modal-anchor">
    <slot />
  </div>
</template>

<script setup lang="ts">
import { ref, provide, onMounted } from 'vue'

const anchorRef = ref<HTMLElement>()

// Provide anchor element to content for positioning
provide('assistantModalAnchor', anchorRef)

onMounted(() => {
  // Can be used for positioning calculations
})
</script>