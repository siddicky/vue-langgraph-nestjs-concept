<template>
  <textarea
    ref="textareaRef"
    v-model="value"
    :disabled="isDisabled"
    :placeholder="placeholder"
    :rows="rows"
    :maxRows="maxRows"
    :minRows="minRows"
    :class="class"
    @keydown="handleKeyDown"
    @paste="handlePaste"
    v-bind="$attrs"
  />
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue';
import { useComposer, useComposerRuntime } from '../../../composables/composer/useComposerContext';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';
import { useThreadContext } from '../../../composables/thread/useThreadContext';
import { useThreadListItemRuntime } from '../../../composables/threadListItem/useThreadListItemContext';
// import { useOnScrollToBottom } from '../../../utils/hooks/useOnScrollToBottom'; // TODO: Convert from React

/**
 * A text input component for composing messages.
 *
 * This component provides a rich text input experience with automatic resizing,
 * keyboard shortcuts, file paste support, and intelligent focus management.
 * It integrates with the composer context to manage message state and submission.
 *
 * @example
 * ```vue
 * <ComposerInput
 *   placeholder="Type your message..."
 *   :submitOnEnter="true"
 *   :addAttachmentOnPaste="true"
 * />
 * ```
 */

export interface ComposerInputProps {
  placeholder?: string;
  disabled?: boolean;
  autoFocus?: boolean;
  submitOnEnter?: boolean;
  cancelOnEscape?: boolean;
  unstable_focusOnRunStart?: boolean;
  unstable_focusOnScrollToBottom?: boolean;
  unstable_focusOnThreadSwitched?: boolean;
  addAttachmentOnPaste?: boolean;
  rows?: number;
  minRows?: number;
  maxRows?: number;
  class?: string;
}

const props = withDefaults(defineProps<ComposerInputProps>(), {
  autoFocus: false,
  submitOnEnter: true,
  cancelOnEscape: true,
  unstable_focusOnRunStart: true,
  unstable_focusOnScrollToBottom: true,
  unstable_focusOnThreadSwitched: true,
  addAttachmentOnPaste: true,
  rows: 1,
  minRows: 1,
  maxRows: 5
});

const textareaRef = ref<HTMLTextAreaElement>();
const threadListItemRuntime = useThreadListItemRuntime({ optional: true });
const threadRuntime = useThreadRuntime();
const composerRuntime = useComposerRuntime();
const threadContext = useThreadContext();

const value = useComposer((c) => {
  if (!c.isEditing) return "";
  return c.text;
});

const isThreadDisabled = computed(() => threadContext?.thread.value?.isDisabled ?? false);
const isDisabled = computed(() => Boolean(isThreadDisabled.value || props.disabled));

const focus = () => {
  const textarea = textareaRef.value;
  if (!textarea || !props.autoFocus || isDisabled.value) return;
  
  textarea.focus({ preventScroll: true });
  textarea.setSelectionRange(textarea.value.length, textarea.value.length);
};

const handleKeyDown = (e: KeyboardEvent) => {
  // Handle escape key
  if (props.cancelOnEscape && e.key === 'Escape') {
    if (composerRuntime.value?.getState().canCancel) {
      composerRuntime.value.cancel();
      e.preventDefault();
    }
    return;
  }

  // Handle enter key for submission
  if (isDisabled.value || !props.submitOnEnter) return;
  
  // Ignore IME composition events
  if (e.isComposing) return;
  
  if (e.key === 'Enter' && !e.shiftKey) {
    const { isRunning } = threadRuntime.value?.getState() ?? {};
    
    if (!isRunning) {
      e.preventDefault();
      textareaRef.value?.closest('form')?.requestSubmit();
    }
  }
};

const handlePaste = async (e: ClipboardEvent) => {
  if (!props.addAttachmentOnPaste) return;
  
  const threadCapabilities = threadRuntime.value?.getState().capabilities;
  const files = Array.from(e.clipboardData?.files || []);
  
  if (threadCapabilities?.attachments && files.length > 0) {
    try {
      e.preventDefault();
      await Promise.all(
        files.map((file) => composerRuntime.value?.addAttachment(file))
      );
    } catch (error) {
      console.error("Error adding attachment:", error);
    }
  }
};

// Watch for value changes from model
watch(value, (newValue) => {
  if (textareaRef.value && textareaRef.value.value !== newValue) {
    textareaRef.value.value = newValue ?? '';
  }
});

// Handle text input changes
watch(() => textareaRef.value?.value, (newValue) => {
  if (!composerRuntime.value?.getState().isEditing) return;
  composerRuntime.value?.setText(newValue ?? '');
});

// Auto-focus on mount
onMounted(() => {
  if (props.autoFocus) {
    nextTick(focus);
  }
});

// Focus on scroll to bottom
// TODO: Convert useOnScrollToBottom from React
// useOnScrollToBottom(() => {
//   if (composerRuntime.value?.type === "thread" && props.unstable_focusOnScrollToBottom) {
//     focus();
//   }
// });

// Focus on run start
watch(() => threadRuntime.value, (runtime) => {
  if (!runtime || composerRuntime.value?.type !== "thread" || !props.unstable_focusOnRunStart) {
    return;
  }
  
  const unsubscribe = runtime.unstable_on("run-start", focus);
  
  // Clean up on unmount
  onUnmounted(() => unsubscribe?.());
}, { immediate: true });

// Focus on thread switch
watch(() => threadListItemRuntime?.value, (runtime) => {
  if (!runtime || composerRuntime.value?.type !== "thread" || !props.unstable_focusOnThreadSwitched) {
    return;
  }
  
  const unsubscribe = runtime.unstable_on("switched-to", focus);
  
  // Clean up on unmount
  onUnmounted(() => unsubscribe?.());
}, { immediate: true });
</script>