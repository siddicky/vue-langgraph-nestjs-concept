<template>
  <template v-if="shouldRender">
    <slot />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useComposer } from '../../../composables/composer/useComposerContext';
/**
 * Conditional rendering component for composer states.
 * 
 * Renders children when the composer matches the specified state.
 * At least one condition must be provided.
 * 
 * @example
 * ```vue
 * <ComposerIf :editing="true">
 *   <!-- Only shown when composer is in editing mode -->
 * </ComposerIf>
 * 
 * <ComposerIf :editing="false">
 *   <!-- Only shown when composer is NOT in editing mode -->
 * </ComposerIf>
 * ```
 */

interface ComposerIfProps {
  editing?: boolean;
}

const props = defineProps<ComposerIfProps>();

const isEditing = useComposer((c) => c?.isEditing);

const shouldRender = computed(() => {
  if (props.editing !== undefined) {
    return isEditing.value === props.editing;
  }
  return true;
});
</script>