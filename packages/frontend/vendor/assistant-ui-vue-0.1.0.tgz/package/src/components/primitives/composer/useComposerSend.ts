import { computed, ComputedRef } from 'vue';
import { useComposerRuntime } from '../../../composables/composer/useComposerContext';
import { useThreadRuntime } from '../../../composables/thread/useThreadRuntime';

/**
 * Hook that provides a send function for the composer.
 * Returns null when sending is disabled (thread is running, composer is not editing, or composer is empty).
 * 
 * @returns A computed ref containing the send function or null
 */
export function useComposerSend(): ComputedRef<(() => void) | null> {
  const composerRuntime = useComposerRuntime();
  const threadRuntime = useThreadRuntime();

  const disabled = computed(() => {
    const thread = threadRuntime?.value;
    const composer = composerRuntime?.value;
    if (!thread || !composer) return true;
    
    const threadState = thread.getState();
    const composerState = composer.getState();
    return threadState.isRunning || !composerState.isEditing || composerState.isEmpty;
  });

  return computed(() => {
    if (disabled.value || !composerRuntime?.value) return null;
    return () => composerRuntime.value!.send();
  });
}