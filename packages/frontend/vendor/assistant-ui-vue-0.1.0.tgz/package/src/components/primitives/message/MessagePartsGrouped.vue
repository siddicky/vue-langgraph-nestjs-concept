<template>
  <template v-if="contentLength === 0">
    <EmptyParts :components="components" />
  </template>
  <template v-else>
    <component
      v-for="(group, groupIndex) in messageGroups"
      :key="`group-${groupIndex}-${group.groupKey ?? 'ungrouped'}`"
      :is="GroupComponent"
      :group-key="group.groupKey"
      :indices="group.indices"
    >
      <MessagePart
        v-for="partIndex in group.indices"
        :key="partIndex"
        :part-index="partIndex"
        :components="components"
      />
    </component>
  </template>
</template>

<script lang="ts">
import type { Component } from 'vue'
import type { GroupingFunction } from './messagePartsUtils'

export interface MessagePartsGroupedProps {
  groupingFunction: GroupingFunction
  components?: Components
}

interface Components {
  Empty?: Component
  Text?: Component
  Reasoning?: Component
  Source?: Component
  Image?: Component
  File?: Component
  Unstable_Audio?: Component
  tools?: {
    by_name?: Record<string, Component | undefined>
    Fallback?: Component
  } | {
    Override: Component
  }
  Group?: Component
}
</script>

<script setup lang="ts">
import { computed, defineComponent, h, provide } from 'vue'
import type { PropType } from 'vue'
import { useMessageContext } from '../../../composables'
import MessagePartText from '../messagePart/MessagePartText.vue'
import MessagePartImage from '../messagePart/MessagePartImage.vue'
import MessagePartInProgress from '../messagePart/MessagePartInProgress.vue'
import type { MessagePartStatus } from '../../../types'

const props = defineProps<MessagePartsGroupedProps>()

const context = useMessageContext()
const contentLength = computed(() => context?.message.value?.content?.length ?? 0)

// Compute message groups
const messageGroups = computed(() => {
  const content = context?.message.value?.content
  if (!content || content.length === 0) {
    return []
  }
  return props.groupingFunction(content)
})

// Default components
const defaultComponents = {
  Text: defineComponent({
    setup() {
      return () => h('p', { style: { whiteSpace: 'pre-line' } }, [
        h(MessagePartText),
        h(MessagePartInProgress, () => h('span', { style: { fontFamily: 'revert' } }, ' ●'))
      ])
    }
  }),
  Reasoning: () => null,
  Source: () => null,
  Image: MessagePartImage,
  File: () => null,
  Unstable_Audio: () => null,
  Group: defineComponent({
    props: {
      groupKey: String,
      indices: Array as PropType<number[]>
    },
    setup(_, { slots }) {
      return () => slots.default?.()
    }
  })
}

// Group component
const GroupComponent = computed(() => props.components?.Group ?? defaultComponents.Group)

// EmptyParts component
const EmptyParts = defineComponent({
  props: {
    components: Object as PropType<Components>
  },
  setup(props) {
    const context = useMessageContext()
    const message = computed(() => context?.message.value)
    const status = computed(() => message.value?.status ?? { type: 'complete' } as MessagePartStatus)
    
    return () => {
      if (props.components?.Empty) {
        return h(props.components.Empty, { status: status.value })
      }
      
      const TextComponent = props.components?.Text ?? defaultComponents.Text
      provide('textMessagePart', { text: '', isRunning: status.value.type === 'running' })
      
      return h(TextComponent, {
        type: 'text',
        text: '',
        status: status.value
      })
    }
  }
})

// MessagePart component
const MessagePart = defineComponent({
  props: {
    partIndex: {
      type: Number,
      required: true
    },
    components: Object as PropType<Components>
  },
  setup(props) {
    const context = useMessageContext()
    const runtime = computed(() => context?.messageRuntime.getMessagePartByIndex(props.partIndex))
    
    return () => {
      if (!runtime.value) return null
      
      provide('messagePartRuntime', runtime.value)
      
      const part = runtime.value.getState()
      const type = part.type
      
      const components = {
        Text: props.components?.Text ?? defaultComponents.Text,
        Reasoning: props.components?.Reasoning ?? defaultComponents.Reasoning,
        Image: props.components?.Image ?? defaultComponents.Image,
        Source: props.components?.Source ?? defaultComponents.Source,
        File: props.components?.File ?? defaultComponents.File,
        Unstable_Audio: props.components?.Unstable_Audio ?? defaultComponents.Unstable_Audio,
        tools: props.components?.tools ?? {}
      }
      
      if (type === 'tool-call') {
        const addResult = (result: any) => runtime.value?.addToolResult(result)
        if ('Override' in components.tools) {
          return h(components.tools.Override, { ...part, addResult })
        }
        const Tool = components.tools.by_name?.[part.toolName] ?? components.tools.Fallback
        if (Tool) {
          return h(Tool, { ...part, addResult })
        }
        return null
      }
      
      if (part.status.type === 'requires-action') {
        throw new Error('Encountered unexpected requires-action status')
      }
      
      switch (type) {
        case 'text':
          return h(components.Text, part)
        case 'reasoning':
          return h(components.Reasoning, part)
        case 'source':
          return h(components.Source, part)
        case 'image':
          return h(components.Image, part)
        case 'file':
          return h(components.File, part)
        case 'audio':
          return h(components.Unstable_Audio, part)
        default:
          const unhandledType: never = type
          throw new Error(`Unknown message part type: ${unhandledType}`)
      }
    }
  }
})
</script>