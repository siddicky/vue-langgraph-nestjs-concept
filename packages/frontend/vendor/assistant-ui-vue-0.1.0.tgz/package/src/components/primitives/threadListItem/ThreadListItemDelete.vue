<template>
  <button
    type="button"
    class="thread-list-item-delete"
    @click="handleDelete"
    v-bind="$attrs"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
import { useThreadListItemContext } from '../../../composables'

const threadListItemRuntime = useThreadListItemContext()

const handleDelete = () => {
  if (threadListItemRuntime.value) {
    threadListItemRuntime.value.delete()
  }
}
</script>