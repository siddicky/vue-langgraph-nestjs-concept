export { default as ThreadRoot } from './ThreadRoot.vue';
export { default as ThreadViewport } from './ThreadViewport.vue';
export { default as ThreadMessages } from './ThreadMessages.vue';
export { default as ThreadMessageByIndex } from './ThreadMessageByIndex.vue';
export { default as ThreadMessageComponent } from './ThreadMessageComponent.vue';
export { default as ThreadEmpty } from './ThreadEmpty.vue';
export { default as ThreadIf } from './ThreadIf.vue';
export { default as ThreadScrollToBottom } from './ThreadScrollToBottom.vue';
export { default as ThreadSuggestion } from './ThreadSuggestion.vue';

// Export all thread components as namespace
import ThreadRoot from './ThreadRoot.vue';
import ThreadViewport from './ThreadViewport.vue';
import ThreadMessages from './ThreadMessages.vue';
import ThreadMessageByIndex from './ThreadMessageByIndex.vue';
import ThreadEmpty from './ThreadEmpty.vue';
import ThreadIf from './ThreadIf.vue';
import ThreadScrollToBottom from './ThreadScrollToBottom.vue';
import ThreadSuggestion from './ThreadSuggestion.vue';

export const ThreadPrimitive = {
  Root: ThreadRoot,
  Viewport: ThreadViewport,
  Messages: ThreadMessages,
  MessageByIndex: ThreadMessageByIndex,
  Empty: ThreadEmpty,
  If: ThreadIf,
  ScrollToBottom: ThreadScrollToBottom,
  Suggestion: ThreadSuggestion,
} as const;