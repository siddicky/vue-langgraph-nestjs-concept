<template>
  <span class="branch-picker-count">{{ branchCount }}</span>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useMessage } from '../../../composables'

const message = useMessage()

const branchCount = computed(() => {
  return message?.branchCount || 0
})
</script>