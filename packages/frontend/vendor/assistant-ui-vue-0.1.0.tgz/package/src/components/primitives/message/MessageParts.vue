<template>
  <template v-if="contentLength === 0">
    <EmptyParts :components="components" />
  </template>
  <template v-else>
    <template v-for="range in messageRanges" :key="getKey(range)">
      <MessagePartByIndex
        v-if="range.type === 'single' && range.index !== undefined"
        :index="range.index"
        :components="components"
      />
      <component
        v-else-if="range.type === 'toolGroup' && range.startIndex !== undefined && range.endIndex !== undefined"
        :is="ToolGroupComponent"
        :start-index="range.startIndex"
        :end-index="range.endIndex"
      >
        <MessagePartByIndex
          v-for="i in range.endIndex - range.startIndex + 1"
          :key="i - 1"
          :index="range.startIndex + i - 1"
          :components="components"
        />
      </component>
    </template>
  </template>
</template>

<script setup lang="ts">
import { computed, defineComponent, h } from 'vue';
import { useMessage } from '../../../composables/message/useMessageContext';
import MessagePartByIndex from './MessagePartByIndex.vue';
import EmptyParts from './EmptyParts.vue';
import type { MessagePartComponentTypes } from '../../../types/MessagePartComponentTypes';

type MessagePartRange = 
  | { type: 'single'; index: number }
  | { type: 'toolGroup'; startIndex: number; endIndex: number };

interface Props {
  components?: MessagePartComponentTypes;
}

const props = withDefaults(defineProps<Props>(), {
  components: () => ({})
});

const contentLength = computed(() => {
  const message = useMessage();
  return message?.content?.length ?? 0;
});

const messageTypes = computed(() => {
  const message = useMessage();
  return message?.content?.map((c: any) => c.type) ?? [];
});

const groupMessageParts = (types: string[]): MessagePartRange[] => {
  const ranges: MessagePartRange[] = [];
  let currentToolGroupStart = -1;

  for (let i = 0; i < types.length; i++) {
    const type = types[i];

    if (type === 'tool-call') {
      if (currentToolGroupStart === -1) {
        currentToolGroupStart = i;
      }
    } else {
      if (currentToolGroupStart !== -1) {
        ranges.push({
          type: 'toolGroup',
          startIndex: currentToolGroupStart,
          endIndex: i - 1,
        });
        currentToolGroupStart = -1;
      }

      ranges.push({ type: 'single', index: i });
    }
  }

  if (currentToolGroupStart !== -1) {
    ranges.push({
      type: 'toolGroup',
      startIndex: currentToolGroupStart,
      endIndex: types.length - 1,
    });
  }

  return ranges;
};

const messageRanges = computed(() => {
  if (messageTypes.value.length === 0) {
    return [];
  }
  return groupMessageParts(messageTypes.value);
});

const getKey = (range: MessagePartRange) => {
  if (range.type === 'single') {
    return range.index;
  }
  return range.startIndex;
};

const defaultToolGroup = defineComponent({
  name: 'DefaultToolGroup',
  render() {
    return h('div', this.$slots.default?.());
  }
});

const ToolGroupComponent = computed(() => {
  return props.components?.ToolGroup ?? defaultToolGroup;
});
</script>