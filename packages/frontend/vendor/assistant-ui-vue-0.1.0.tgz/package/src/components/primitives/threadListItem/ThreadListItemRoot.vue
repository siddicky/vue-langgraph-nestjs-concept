<template>
  <div
    class="thread-list-item-root"
    :data-active="isMain"
    :aria-current="isMain"
    v-bind="$attrs"
  >
    <slot />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useThreadListItemContext } from '../../../composables'

const context = useThreadListItemContext()

const isMain = computed(() => {
  const item = context?.value?.getState()
  return item?.isMain || false
})
</script>