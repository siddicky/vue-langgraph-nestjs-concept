<template>
  <template v-for="index in attachmentsCount" :key="index - 1">
    <ComposerAttachmentByIndex
      :index="index - 1"
      :components="components"
    />
  </template>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { Component } from 'vue'
import { useComposerContext } from '../../../composables'
import ComposerAttachmentByIndex from './ComposerAttachmentByIndex.vue'

interface Components {
  Image?: Component
  Document?: Component
  File?: Component
  Attachment?: Component
}

interface Props {
  components?: Components
}

defineProps<Props>()

const context = useComposerContext()
const attachmentsCount = computed(() => context?.composer.value?.attachments?.length ?? 0)
</script>